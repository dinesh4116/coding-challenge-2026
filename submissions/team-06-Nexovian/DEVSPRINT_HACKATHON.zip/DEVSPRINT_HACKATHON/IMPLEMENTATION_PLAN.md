# AdMatch AI — Master Implementation Plan
**Role:** Senior Project Developer & Senior Web Architect  
**Project:** Ad-to-Landing-Page Message Match Auditor (Hackathon MVP)  
**Target Environment:** Local Windows (Python 3.11.9) • No Git commits or pushes

---

## 1. Executive Summary & Architecture Overview

**AdMatch AI** is an AI-powered advertising consistency auditor. It verifies whether an ad’s promises (discounts, product claims, CTAs, eligibility, imagery) match the destination landing page, backed by **traceable evidence**, not arbitrary black-box hallucinations.

### Core Architectural Pillars
1. **Decoupled Architecture**: FastAPI backend houses the intelligence (scraping, MiniLM semantic matching, deterministic claim verification, CLIP image comparison, and OCR). The Streamlit frontend is a thin, reactive client.
2. **Relevance ≠ Truth**: Semantic similarity retrieves candidate evidence sentences; rule-based deterministic checks classify claims into `SUPPORTED`, `CONTRADICTED`, `UNSUPPORTED`, and `UNCERTAIN`.
3. **Resilient Degradation**: If PyTorch, CLIP, or EasyOCR are not loaded, the system automatically falls back to a 100% operational text-only pipeline with transparent UI warnings.
4. **Security by Design**: Complete SSRF defenses (preventing private IP fetching, DNS resolution checks, redirect inspection), response size limits (20KB text / 10 images max), and timeout enforcement.

---

## 2. Target Directory & File Structure

```text
f:\Coding\Events\DEVSPRINT_HACKATHON\
│
├── IMPLEMENTATION_PLAN.md           # This document
├── MODEL_SETUP_GUIDE.md             # Open-source model setup & caching instructions
├── requirements.txt                 # Pinned dependencies
├── run_local.bat                    # One-click launcher for Backend & Frontend
├── .gitignore                       # Standard python/cache ignores
│
├── backend/
│   ├── __init__.py
│   ├── main.py                      # FastAPI application with CORS & endpoints
│   ├── schemas.py                   # Pydantic v2 data models for API contracts
│   │
│   ├── services/
│   │   ├── __init__.py
│   │   ├── scraper.py               # Requests + BeautifulSoup + Trafilatura scraper
│   │   ├── image_extractor.py       # Safe landing-page image extraction & validation
│   │   ├── text_matcher.py          # Sentence-level MiniLM semantic retrieval
│   │   ├── claim_verifier.py        # Deterministic rule engine (discounts, numbers, dates)
│   │   ├── ocr_service.py           # EasyOCR text extraction from ad creatives
│   │   ├── image_matcher.py         # CLIP ViT-B/32 visual embedding cosine comparison
│   │   └── report_service.py        # Composite heuristic scoring and audit synthesis
│   │
│   └── utils/
│       ├── __init__.py
│       ├── url_security.py          # SSRF prevention, IP whitelist/blacklist, DNS validator
│       └── text_cleaner.py          # Text normalization, claim chunker, sentence splitter
│
├── frontend/
│   └── app.py                       # Premium Streamlit UI with metric cards & evidence tables
│
└── tests/
    ├── __init__.py
    ├── test_scraper.py              # Mock HTML scraping & error handling tests
    ├── test_matcher.py              # Claim verification & rule checks tests
    └── test_api.py                  # FastAPI TestClient endpoints tests
```

---

## 3. Detailed Component Specifications

### 3.1 Security & URL Validation (`backend/utils/url_security.py`)
- Restrict schemes to `http` and `https`.
- Resolve domain DNS before fetching; block loopback (`127.0.0.1`, `::1`), private networks (`10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`), link-local, and cloud metadata endpoints (`169.254.169.254`).
- Validate subsequent redirect destinations prior to following.

### 3.2 Web Scraping Engine (`backend/services/scraper.py`)
- Fetch with custom User-Agent, 10s timeout, and 5MB payload limit.
- Parse structured HTML elements using **BeautifulSoup4** (H1, H2, H3, buttons, CTAs, Open Graph tags).
- Extract cleaned body text using **Trafilatura** (stripping navigation bars, cookie banners, tracking scripts, footers).
- **JavaScript Rendering Fallback**: If the initial extracted text is empty or minimal because a site renders content dynamically using JavaScript (SPAs, React/Vue/Angular/Next.js hydration), automatically invoke **Playwright** (headless Chromium) as a fallback to execute scripts and extract the rendered DOM.
- Mark extraction provenance via `extraction_method` metadata (`"requests"` or `"playwright_fallback"`).
- Sentence boundary splitting via regex/NLTK for atomic evidence candidates.
- Cap extracted text at 20,000 characters to prevent memory exhaustion.

### 3.3 Semantic Retrieval (`backend/services/text_matcher.py`)
- Lazy-loaded `sentence-transformers/all-MiniLM-L6-v2` singleton.
- Vectorize ad claims and all landing-page sentences.
- Compute cosine similarity matrix via `scikit-learn`.
- Retrieve top-3 candidate sentences per claim with exact character snippets and similarity scores.

### 3.4 Claim Verification Engine (`backend/services/claim_verifier.py`)
- Inspect claims and top evidence candidates using deterministic regex and entity rules:
  - **Discount percentages**: e.g. "50% off" vs page mentioning "20% off" (`CONTRADICTED`) or "50% off" (`SUPPORTED`) or no percentage (`UNSUPPORTED`).
  - **Prices / Currencies**: Dollar/Euro/Rupee figures.
  - **Eligibility**: "first-time customers", "new users", "students".
  - **Shipping**: "free delivery", "free shipping", minimum cart thresholds.
  - **Expiration/Dates**: "today only", "valid till...".
- Classification outputs:
  - `SUPPORTED`: Strong semantic alignment (>0.68) AND numerical/offer parameters verified.
  - `CONTRADICTED`: Conflicting numerical or factual conditions identified on the page.
  - `UNSUPPORTED`: No relevant evidence found on page.
  - `UNCERTAIN`: High lexical ambiguity or partial context.
- Generates precise **reasoning** and actionable **remediation suggestions**.

### 3.5 Image Processing & Vision Layer
- **`backend/services/ocr_service.py`**:
  - Validates image dimensions, file type (JPEG, PNG, WebP) and size (<10MB).
  - Runs EasyOCR to extract promotional banners and promotional overlays.
  - Normalizes text and feeds into claim extractor.
- **`backend/services/image_matcher.py`**:
  - Uses `openai/clip-vit-base-patch32` (or Hugging Face transformers CLIP).
  - Resizes images to standard 224x224.
  - Computes normalized image embeddings; calculates cosine similarity against up to 10 top landing-page images.
  - Displays top visual matches without claiming visual score equals factual truth.

### 3.6 API Contracts (`backend/schemas.py` & `backend/main.py`)
- `GET /health` -> System health and loaded AI model status (`miniLM: true`, `clip: false/true`, `ocr: false/true`).
- `POST /api/scrape` -> Standalone scraper diagnostic endpoint.
- `POST /api/audit` -> Multipart form data (`ad_headline`, `ad_description`, `landing_page_url`, optional `ad_image`).
  - Returns unified JSON audit dossier: page metadata, text match score, visual match score, list of claims with statuses, evidence quotations, suggestions, and warnings.

### 3.7 Frontend Interface (`frontend/app.py`)
- Streamlit application configured with modern typography, dark mode theme, status badges, and expandable evidence dossiers.
- Interactive controls:
  - Quick-fill preset test cases (e.g. *Legitimate Offer*, *Bait-and-Switch Discount*, *Missing Terms*).
  - Ad creative file uploader with live preview.
  - High-level metric KPI cards (Text Consistency Score, Visual Similarity, Offer Match Status).
  - Color-coded claim badges (Green: Supported, Red: Contradicted, Yellow: Unsupported, Gray: Uncertain).
  - Traceable quote callouts displaying exact webpage quotations with source tags.
  - One-click JSON Audit Report download.

---

## 4. Step-by-Step Implementation Roadmap

```mermaid
graph TD
    A[Milestone 1: Project Setup & Utils] --> B[Milestone 2: Scraper & Security]
    B --> C[Milestone 3: Text Matcher & Claim Verifier]
    C --> D[Milestone 4: FastAPI Core Endpoints]
    D --> E[Milestone 5: Streamlit Interactive UI]
    E --> F[Milestone 6: Vision & OCR Layer with Lazy Fallbacks]
    F --> G[Milestone 7: Unit Testing & Preset Demo Scenarios]
```

### Milestone Breakdown
1. **Milestone 1**: Initialize folder hierarchy, `.gitignore`, and `requirements.txt`.
2. **Milestone 2**: Implement `url_security.py`, `text_cleaner.py`, and `scraper.py`. Verify with live/mock pages.
3. **Milestone 3**: Implement `text_matcher.py` and `claim_verifier.py`. Test deterministic discount/offer verification.
4. **Milestone 4**: Build `schemas.py`, `report_service.py`, and `backend/main.py`. Verify API with curl / TestClient.
5. **Milestone 5**: Build `frontend/app.py` Streamlit dashboard with preset demo buttons and interactive audit cards.
6. **Milestone 6**: Add `ocr_service.py` and `image_matcher.py` with safe try/except fallback guards.
7. **Milestone 7**: Create unit test suite in `tests/` and verify the entire end-to-end pipeline without errors.

---

## 5. Hackathon Winning Demo Strategy

To wow the judges in 3 minutes:
1. **Demo Case A (The Bait & Switch)**: Ad promises `"Get 50% off your first order"`. Landing page only states `"Save 15% on seasonal items"`.
   - Result: Instant flag **CONTRADICTED** with exact quote.
2. **Demo Case B (The Ghost Promotion)**: Ad promises `"Free Express Delivery on all orders"`. Landing page makes no mention of free express shipping.
   - Result: Instant flag **UNSUPPORTED** with clear suggestion.
3. **Demo Case C (The Flawless Match)**: Ad promises `"14-Day Free Trial - No Credit Card Required"`. Landing page hero section contains exact terms.
   - Result: Instant flag **SUPPORTED** with confidence metric.
