"""
Tests for URL Security & Web Scraping
"""
import pytest
from backend.utils.url_security import validate_url, is_ip_private_or_reserved
from backend.utils.text_cleaner import clean_text, split_into_sentences, extract_claims
from backend.services.image_extractor import extract_page_images

def test_url_security_blocks_private_ips():
    assert is_ip_private_or_reserved("127.0.0.1") is True
    assert is_ip_private_or_reserved("10.0.0.5") is True
    assert is_ip_private_or_reserved("192.168.1.1") is True
    assert is_ip_private_or_reserved("169.254.169.254") is True
    assert is_ip_private_or_reserved("8.8.8.8") is False

def test_url_security_validate_url():
    valid, err = validate_url("ftp://example.com")
    assert valid is False
    assert "Unsupported protocol" in err

    valid, err = validate_url("http://localhost:8000")
    assert valid is False
    assert "SSRF" in err or "blocked" in err

    valid, err = validate_url("https://www.google.com")
    assert valid is True
    assert err is None

def test_split_into_sentences_preserves_decimals_and_numbers():
    text = "Get 50.5% off today! Premium subscription is only $49.99 per year. Order now."
    sentences = split_into_sentences(text)
    assert len(sentences) == 3
    assert "50.5% off today" in sentences[0]
    assert "$49.99" in sentences[1]

def test_extract_claims():
    headline = "50% Off First Order • Free Express Shipping"
    desc = "Join today and get 14-day free trial with no credit card required."
    claims = extract_claims(headline, desc)
    assert len(claims) >= 3
    assert any("50%" in c for c in claims)
    assert any("Free" in c or "Shipping" in c for c in claims)

def test_extract_page_images_with_og_and_filtering():
    html = """
    <html>
      <head>
        <meta property="og:image" content="https://example.com/hero.jpg" />
      </head>
      <body>
        <img src="/static/favicon.png" width="16" height="16" />
        <img src="https://example.com/product-large.png" width="800" height="600" alt="Special Product" />
      </body>
    </html>
    """
    images = extract_page_images(html, "https://example.com")
    assert len(images) == 2
    urls = [i["url"] for i in images]
    assert "https://example.com/hero.jpg" in urls
    assert "https://example.com/product-large.png" in urls
    assert not any("favicon" in u for u in urls)

def test_scrape_landing_page_with_local_snapshot():
    from backend.services.scraper import scrape_landing_page
    data = scrape_landing_page("PS-03_message_match_auditor/landing_page_snapshots/pair_01.html")
    assert "Kestrel" in data["title"]
    assert len(data["paragraphs"]) > 5
    assert data["extraction_method"] == "local_snapshot"

def test_scrape_landing_page_blocks_private_ip():
    from backend.services.scraper import scrape_landing_page
    with pytest.raises(ValueError) as excinfo:
        scrape_landing_page("http://127.0.0.1:8000")
    assert "SSRF" in str(excinfo.value) or "blocked" in str(excinfo.value)
