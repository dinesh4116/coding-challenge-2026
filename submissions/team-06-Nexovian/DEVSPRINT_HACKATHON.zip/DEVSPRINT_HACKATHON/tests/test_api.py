"""
Tests for FastAPI Endpoints using TestClient
"""
import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch

from backend.main import app

client = TestClient(app)

def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "features" in data

def test_scrape_endpoint_validation_error():
    # Bad protocol
    response = client.post("/api/scrape", json={"url": "ftp://bad-url.com"})
    assert response.status_code == 400

@patch("backend.main.scrape_landing_page")
def test_audit_endpoint_success(mock_scrape):
    mock_scrape.return_value = {
        "original_url": "https://example.com/store",
        "final_url": "https://example.com/store",
        "title": "Example Super Store",
        "meta_description": "Great store deals",
        "headings": ["Seasonal Discounts"],
        "main_text": "Enjoy 50% off your entire first order today. Explore our catalog.",
        "paragraphs": ["Enjoy 50% off your entire first order today.", "Explore our catalog."],
        "ctas": ["Shop Now"],
        "images": [],
        "extraction_method": "requests",
        "character_count": 65,
        "warnings": []
    }

    response = client.post(
        "/api/audit",
        data={
            "ad_headline": "Get 50% off your first order",
            "ad_description": "Shop the collection today",
            "landing_page_url": "https://example.com/store"
        }
    )
    assert response.status_code == 200
    data = response.json()
    assert "page" in data
    assert "summary" in data
    assert "claims" in data
    assert len(data["claims"]) >= 1
    # Check claim status
    assert data["claims"][0]["status"] == "SUPPORTED"
