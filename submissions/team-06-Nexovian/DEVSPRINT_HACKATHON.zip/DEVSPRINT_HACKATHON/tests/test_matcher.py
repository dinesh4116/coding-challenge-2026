"""
Tests for Text Matching, Semantic Retrieval & Deterministic Claim Verification
"""
import pytest
from backend.services.claim_verifier import verify_claim
from backend.services.text_matcher import match_claim
from backend.services.report_service import synthesize_report
from backend.schemas import ClaimAudit, ClaimStatus

def test_verify_claim_supported_discount():
    claim = "Get 50% off your first purchase"
    evidence = [
        {"evidence": "Enjoy 50% off on all first orders this week.", "similarity": 0.88, "source": "main_text"}
    ]
    res = verify_claim(claim, evidence)
    assert res["status"] == "SUPPORTED"
    assert "50%" in res["reason"]

def test_verify_claim_contradicted_discount():
    claim = "Get 50% off your first purchase"
    evidence = [
        {"evidence": "Explore our site and save 15% on selected items.", "similarity": 0.65, "source": "main_text"}
    ]
    res = verify_claim(claim, evidence)
    assert res["status"] == "CONTRADICTED"
    assert "15%" in res["reason"]

def test_verify_claim_unsupported_discount():
    claim = "Get 50% off your first purchase"
    evidence = [
        {"evidence": "Welcome to our shop featuring handcrafted artisan jewelry.", "similarity": 0.35, "source": "main_text"}
    ]
    res = verify_claim(claim, evidence)
    assert res["status"] == "UNSUPPORTED"

def test_verify_claim_contradicted_shipping():
    claim = "Free delivery on all orders"
    evidence = [
        {"evidence": "Standard delivery fee $10 applies at checkout.", "similarity": 0.70, "source": "main_text"}
    ]
    res = verify_claim(claim, evidence)
    assert res["status"] == "CONTRADICTED"

def test_match_claim_lexical_or_model():
    claim = "100% organic cotton tees"
    sentences = [
        "We are based in San Francisco.",
        "Every shirt is made with 100% organic cotton.",
        "Sign up for our newsletter today."
    ]
    matches = match_claim(claim, sentences, top_k=2)
    assert len(matches) == 2
    assert "cotton" in matches[0]["evidence"].lower()

def test_synthesize_report_contradiction_yields_high_mismatch():
    claims = [
        ClaimAudit(
            claim="50% off",
            status=ClaimStatus.CONTRADICTED,
            evidence=[],
            reason="Contradiction",
            suggestion="Fix it",
            category="discount"
        ),
        ClaimAudit(
            claim="High quality fabric",
            status=ClaimStatus.SUPPORTED,
            evidence=[],
            reason="Matched",
            suggestion="Good",
            category="feature"
        )
    ]
    summary = synthesize_report(claims)
    assert summary.contradicted_count == 1
    assert summary.overall_status.value == "HIGH_MISMATCH"
