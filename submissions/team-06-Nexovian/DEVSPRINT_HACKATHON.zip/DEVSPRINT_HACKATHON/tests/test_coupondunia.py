import requests

payload = {
    "landing_page_url": "https://www.coupondunia.in",
    "ad_headline": "Save More Every Day",
    "ad_description": "Exclusive coupons, offers and cashback on your favorite online stores."
}

r = requests.post("http://127.0.0.1:8000/api/audit", data=payload, timeout=25)
print("Status code:", r.status_code)
if r.status_code == 200:
    res = r.json()
    summary = res["summary"]
    page = res["page"]
    print(f"Title: {page['title']}")
    print(f"Score: {summary['text_score']} / 100 ({summary['overall_status']})")
    for idx, c in enumerate(res.get("claims", []), 1):
        print(f"[{idx}] Claim: '{c['claim']}' | Status: {c['status']}")
        if c.get("evidence"):
            print(f"    Quote: '{c['evidence'][0]['text']}' (Source: {c['evidence'][0]['source']})")
