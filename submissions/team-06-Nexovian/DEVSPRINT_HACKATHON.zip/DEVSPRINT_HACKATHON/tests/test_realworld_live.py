import requests
import json

payload = {
    "landing_page_url": "https://www.python.org",
    "ad_headline": "Python Programming Language: Fast, Friendly & Easy",
    "ad_description": "Work quickly and integrate systems more effectively. Get 90% instant discount on enterprise consulting."
}

# The endpoint expects form data because ad_image is an optional file upload
r = requests.post("http://127.0.0.1:8000/api/audit", data=payload, timeout=25)
print("Status code:", r.status_code)
if r.status_code == 200:
    res = r.json()
    summary = res["summary"]
    page = res["page"]
    print("\n=================== LIVE AUDIT RESULT ===================")
    print(f"Page Title: {page['title']}")
    print(f"Page URL: {page['url']}")
    print(f"Extraction Method: {page['extraction_method']}")
    print(f"Overall Consistency Score: {summary['text_score']} / 100")
    print(f"Verdict: {summary['overall_status']}")
    print(f"Claims Summary: Total={summary['total_claims']} | Supported={summary['supported_count']} | Unsupported={summary['unsupported_count']}")
    
    print("\n----------------- VERIFIED CLAIMS & GROUNDED EVIDENCE -----------------")
    for idx, c in enumerate(res.get("claims", []), 1):
        print(f"\n[Claim {idx}]: \"{c['claim']}\"")
        print(f"  • Category: {c['category']}")
        print(f"  • Status: {c['status']}")
        print(f"  • Reason: {c['reason']}")
        print(f"  • Concrete Fix: {c['suggestion']}")
        if c.get("evidence"):
            print("  • Verbatim Page Quotes:")
            for ev in c["evidence"]:
                print(f"    - \"{ev['text']}\" (Found in: {ev['source']}, Similarity: {ev['similarity']:.2f})")
else:
    print("Error:", r.text)
