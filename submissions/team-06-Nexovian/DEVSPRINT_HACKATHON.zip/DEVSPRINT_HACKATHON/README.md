# AdMatch AI — Ad-to-Landing-Page Message Match Auditor
**DevSprint Hackathon • Team NEXOVIAN**  
*Problem Statement: PS-03 (Web Scraping · Structured LLM Output · Grounding Verification)*

[![FastAPI](https://img.shields.io/badge/API-FastAPI%200.115-009688?style=for-the-badge&logo=fastapi&logoColor=white)](https://fastapi.tiangolo.com/)
[![Streamlit](https://img.shields.io/badge/UI-Streamlit%201.40-FF4B4B?style=for-the-badge&logo=streamlit&logoColor=white)](https://streamlit.io/)
[![Semantic AI](https://img.shields.io/badge/Text%20AI-MiniLM--L6--v2-F59E0B?style=for-the-badge&logo=huggingface&logoColor=white)](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2)
[![Vision AI](https://img.shields.io/badge/Vision%20AI-CLIP%20ViT--B%2F32-2563EB?style=for-the-badge&logo=openai&logoColor=white)](https://huggingface.co/openai/clip-vit-base-patch32)
[![OCR](https://img.shields.io/badge/OCR-EasyOCR-10B981?style=for-the-badge)](https://github.com/JaidedAI/EasyOCR)
[![Tests](https://img.shields.io/badge/Tests-16%2F16%20Passing-brightgreen?style=for-the-badge)](tests/)

---

## 📺 Live Demo Walkthrough

The walkthrough below demonstrates AdMatch AI detecting a **"Bait & Switch" disconnect** on a financial lending offer, calculating an overall consistency score, extracting verbatim quotes, penalizing buried fine print, and generating actionable copy fixes.

### ▶️ Playable Demo Video (720p HD MP4)
> **Direct Video File:** [▶️ Click here to open/play `docs/admatch_demo_video.mp4`](docs/admatch_demo_video.mp4)

<video src="docs/admatch_demo_video.mp4" controls="controls" width="100%" poster="docs/screenshots/01_executive_summary.png">
  <p>Your markdown previewer does not support embedded MP4 video tags. <a href="docs/admatch_demo_video.mp4">Click here to play the MP4 directly</a> or view the animated preview below:</p>
</video>

### 🎬 Animated Walkthrough Preview
![AdMatch AI Demo Walkthrough](docs/admatch_demo_walkthrough.gif)

### Key Dashboard Views
| 1. Executive Summary & Score Gauge | 2. Deep Technical Dossier & Verbatim Quotes |
| :---: | :---: |
| ![Executive Summary](docs/screenshots/01_executive_summary.png) | ![Technical Dossier](docs/screenshots/02_technical_dossier.png) |

| 3. Grounded Evidence & Actionable Fixes | 4. Live Benchmark & Creative Selection |
| :---: | :---: |
| ![Grounded Claims](docs/screenshots/03_grounded_claims.png) | ![Audit Configuration](docs/screenshots/05_audit_configuration.png) |

---

## 🎯 The Problem

> *"An ad promises same-day approval. The landing page it points to never mentions approval times. The click costs full price, the visitor bounces, and the conversion rate quietly sits at half what it should for weeks before anyone spots the disconnect."*

Online advertisers waste millions driving high-cost paid traffic to landing pages that fail to substantiate the advertisement's initial promises. **AdMatch AI** provides continuous, automated message-match auditing by extracting advertising claims, inspecting destination landing pages, validating evidence with zero hallucinations, and delivering specific, quotable fixes.

---

## 🏗️ System Architecture

AdMatch AI welds **local embedding search (`all-MiniLM-L6-v2`)**, **deterministic offer verification rules**, **visual alignment (`CLIP`)**, and **DOM position awareness** into a zero-hallucination auditor.

```mermaid
flowchart TD
    subgraph Inputs ["1. Multimodal Inputs"]
        A1[Ad Headline & Description]
        A2[Landing Page URL / Offline Snapshot]
        A3[Ad Creative Banner Image]
    end

    subgraph Ingestion ["2. Ingestion & Security"]
        B1[SSRF Defense Validator<br/>Blocks 127.0.0.1, RFC1918, Cloud Metadata]
        B2[EasyOCR Pipeline<br/>Extracts embedded text & promo offers]
        B3[DOM Parser & Section Tagger<br/>Hero | Headline | Body | Footer Fine-Print]
    end

    subgraph Processing ["3. Dual Verification Engine"]
        C1[Claim Chunker & Normalizer]
        C2[Semantic Vector Retrieval<br/>MiniLM-L6-v2 Cosine Similarity]
        C3[Deterministic Offer Engine<br/>Discounts %, Currencies $, Free Shipping, Trials]
        C4[Zero-Hallucination Grounding<br/>Verbatim Substring Proof Check]
        C5[Visual Alignment Engine<br/>CLIP ViT-B/32 Cosine Match]
    end

    subgraph Scoring ["4. Synthesis & Reporting"]
        D1[Position-Aware Heuristic Scorer<br/>Fine-Print Penalty Applied]
        D2[Executive Plain-English Summary<br/>Traffic Impact & Business Fixes]
        D3[Deep Technical Auditor Dossier<br/>Verbatim Citations & JSON Export]
    end

    A1 --> C1
    A2 --> B1 --> B3 --> C2
    A3 --> B2 --> C1
    A3 --> C5
    B3 --> C5
    C1 --> C2 --> C4 --> D1
    C1 --> C3 --> C4
    B3 --> D1
    C5 --> D1
    D1 --> D2
    D1 --> D3
```

---

## 🛡️ Core Defenses & Differentiators

### 1. Zero-Hallucination Grounding Guarantee
- **The Core Hackathon Test:** Standard generative LLMs frequently hallucinate content on pages they never actually read.
- **Our Defense:** Claims are matched against **raw DOM text nodes** extracted via `Trafilatura` and `BeautifulSoup4`. Every reported quotation is validated via exact substring presence verification before appearing in any report.

### 2. Position & Placement Awareness
- A promise buried in the footer fine print is **not** treated the same as a promise in the hero section.
- Content is segmented into:
  - `hero section` (highest weight)
  - `headline / H1-H3` (primary visual anchor)
  - `main_body` (standard supporting copy)
  - `footer / fine print` (triggers fine-print mismatch penalties)

### 3. Transparent Scoring Formula
Rather than an arbitrary LLM black-box rating, the text consistency score is calculated mathematically:

$$S_{\text{text}} = 100 \times \frac{\sum_{i=1}^N w_i \cdot s_i}{\sum_{i=1}^N w_i} - P_{\text{fine\_print}}$$

Where:
- $s_i \in \{1.0 \text{ (SUPPORTED)}, 0.4 \text{ (UNCERTAIN)}, 0.0 \text{ (UNSUPPORTED/CONTRADICTED)}\}$
- $w_i = 1.5$ for headline claims, $1.0$ for body claims.
- $P_{\text{fine\_print}} = 15\%$ penalty when key promises only appear in legal fine print.

### 4. Complete SSRF Protection
The URL scraping pipeline intercepts all network requests before transmission, proactively blocking:
- Loopback addresses (`127.0.0.1`, `localhost`, `::1`)
- RFC1918 private IP subnets (`10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`)
- Cloud instance metadata endpoints (`169.254.169.254`, `metadata.google.internal`)
- Unsafe redirect hopping.

---

## 🚀 Quick Setup & Installation

### Prerequisites
- Python 3.10 or 3.11 installed.
- Git (optional).
- Windows, macOS, or Linux.

### 1. Clone & Set Up Virtual Environment
```powershell
# In PowerShell (Windows)
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### 2. Install Dependencies
```powershell
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

### 3. Pre-Cache Open-Source AI Models (100% Offline Capable)
Pre-cache all weights locally so live audits require zero external downloads:
```powershell
python scripts\download_models.py
```
*Cached Models:*
- `sentence-transformers/all-MiniLM-L6-v2` (~80 MB)
- `openai/clip-vit-base-patch32` (~350 MB)
- `EasyOCR English weights` (~45 MB)

---

## 💻 Running the Application

### Option A: One-Click Windows Batch Launcher
Run both the backend and frontend simultaneously:
```powershell
.\run_local.bat
```

### Option B: Separate Terminal Launch
```powershell
# Terminal 1: FastAPI Backend
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000 --reload

# Terminal 2: Streamlit Dashboard UI
python -m streamlit run frontend/app.py
```

### Active Service Endpoints
- **Streamlit Web Dashboard:** [http://localhost:8501](http://localhost:8501)
- **FastAPI Interactive Docs (Swagger):** [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)
- **Backend Health Check:** [http://127.0.0.1:8000/health](http://127.0.0.1:8000/health)

---

## 🧪 Live Real-World Testing Guide

You can test AdMatch AI across three distinct modes:

### Mode 1: Benchmark Dataset (60 Pre-Loaded Pairs)
1. Open [http://localhost:8501](http://localhost:8501).
2. Expand the sidebar dropdown: **📂 Benchmark Dataset (60 Ads)**.
3. Select any campaign (e.g. `P01: Kestrel Business Funding`, `P09: Cobalt Line of Credit`, or `P25: SaaS Landing`).
4. Click **"🔍 Analyze Advertisement"** to test against the offline HTML snapshot bundle.

---

### Mode 2: Live Real-World URL Audits

#### Scenario A: High Consistency (E-Commerce Cashback / Coupons)
* **Landing Page URL:** `https://www.coupondunia.in`
* **Ad Headline:** `Save More Every Day`
* **Ad Description:** `Exclusive coupons, offers and cashback on your favorite online stores.`
* **Expected Result:** `100 / 100 (FULL MATCH)` with verbatim supporting quotes extracted directly from `main_body`.

#### Scenario B: Unsubstantiated Promotion Detection (Discrepancy Catch)
* **Landing Page URL:** `https://www.python.org`
* **Ad Headline:** `Python Programming Language: Fast, Friendly & Easy`
* **Ad Description:** `Work quickly and integrate systems more effectively. Get 90% instant discount on enterprise consulting.`
* **Expected Result:** Overall score ~`24 / 100`. Claim 3 flagged as `UNSUPPORTED`: *"The ad promises a specific discount (90%), but no verified promotional discount was found in page evidence."*

---

### Mode 3: Real-World Ad Banner Creative Testing (OCR + CLIP)
Real-world ad banner images from production CDNs are pre-downloaded in `sample_ad_creatives/`:
- `sample_ad_creatives/coupondunia_exclusive_deals.png`
- `sample_ad_creatives/coupondunia_buy_get_free.png`

**To test:**
1. Drag and drop `coupondunia_exclusive_deals.png` into the **Ad Creative Image** box in the UI.
2. Watch EasyOCR automatically extract:
   > *"Only on CouponDunia: Specially for you: Oyo PharmEasy COUPONS make trip drivezy & more .. SEE COUPONS EXCLUSIVE"*
3. Set URL to `https://www.coupondunia.in` and run the audit.

---

## 🔌 API Reference

### 1. `GET /health`
Returns system status and availability of local ML models.
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "features": {
    "semantic_text_matching": true,
    "clip_vision_matching": true,
    "easy_ocr": true
  }
}
```

### 2. `POST /api/audit` (Multipart Form)
Executes the full multimodal audit pipeline.
- **Parameters:**
  - `landing_page_url` (string, required)
  - `ad_headline` (string, optional)
  - `ad_description` (string, optional)
  - `ad_image` (file, optional)
- **Response Schema:**
  - `page`: Page metadata, headings, CTAs, extraction method.
  - `summary`: Heuristic text score (0-100), visual score, verdict (`FULL_MATCH`, `PARTIAL_MATCH`, `HIGH_MISMATCH`).
  - `claims`: Array of verified claims, verbatim quotes, section positions, confidence similarity, and concrete fixes.
  - `visual_matches`: Top matched page images with CLIP visual similarity scores.

### 3. `POST /api/ocr` (File Upload)
Extracts embedded promotional text and headline copy directly from an ad banner.

### 4. `POST /api/scrape` (JSON)
Diagnostic endpoint returning sanitized page text, headings, and CTAs.

---

## 🧪 Automated Test Suite

Run the full automated test suite:
```powershell
# Run PyTest unit tests
python -m pytest tests/ -v

# Run End-to-End integration smoke test
python scripts\e2e_smoke_test.py
```

### Verified Test Matrix
- ✅ `tests/test_scraper.py`: SSRF security validator, section segmentation, local snapshot loading.
- ✅ `tests/test_matcher.py`: Hyphen-safe chunking, decimal-safe sentence tokenization, deterministic offer verification.
- ✅ `tests/test_api.py`: FastAPI endpoints, status payloads, error handlers.
- ✅ `scripts/e2e_smoke_test.py`: 6/6 End-to-End real-world tests (Health, Snapshot scrape, Consistent campaign, Bait & switch contradiction, SSRF loopback defense, Live public URL fetch).

---

## 📁 Repository Structure

```
DEVSPRINT_HACKATHON/
├── backend/
│   ├── main.py                  # FastAPI server with /health, /api/audit, /api/ocr
│   ├── schemas.py               # Pydantic contracts & response models
│   ├── services/
│   │   ├── scraper.py           # DOM scraper, placement tagger & SSRF defense
│   │   ├── text_matcher.py      # MiniLM sentence embedding search
│   │   ├── claim_verifier.py    # Deterministic discount & currency rules
│   │   ├── image_matcher.py     # CLIP ViT-B/32 visual alignment
│   │   ├── ocr_service.py       # EasyOCR ad creative parser
│   │   └── report_service.py    # Heuristic score calculation
│   └── utils/
│       ├── text_cleaner.py      # Safe chunker & sentence boundary splitter
│       └── url_security.py      # SSRF firewall & private IP blocks
├── frontend/
│   └── app.py                   # Premium dual-view Streamlit SaaS dashboard
├── docs/
│   ├── admatch_demo_video.webp  # Browser walkthrough recording
│   └── screenshots/             # High-res UI documentation captures
├── sample_ad_creatives/         # Real-world banner images for OCR testing
├── PS-03_message_match_auditor/ # Official hackathon benchmark dataset & snapshots
├── scripts/
│   ├── download_models.py       # Offline model pre-cacher
│   └── e2e_smoke_test.py        # 6-step integration test runner
├── tests/                       # Complete PyTest test suite
├── run_local.bat                # Windows one-click launcher
└── requirements.txt             # Production dependency manifest
```

---

## 👥 Hackathon Team & Acknowledgments
- **Team:** NEXOVIAN
- **Hackathon:** DevSprint Hackathon
- **Problem Statement:** PS-03 — Ad-to-Landing-Page Message Match Auditor
