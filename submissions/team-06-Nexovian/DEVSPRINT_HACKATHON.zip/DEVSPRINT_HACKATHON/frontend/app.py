"""
AdMatch AI — Premium Advertising Message Match Auditor
Production SaaS Interface • Analytics & Compliance Intelligence Grade
"""
import io
import json
import streamlit as st
import requests
from PIL import Image

# Backend API Configuration
BACKEND_URL = "http://127.0.0.1:8000"

st.set_page_config(
    page_title="AdMatch AI — Advertising Message Match Auditor",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# SaaS Visual Direction: Off-white neutral backdrop, deep navy typography, restrained indigo accents
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        color: #0F172A;
    }
    
    /* Main App Header */
    .saas-header {
        border-bottom: 1px solid #E2E8F0;
        padding-bottom: 1.2rem;
        margin-bottom: 2rem;
    }
    .saas-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: #EEF2FF;
        color: #4F46E5;
        font-size: 0.8rem;
        font-weight: 700;
        padding: 4px 12px;
        border-radius: 9999px;
        border: 1px solid #C7D2FE;
        letter-spacing: 0.05em;
        text-transform: uppercase;
        margin-bottom: 0.6rem;
    }
    .saas-title {
        font-size: 2.25rem;
        font-weight: 800;
        color: #0F172A;
        letter-spacing: -0.025em;
        line-height: 1.2;
        margin-bottom: 0.4rem;
    }
    .saas-subtitle {
        font-size: 1.05rem;
        color: #64748B;
        max-width: 820px;
        line-height: 1.55;
    }
    
    /* Card Component */
    .saas-card {
        background: #FFFFFF;
        border: 1px solid #E2E8F0;
        border-radius: 12px;
        padding: 1.5rem;
        box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.05), 0 1px 2px -1px rgba(0, 0, 0, 0.05);
        margin-bottom: 1.5rem;
    }
    
    /* Metric Cards */
    .metric-container {
        background: #F8FAFC;
        border: 1px solid #E2E8F0;
        border-radius: 12px;
        padding: 1.25rem;
        text-align: left;
    }
    .metric-label {
        font-size: 0.85rem;
        font-weight: 600;
        color: #64748B;
        margin-bottom: 0.35rem;
    }
    .metric-value {
        font-size: 1.75rem;
        font-weight: 800;
        color: #0F172A;
        line-height: 1.1;
    }
    .metric-sub {
        font-size: 0.8rem;
        color: #94A3B8;
        margin-top: 0.25rem;
    }

    /* Badges */
    .status-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 20px;
        font-weight: 700;
        font-size: 0.8rem;
        letter-spacing: 0.02em;
    }
    .badge-supported { background: #ECFDF5; color: #059669; border: 1px solid #A7F3D0; }
    .badge-contradicted { background: #FEF2F2; color: #DC2626; border: 1px solid #FECACA; }
    .badge-unsupported { background: #FFFBEB; color: #D97706; border: 1px solid #FDE68A; }
    .badge-uncertain { background: #F8FAFC; color: #64748B; border: 1px solid #E2E8F0; }
    
    /* Evidence Quote Box */
    .evidence-box {
        background: #F8FAFC;
        border-left: 3px solid #4F46E5;
        border-top: 1px solid #E2E8F0;
        border-right: 1px solid #E2E8F0;
        border-bottom: 1px solid #E2E8F0;
        border-radius: 0 8px 8px 0;
        padding: 12px 16px;
        margin: 8px 0;
        font-style: normal;
        color: #1E293B;
        font-size: 0.92rem;
        line-height: 1.5;
    }
    .evidence-meta {
        font-size: 0.78rem;
        color: #6366F1;
        font-weight: 600;
        margin-top: 6px;
        display: flex;
        gap: 12px;
    }
</style>
""", unsafe_allow_html=True)

# -------------------------------------------------------------
# SIDEBAR: Presets, Benchmark Dataset & System Health
# -------------------------------------------------------------
with st.sidebar:
    st.markdown("### **AdMatch AI**")
    st.caption("v1.0.0 • Production Audit Suite")
    st.markdown("---")

    st.markdown("#### ⚡ Quick Demo Scenarios")
    col_p1, col_p2 = st.columns(2)
    if col_p1.button("🎯 Bait & Switch", use_container_width=True):
        st.session_state["headline"] = "Get 50% Off Everything Today!"
        st.session_state["description"] = "Shop our summer blowout sale. First-time buyers get half price."
        st.session_state["url"] = "PS-03_message_match_auditor/landing_page_snapshots/pair_01.html"

    if col_p2.button("👻 Ghost Offer", use_container_width=True):
        st.session_state["headline"] = "Free Express Shipping on All Orders"
        st.session_state["description"] = "Zero shipping fees guaranteed anywhere in the country."
        st.session_state["url"] = "PS-03_message_match_auditor/landing_page_snapshots/pair_01.html"

    if st.button("✅ Consistent Campaign", use_container_width=True):
        st.session_state["headline"] = "Rates starting at 6.9% APR • Decision Same Business Day"
        st.session_state["description"] = "Our online application takes about 10 minutes for qualified borrowers."
        st.session_state["url"] = "PS-03_message_match_auditor/landing_page_snapshots/pair_01.html"

    # Official PS-03 Benchmark Pairs (60 Ads)
    import os, csv
    csv_path = os.path.join("PS-03_message_match_auditor", "ads.csv")
    if os.path.exists(csv_path):
        st.markdown("---")
        st.markdown("#### 📂 Benchmark Dataset (60 Ads)")
        pairs_options = ["-- Select a Benchmark Pair --"]
        pairs_data = {}
        try:
            with open(csv_path, mode="r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    label = f"{row['pair_id']}: {row['advertiser']}"
                    pairs_options.append(label)
                    pairs_data[label] = row
            
            selected_pair = st.selectbox("Load Standardized Benchmark:", pairs_options, key="benchmark_select")
            if selected_pair != "-- Select a Benchmark Pair --":
                row = pairs_data[selected_pair]
                hl_parts = [row.get("headline_1", ""), row.get("headline_2", ""), row.get("headline_3", "")]
                st.session_state["headline"] = " • ".join([h.strip() for h in hl_parts if h.strip()])
                desc_parts = [row.get("description_1", ""), row.get("description_2", "")]
                st.session_state["description"] = " ".join([d.strip() for d in desc_parts if d.strip()])
                snapshot_rel = row.get("snapshot_file", "")
                st.session_state["url"] = os.path.join("PS-03_message_match_auditor", snapshot_rel).replace("\\", "/")
        except Exception:
            pass

    st.markdown("---")
    st.markdown("#### 🩺 Engine Status")
    try:
        health_resp = requests.get(f"{BACKEND_URL}/health", timeout=3)
        if health_resp.status_code == 200:
            h_data = health_resp.json()
            st.success("● Core Backend: Ready")
            st.caption(f"Semantic AI (MiniLM): {'✅ Ready' if h_data['features']['semantic_text_matching'] else '⚠️ Standby'}")
            st.caption(f"Vision AI (CLIP): {'✅ Ready' if h_data['features']['clip_vision_matching'] else '⚠️ Standby'}")
            st.caption(f"Ad OCR (EasyOCR): {'✅ Ready' if h_data['features']['easy_ocr'] else '⚠️ Standby'}")
        else:
            st.warning("⚠️ API Port Responding with Warning")
    except Exception:
        st.info("ℹ️ Local Engine Ready")

    st.markdown("---")
    st.caption("AdMatch AI • DevSprint Hackathon")

# -------------------------------------------------------------
# MAIN APP HEADER
# -------------------------------------------------------------
st.markdown("""
<div class="saas-header">
    <div class="saas-badge">🛡️ Message Match Intelligence</div>
    <div class="saas-title">Advertising Message Match</div>
    <div class="saas-subtitle">
        Audits whether an advertisement's promises (promotional discounts, product claims, calls-to-action, and visuals) 
        match the destination landing page. Backed by traceable on-page quotations and deterministic offer verification.
    </div>
</div>
""", unsafe_allow_html=True)

# -------------------------------------------------------------
# AUDIT INPUT PANEL
# -------------------------------------------------------------
st.markdown("### 1. Audit Parameters")

col_left, col_right = st.columns([1.1, 0.9], gap="large")

with col_left:
    ad_headline = st.text_input(
        "Advertisement Headline",
        value=st.session_state.get("headline", ""),
        placeholder="e.g. Rates From 6.9% APR • Apply in 10 Minutes"
    )
    ad_description = st.text_area(
        "Advertisement Description / Body Text",
        value=st.session_state.get("description", ""),
        height=105,
        placeholder="e.g. Simple online application, about 10 minutes. Rates starting at 6.9% APR."
    )
    landing_url = st.text_input(
        "Destination Landing Page URL",
        value=st.session_state.get("url", ""),
        placeholder="https://example.com/offer or local snapshot path"
    )

with col_right:
    st.markdown("**Advertisement Image (Optional Creative Upload)**")
    uploaded_image = st.file_uploader(
        "Upload Ad Creative Banner for OCR & CLIP Visual Audit",
        type=["png", "jpg", "jpeg", "webp"],
        help="Extracts promotional overlays via EasyOCR and scores visual alignment via CLIP ViT-B/32."
    )
    
    if uploaded_image:
        image_preview = Image.open(uploaded_image)
        st.image(image_preview, caption="Uploaded Ad Creative", use_container_width=True)

        # Auto-detect text with EasyOCR
        img_bytes = uploaded_image.getvalue()
        if st.session_state.get("last_uploaded_name") != uploaded_image.name:
            st.session_state["last_uploaded_name"] = uploaded_image.name
            with st.spinner("Extracting promotional text from image creative..."):
                from backend.services.ocr_service import extract_text_from_image
                extracted, _ = extract_text_from_image(img_bytes)
                if extracted:
                    if not st.session_state.get("headline"):
                        st.session_state["headline"] = extracted
                    st.session_state["ocr_detected"] = extracted
                    st.rerun()

        if st.session_state.get("ocr_detected"):
            st.success(f"**OCR Extracted:** \"{st.session_state['ocr_detected']}\"")

        col_img_btn1, col_img_btn2 = st.columns(2)
        if col_img_btn1.button("🔄 Re-Run OCR", use_container_width=True):
            from backend.services.ocr_service import extract_text_from_image
            extracted, _ = extract_text_from_image(img_bytes)
            if extracted:
                st.session_state["headline"] = extracted
                st.session_state["ocr_detected"] = extracted
                st.rerun()

        if col_img_btn2.button("❌ Remove Image", use_container_width=True):
            st.session_state.pop("last_uploaded_name", None)
            st.session_state.pop("ocr_detected", None)
            st.rerun()

# Execution Controls
st.markdown("")
btn_col1, btn_col2 = st.columns([0.8, 0.2])
with btn_col1:
    analyze_clicked = st.button("🔍 Analyze Advertisement", type="primary", use_container_width=True)
with btn_col2:
    if st.button("🔄 Reset Form", use_container_width=True):
        st.session_state["headline"] = ""
        st.session_state["description"] = ""
        st.session_state["url"] = ""
        st.session_state.pop("audit_result", None)
        st.session_state.pop("ocr_detected", None)
        st.session_state.pop("last_uploaded_name", None)
        st.rerun()

# -------------------------------------------------------------
# AUDIT EXECUTION ENGINE
# -------------------------------------------------------------
def execute_audit(headline, desc, url, img_file):
    """Executes audit with real progressive status and resilient fallback."""
    progress_bar = st.progress(0, text="Validating inputs and target destination...")

    # Validate inputs
    if not headline.strip() and not desc.strip() and not img_file:
        progress_bar.empty()
        return None, "Please provide an advertisement headline, description, or upload an image."
    if not url.strip():
        progress_bar.empty()
        return None, "Please provide a valid destination landing page URL."

    progress_bar.progress(25, text="Fetching landing page content and extracting DOM hierarchy...")

    # Attempt REST call to backend
    try:
        files = {}
        if img_file:
            img_file.seek(0)
            files["ad_image"] = (img_file.name, img_file.getvalue(), img_file.type or "image/jpeg")
        
        data = {
            "ad_headline": headline or "",
            "ad_description": desc or "",
            "landing_page_url": url
        }
        progress_bar.progress(60, text="Running MiniLM semantic search & deterministic verification rules...")
        res = requests.post(f"{BACKEND_URL}/api/audit", data=data, files=files, timeout=30)
        progress_bar.progress(90, text="Synthesizing consistency scores and report dossier...")
        if res.status_code == 200:
            progress_bar.progress(100, text="Audit Complete!")
            progress_bar.empty()
            return res.json(), None
    except Exception:
        pass

    # Direct engine fallback
    try:
        from backend.services.scraper import scrape_landing_page
        from backend.services.ocr_service import extract_text_from_image
        from backend.services.text_matcher import match_claim
        from backend.services.claim_verifier import verify_claim
        from backend.services.image_matcher import match_images
        from backend.services.report_service import synthesize_report
        from backend.utils.text_cleaner import extract_claims
        from backend.schemas import ClaimAudit, EvidenceItem

        page_data = scrape_landing_page(url, allow_local_for_testing=True)
        ocr_text = ""
        if img_file:
            ocr_text, _ = extract_text_from_image(img_file.getvalue())

        progress_bar.progress(70, text="Evaluating claims against retrieved page evidence...")
        claims_list = extract_claims(headline, desc, ocr_text)
        if not claims_list and ocr_text:
            claims_list = [ocr_text.strip()]
        if not claims_list:
            claims_list = [headline.strip()] if headline.strip() else ["General Proposition"]

        verified_claims = []
        s_sources = page_data.get("sentence_sources", {})
        for c in claims_list:
            ev_raw = match_claim(c, page_data.get("paragraphs", []), top_k=3, sentence_sources=s_sources)
            v_res = verify_claim(c, ev_raw)
            verified_claims.append(ClaimAudit(
                claim=v_res["claim"],
                status=v_res["status"],
                evidence=[EvidenceItem(text=e["evidence"], source=e.get("source", "main_body"), similarity=e["similarity"]) for e in v_res.get("evidence", [])],
                reason=v_res["reason"],
                suggestion=v_res["suggestion"],
                category=v_res.get("category", "general")
            ))

        v_score = None
        v_matches_formatted = []
        if img_file:
            v_score, v_matches, _ = match_images(img_file.getvalue(), page_data.get("images", []))
            v_matches_formatted = [
                {"image_url": vm["image_url"], "similarity": vm["similarity"], "alt_text": vm.get("alt_text")}
                for vm in v_matches
            ]

        summary = synthesize_report(verified_claims, visual_score=v_score)
        progress_bar.progress(100, text="Audit Complete!")
        progress_bar.empty()
        return {
            "page": page_data,
            "summary": summary.model_dump(),
            "claims": [c.model_dump() for c in verified_claims],
            "ocr_extracted_text": ocr_text,
            "visual_matches": v_matches_formatted,
            "warnings": page_data.get("warnings", [])
        }, None
    except Exception as err:
        progress_bar.empty()
        return None, f"Audit processing error: {err}"

if analyze_clicked:
    result, error = execute_audit(ad_headline, ad_description, landing_url, uploaded_image)
    if error:
        st.error(f"❌ {error}")
    elif result:
        st.session_state["audit_result"] = result

# -------------------------------------------------------------
# RESULTS DASHBOARD
# -------------------------------------------------------------
if st.session_state.get("audit_result"):
    result = st.session_state["audit_result"]
    summary = result["summary"]
    page = result["page"]
    claims = result["claims"]
    warnings = result.get("warnings", [])

    st.markdown("---")
    st.markdown("### 2. Consistency Audit Dossier")

    # High-Level Metric Tiles
    m_col1, m_col2, m_col3, m_col4 = st.columns(4)
    
    status_badges = {
        "FULL_MATCH": ("🟢 FULL MATCH", "Consistent with destination content"),
        "PARTIAL_MATCH": ("🟡 PARTIAL MATCH", "Some offers or claims unconfirmed"),
        "HIGH_MISMATCH": ("🔴 HIGH MISMATCH", "Contradictory offers detected"),
        "INSUFFICIENT_EVIDENCE": ("⚪ INSUFFICIENT PROOF", "Page lacks substantiating text")
    }
    badge_label, badge_desc = status_badges.get(summary['overall_status'], (summary['overall_status'], ""))

    with m_col1:
        st.markdown(f"""
        <div class="metric-container">
            <div class="metric-label">OVERALL MATCH SCORE</div>
            <div class="metric-value">{summary['text_score']}<span style="font-size:1.1rem; color:#94A3B8;">/100</span></div>
            <div class="metric-sub">{summary['supported_count']} of {summary['total_claims']} promises confirmed</div>
        </div>
        """, unsafe_allow_html=True)

    with m_col2:
        st.markdown(f"""
        <div class="metric-container">
            <div class="metric-label">CONSISTENCY STATUS</div>
            <div class="metric-value" style="font-size:1.35rem;">{badge_label}</div>
            <div class="metric-sub">{badge_desc}</div>
        </div>
        """, unsafe_allow_html=True)

    with m_col3:
        v_disp = f"{summary['visual_score']}/100" if summary.get('visual_score') is not None else "Not analyzed"
        st.markdown(f"""
        <div class="metric-container">
            <div class="metric-label">VISUAL ALIGNMENT (CLIP)</div>
            <div class="metric-value" style="font-size:1.45rem;">{v_disp}</div>
            <div class="metric-sub">Creative vs. Landing Page Images</div>
        </div>
        """, unsafe_allow_html=True)

    with m_col4:
        st.markdown(f"""
        <div class="metric-container">
            <div class="metric-label">PAGE EXTRACTION</div>
            <div class="metric-value" style="font-size:1.35rem;">{page.get('character_count', 0)} chars</div>
            <div class="metric-sub">Engine: {page.get('extraction_method', 'requests')}</div>
        </div>
        """, unsafe_allow_html=True)

    # Score calculation explanation
    with st.expander("ℹ️ How the Message Match Score is Calculated"):
        st.markdown("""
        **Transparent Heuristic Scoring Model:**
        $$\\text{Score} = 100 \\times \\frac{\\sum w_i \\cdot s_i}{\\sum w_i}$$
        - **Status Values ($s_i$):** `SUPPORTED` = 1.0 • `UNCERTAIN` = 0.45 • `UNSUPPORTED` = 0.15 • `CONTRADICTED` = 0.0
        - **Weights ($w_i$):** Numerical offers, pricing, and discount claims are weighted at **1.5×** importance; general product features at **1.0×**.
        - *Note: This is an AI-assisted heuristic audit, not a legal compliance determination.*
        """)

    # Dual-View Presentation: Plain-English vs Deep Auditor Dossier
    tab_plain, tab_deep = st.tabs([
        "✨ Plain-English Summary (Executive View)",
        "🔬 Deep Technical Dossier (Auditor View)"
    ])

    with tab_plain:
        if summary['overall_status'] == "FULL_MATCH":
            st.success("### 🎉 High Customer Trust\nEverything promised in your advertisement is clearly verified on the landing page. Visitors will find what they clicked for.")
        elif summary['overall_status'] == "HIGH_MISMATCH":
            st.error("### 🚨 Warning: Message Mismatch Detected\nThe landing page contradicts key promises made in your ad (e.g. discount numbers or pricing do not agree). High bounce risk.")
        elif summary['overall_status'] == "PARTIAL_MATCH":
            st.warning("### ⚠️ Partial Promise Match\nSome parts of your advertisement match the page, but key offers are missing or ambiguous.")
        else:
            st.info("### ℹ️ Insufficient Page Evidence\nThe landing page lacks sufficient textual proof to verify the advertisement's claims.")

        st.markdown("#### What You Promised vs. What Visitors Find:")
        for idx, c in enumerate(claims):
            icon = "✅" if c['status'] == "SUPPORTED" else ("❌" if c['status'] == "CONTRADICTED" else "⚠️")
            col_p_left, col_p_right = st.columns([0.45, 0.55])
            with col_p_left:
                st.markdown(f"**{icon} Ad Promise #{idx+1}:**")
                st.markdown(f"> **\"{c['claim']}\"**")
            with col_p_right:
                if c['status'] == "SUPPORTED":
                    st.markdown("**What Visitors Find:**")
                    st.caption(f"Confirmed: {c['reason']}")
                elif c['status'] == "CONTRADICTED":
                    st.markdown("**What Visitors Find Instead:**")
                    st.markdown(f"<span style='color:#DC2626; font-weight:600;'>{c['reason']}</span>", unsafe_allow_html=True)
                else:
                    st.markdown("**What Visitors Find:**")
                    st.caption(f"Missing: {c['reason']}")
                st.markdown(f"👉 **Action Item:** {c['suggestion']}")
            st.divider()

    with tab_deep:
        st.markdown("#### Sentence-Level Evidence & Deterministic Rule Verification")
        for idx, c in enumerate(claims):
            badge_class = f"badge-{c['status'].lower()}"
            with st.expander(f"Claim #{idx+1}: \"{c['claim']}\" — {c['status']}", expanded=True):
                col_d1, col_d2 = st.columns([0.65, 0.35])
                with col_d1:
                    st.markdown(f"**Verdict:** <span class='status-badge {badge_class}'>{c['status']}</span>", unsafe_allow_html=True)
                    st.markdown(f"**Rationale:** {c['reason']}")
                    st.markdown(f"**Recommendation:** `{c['suggestion']}`")

                    if c.get("evidence"):
                        st.markdown("**Retrieved On-Page Quotes:**")
                        for ev in c["evidence"]:
                            st.markdown(f"""
                            <div class="evidence-box">
                                "{ev['text']}"
                                <div class="evidence-meta">
                                    <span>Semantic Alignment: <b>{round(ev['similarity'] * 100, 1)}%</b></span>
                                    <span>Location: <b>{ev.get('source', 'main body')}</b></span>
                                </div>
                            </div>
                            """, unsafe_allow_html=True)
                    else:
                        st.caption("No relevant textual quotes found on destination page.")

                with col_d2:
                    st.markdown(f"**Category:** `{c.get('category', 'general')}`")
                    if c['status'] == "SUPPORTED":
                        st.success("Fulfilled by destination content.")
                    elif c['status'] == "CONTRADICTED":
                        st.error("Contradiction detected.")
                    elif c['status'] == "UNSUPPORTED":
                        st.warning("Missing on-page evidence.")
                    else:
                        st.info("Ambiguous context.")

    # Visual Alignment Gallery
    visual_matches = result.get("visual_matches", [])
    page_imgs = page.get("images", [])
    if uploaded_image or visual_matches or page_imgs:
        st.markdown("---")
        st.markdown("### 🖼️ Visual Alignment Gallery")
        v_col1, v_col2 = st.columns([0.4, 0.6], gap="large")
        with v_col1:
            st.markdown("**Uploaded Advertisement Creative**")
            if uploaded_image:
                st.image(uploaded_image, caption="Ad Creative (Input)", use_container_width=True)
                if result.get("ocr_extracted_text"):
                    st.info(f"**OCR Extracted Copy:** \"{result['ocr_extracted_text']}\"")
            else:
                st.info("No ad creative image uploaded for this audit run.")

        with v_col2:
            st.markdown("**Destination Page Extracted Images & CLIP Matching**")
            if visual_matches:
                st.caption("Ranked by CLIP ViT-B/32 Visual Cosine Similarity:")
                grid_cols = st.columns(min(len(visual_matches), 3))
                for idx, vm in enumerate(visual_matches[:3]):
                    with grid_cols[idx]:
                        st.image(vm["image_url"], use_container_width=True)
                        st.markdown(f"<span class='status-badge badge-supported'>{round(vm['similarity'] * 100, 1)}% Match</span>", unsafe_allow_html=True)
                        if vm.get("alt_text"):
                            st.caption(f"_{vm['alt_text']}_")
            elif page_imgs:
                st.caption("Extracted Page Imagery (No ad image uploaded to compute similarity):")
                grid_cols = st.columns(min(len(page_imgs), 3))
                for idx, pi in enumerate(page_imgs[:3]):
                    with grid_cols[idx]:
                        st.image(pi["url"], use_container_width=True)
                        if pi.get("alt"):
                            st.caption(f"_{pi['alt']}_")
            else:
                st.caption("No suitable hero or product images found on destination page.")

    # Page Metadata Summary
    with st.expander("📄 Landing Page Extracted Data Details"):
        st.write(f"**Page Title:** {page.get('title')}")
        st.write(f"**Final Destination:** {page.get('final_url')}")
        st.write(f"**Extraction Engine:** `{page.get('extraction_method', 'requests')}`")
        if page.get("headings"):
            st.write("**Extracted Headings:**", page["headings"])
        if page.get("ctas"):
            st.write("**Extracted CTAs & Buttons:**", page["ctas"])

    # Warnings section
    if warnings:
        st.markdown("---")
        st.markdown("#### ⚠️ Audit Diagnostic Warnings")
        for w in warnings:
            st.warning(f"• {w}")

    # Export Dossier
    st.markdown("---")
    col_exp1, col_exp2 = st.columns(2)
    with col_exp1:
        json_data = json.dumps(result, indent=2)
        st.download_button(
            label="📥 Download JSON Audit Report",
            data=json_data,
            file_name="admatch_ai_audit_report.json",
            mime="application/json",
            use_container_width=True
        )
    with col_exp2:
        # Quick summary text copy
        summary_text = f"AdMatch AI Audit Summary\nStatus: {summary['overall_status']}\nScore: {summary['text_score']}/100\nTotal Claims: {summary['total_claims']} ({summary['supported_count']} supported, {summary['contradicted_count']} contradicted)\nURL: {page.get('final_url')}"
        st.download_button(
            label="📋 Download Text Summary",
            data=summary_text,
            file_name="admatch_ai_summary.txt",
            mime="text/plain",
            use_container_width=True
        )
