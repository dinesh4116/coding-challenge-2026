@echo off
echo ========================================================
echo        Starting AdMatch AI Local Environment
echo ========================================================

if exist .venv\Scripts\activate.bat (
    call .venv\Scripts\activate.bat
) else (
    echo Note: .venv not found, using system Python.
)

echo Starting FastAPI Backend on http://127.0.0.1:8000 ...
start "AdMatch AI - FastAPI Backend" cmd /k "python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000 --reload"

timeout /t 3 >nul

echo Starting Streamlit Dashboard on http://localhost:8501 ...
start "AdMatch AI - Streamlit Dashboard" cmd /k "python -m streamlit run frontend/app.py"

echo.
echo AdMatch AI is launching!
echo Backend Docs: http://127.0.0.1:8000/docs
echo Streamlit UI: http://localhost:8501
echo ========================================================
pause
