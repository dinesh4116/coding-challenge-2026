# AdMatch AI — Open-Source Models & Pipeline Setup Guide

**Architecture Focus:** Zero-crash, resilient local AI execution on Windows (Python 3.11).  
This guide details how to install, cache, and integrate open-source models into **AdMatch AI** without runtime download freezes or memory crashes during a live hackathon presentation.

---

## 1. Selected Open-Source Models Overview

| Model | Size | Purpose | Primary Library | Runtime Profile | Fallback Behavior |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **`all-MiniLM-L6-v2`** | ~80 MB | Semantic sentence-level evidence retrieval | `sentence-transformers` | < 15ms per claim on CPU | Lexical BM25 / Jaccard string similarity |
| **`clip-vit-base-patch32`** | ~350 MB | Ad image vs. Landing-page image visual similarity | `transformers` (HuggingFace) / `open_clip_torch` | ~150ms on CPU | Returns `visual_score: null` with warning, continues text audit |
| **`EasyOCR`** | ~80 MB | Text extraction from ad creative banners | `easyocr` (PyTorch CRAFT + Recognition) | ~300ms on CPU | Graceful warning: uses user headline & description |

> **Key Design Rule:** Text matching is the foundational core. The system **never** crashes if an image model or OCR fails to load; it cleanly reports what was audited and flags what was skipped.

---

## 2. Step-by-Step Environment Setup

### Step 2.1: Create & Activate Virtual Environment
Open PowerShell or Command Prompt in `f:\Coding\Events\DEVSPRINT_HACKATHON`:

```powershell
# Create isolated Python virtual environment
python -m venv .venv

# Activate in PowerShell
.\.venv\Scripts\Activate.ps1

# (If PowerShell execution policy restricts scripts, run:
# Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope Process)

# Or in standard Command Prompt:
# .venv\Scripts\activate.bat
```

### Step 2.2: Install Core Dependencies
Upgrade pip and install the core framework packages first:

```powershell
python -m pip install --upgrade pip

# Install FastAPI, Scraper, Streamlit, and Core Text AI
python -m pip install fastapi uvicorn streamlit requests beautifulsoup4 trafilatura sentence-transformers scikit-learn pillow pandas python-multipart pytest
```

### Step 2.3: (Optional) Install Vision & OCR Modules
When you are ready to enable visual matching and ad creative OCR:

```powershell
# Install PyTorch CPU (lightweight ~180MB compared to CUDA's 2GB+)
python -m pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu

# Install HuggingFace transformers and EasyOCR
python -m pip install transformers easyocr
```

### Step 2.4: (Optional) Install Playwright for JS Rendering Fallback
If you wish to scrape client-side JavaScript sites (SPAs, React, Next.js):

```powershell
python -m pip install playwright
python -m playwright install chromium
```

---

## 3. Pre-Downloading Models (Offline Demo Preparation)

During a live presentation, you must **never** let the backend download weights from Hugging Face on request. We provide a pre-caching script: `scripts/download_models.py`.

### Script: `scripts/download_models.py`
```python
"""
Pre-download and cache model weights into the local HuggingFace cache directory.
Run once before the hackathon demo.
"""
import os
import sys

def cache_models():
    print("[1/3] Caching sentence-transformers/all-MiniLM-L6-v2...")
    try:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
        print(" -> MiniLM-L6-v2 successfully cached!")
    except Exception as e:
        print(f" -> Failed to cache MiniLM: {e}", file=sys.stderr)

    print("\n[2/3] Caching CLIP Vision Model (openai/clip-vit-base-patch32)...")
    try:
        from transformers import CLIPProcessor, CLIPModel
        CLIPModel.from_pretrained("openai/clip-vit-base-patch32")
        CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")
        print(" -> CLIP model successfully cached!")
    except Exception as e:
        print(f" -> CLIP skipped/failed: {e}")

    print("\n[3/3] Initializing EasyOCR English reader...")
    try:
        import easyocr
        reader = easyocr.Reader(['en'], gpu=False)
        print(" -> EasyOCR successfully cached!")
    except Exception as e:
        print(f" -> EasyOCR skipped/failed: {e}")

    print("\n[DONE] Model cache process complete.")

if __name__ == "__main__":
    cache_models()
```

Run this script once:
```powershell
python scripts\download_models.py
```

---

## 4. Zero-Crash Pipeline Integration Architecture

To ensure the backend never stalls or throws 500 errors, we use the **Lazy Singleton Pattern with Feature Flags**.

```mermaid
flowchart TD
    Req[POST /api/audit] --> Pipe[Pipeline Dispatcher]
    
    Pipe --> TextEngine[Text Matching Engine]
    TextEngine --> LMCheck{MiniLM Loaded?}
    LMCheck -- Yes --> MiniLM[MiniLM Semantic Embedding]
    LMCheck -- No / CPU Fallback --> BM25[Lexical Fallback Matcher]
    MiniLM --> Verifier[Deterministic Claim Verifier]
    BM25 --> Verifier
    
    Pipe --> VisionEngine{Ad Image Uploaded?}
    VisionEngine -- Yes --> CLIPCheck{CLIP Available?}
    VisionEngine -- No --> SkipVision[Set visual_score = null]
    
    CLIPCheck -- Yes --> CLIP[CLIP Cosine Matrix]
    CLIPCheck -- No --> ClipWarn[Add Warning: Vision Model Inactive]
    
    CLIP --> Merger[Report Synthesis Engine]
    ClipWarn --> Merger
    SkipVision --> Merger
    Verifier --> Merger
    
    Merger --> Dossier[Structured Audit Dossier]
```

### 4.1 Lazy Singleton Implementation (`backend/services/text_matcher.py`)
```python
_mini_lm_instance = None

def get_text_model():
    global _mini_lm_instance
    if _mini_lm_instance is None:
        try:
            from sentence_transformers import SentenceTransformer
            _mini_lm_instance = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
        except Exception as e:
            # Fallback to None if torch is not installed
            _mini_lm_instance = "FALLBACK"
    return _mini_lm_instance
```

### 4.2 Safe Vision Loader (`backend/services/image_matcher.py`)
```python
_clip_model = None
_clip_processor = None

def get_clip_engine():
    global _clip_model, _clip_processor
    if _clip_model is None:
        try:
            from transformers import CLIPProcessor, CLIPModel
            _clip_model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32")
            _clip_processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")
        except Exception:
            return None, None
    return _clip_model, _clip_processor
```

---

## 5. Verification & Health Check Procedure

To verify all components prior to running the demo:

1. **Verify Backend**:
   ```powershell
   python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
   ```
   Navigate to `http://127.0.0.1:8000/health`. It returns:
   ```json
   {
     "status": "healthy",
     "models": {
       "miniLM": true,
       "clip": true,
       "ocr": true
     }
   }
   ```

2. **Verify Streamlit Frontend**:
   ```powershell
   python -m streamlit run frontend/app.py
   ```
   Opens browser at `http://localhost:8501` and connects seamlessly to the FastAPI backend.

3. **Verify Automated Tests**:
   ```powershell
   python -m pytest tests/ -v
   ```
   Validates scraper parsing, SSRF URL blocks, contradictory discount calculations, and audit responses using offline fixtures.
