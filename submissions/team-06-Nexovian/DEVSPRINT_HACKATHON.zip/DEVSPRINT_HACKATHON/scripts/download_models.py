"""
AdMatch AI — Model Pre-caching Script
Run this script in advance to download and cache open-source weights locally
so your live demo never stalls or requires internet downloads.
"""
import sys

def cache_models():
    print("=" * 60)
    print("  AdMatch AI: Downloading & Caching Open-Source Models")
    print("=" * 60)

    # 1. MiniLM-L6-v2 Semantic Embeddings (~80 MB)
    print("\n[1/3] Caching sentence-transformers/all-MiniLM-L6-v2 ...")
    try:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
        # Quick sanity check
        _ = model.encode(["AdMatch AI semantic test"], normalize_embeddings=True)
        print(" [SUCCESS] MiniLM-L6-v2 cached and ready!")
    except ImportError:
        print(" [SKIP/NOTE] sentence-transformers not installed yet. Run: pip install sentence-transformers")
    except Exception as e:
        print(f" [ERROR] Could not cache MiniLM: {e}", file=sys.stderr)

    # 2. CLIP Vision Model (~350 MB)
    print("\n[2/3] Caching CLIP Vision Model (openai/clip-vit-base-patch32) ...")
    try:
        from transformers import CLIPProcessor, CLIPModel
        CLIPModel.from_pretrained("openai/clip-vit-base-patch32")
        CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")
        print(" [SUCCESS] CLIP ViT-B/32 cached and ready!")
    except ImportError:
        print(" [SKIP/NOTE] transformers not installed yet. Run: pip install transformers")
    except Exception as e:
        print(f" [NOTE] CLIP download deferred: {e}")

    # 3. EasyOCR (~80 MB)
    print("\n[3/3] Initializing EasyOCR Reader ...")
    try:
        import easyocr
        _ = easyocr.Reader(['en'], gpu=False)
        print(" [SUCCESS] EasyOCR models cached and ready!")
    except ImportError:
        print(" [SKIP/NOTE] easyocr not installed yet. Run: pip install easyocr")
    except Exception as e:
        print(f" [NOTE] EasyOCR initialization deferred: {e}")

    print("\n" + "=" * 60)
    print("  Model caching complete!")
    print("=" * 60)

if __name__ == "__main__":
    cache_models()
