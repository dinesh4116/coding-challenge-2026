"""
AdMatch AI — End-to-End Automated Integration Smoke Test
Tests backend /health, /api/scrape, /api/audit, SSRF blocking, and claim verification.
"""
import sys
import os
import requests

BACKEND_URL = "http://127.0.0.1:8000"

def run_smoke_test():
    print("=" * 65)
    print("  AdMatch AI — Production End-to-End Smoke Test")
    print("=" * 65)
    passed_checks = 0
    total_checks = 6

    # 1. Health Check
    print("\n[Check 1/6] Testing GET /health endpoint...")
    try:
        r = requests.get(f"{BACKEND_URL}/health", timeout=5)
        assert r.status_code == 200, f"Expected 200, got {r.status_code}"
        h_data = r.json()
        assert h_data["status"] == "healthy"
        print(f" [PASS] Backend is online. Features: {h_data['features']}")
        passed_checks += 1
    except Exception as e:
        print(f" [FAIL] Health check failed: {e}", file=sys.stderr)
        return False

    # 2. Local Snapshot Scraping
    print("\n[Check 2/6] Testing POST /api/scrape with local fixture...")
    snapshot_path = "PS-03_message_match_auditor/landing_page_snapshots/pair_01.html"
    try:
        r = requests.post(f"{BACKEND_URL}/api/scrape", json={"url": snapshot_path}, timeout=5)
        assert r.status_code == 200, f"Expected 200, got {r.status_code}"
        sc_data = r.json()
        assert sc_data["success"] is True
        assert "Kestrel" in sc_data["page"]["title"]
        print(f" [PASS] Page scraped successfully: \"{sc_data['page']['title']}\"")
        passed_checks += 1
    except Exception as e:
        print(f" [FAIL] Scrape test failed: {e}", file=sys.stderr)

    # 3. Full Audit - Supported Claim Scenario
    print("\n[Check 3/6] Testing POST /api/audit with consistent ad copy...")
    try:
        data = {
            "ad_headline": "Rates starting at 6.9% APR • Apply in 10 Minutes",
            "ad_description": "Decision the same business day for qualified borrowers.",
            "landing_page_url": snapshot_path
        }
        r = requests.post(f"{BACKEND_URL}/api/audit", data=data, timeout=15)
        assert r.status_code == 200, f"Expected 200, got {r.status_code}"
        audit_res = r.json()
        assert len(audit_res["claims"]) >= 2
        statuses = [c["status"] for c in audit_res["claims"]]
        assert "SUPPORTED" in statuses, f"Expected SUPPORTED claim, got {statuses}"
        print(f" [PASS] Audit returned {len(audit_res['claims'])} claims. Overall Score: {audit_res['summary']['text_score']}/100")
        passed_checks += 1
    except Exception as e:
        print(f" [FAIL] Audit supported check failed: {e}", file=sys.stderr)

    # 4. Full Audit - Contradiction / Unsupported Scenario
    print("\n[Check 4/6] Testing POST /api/audit with contradictory offer...")
    try:
        data = {
            "ad_headline": "Get 90% Off Everything Today • Free International Shipping",
            "ad_description": "Exclusive blowout discounts for all shoppers.",
            "landing_page_url": snapshot_path
        }
        r = requests.post(f"{BACKEND_URL}/api/audit", data=data, timeout=15)
        assert r.status_code == 200, f"Expected 200, got {r.status_code}"
        audit_res = r.json()
        discount_claim = next((c for c in audit_res["claims"] if "90%" in c["claim"]), None)
        assert discount_claim is not None
        assert discount_claim["status"] in ("UNSUPPORTED", "CONTRADICTED")
        print(f" [PASS] Contradictory offer correctly identified as: {discount_claim['status']}")
        passed_checks += 1
    except Exception as e:
        print(f" [FAIL] Contradiction check failed: {e}", file=sys.stderr)

    # 5. Security & SSRF Defense Enforcement
    print("\n[Check 5/6] Testing SSRF Defense on forbidden destination (127.0.0.1)...")
    try:
        data = {
            "ad_headline": "Test Ad",
            "ad_description": "Test Description",
            "landing_page_url": "http://127.0.0.1:8000/internal-admin"
        }
        r = requests.post(f"{BACKEND_URL}/api/audit", data=data, timeout=5)
        assert r.status_code == 400, f"Expected HTTP 400, got {r.status_code}"
        assert "SSRF" in r.text or "blocked" in r.text or "prohibited" in r.text
        print(" [PASS] SSRF destination safely blocked with HTTP 400.")
        passed_checks += 1
    except Exception as e:
        print(f" [FAIL] SSRF defense check failed: {e}", file=sys.stderr)

    # 6. Live Public Web Fetch Test
    print("\n[Check 6/6] Testing live public URL fetch (https://example.com)...")
    try:
        data = {
            "ad_headline": "Example Domain Information Service",
            "ad_description": "This domain is established to be used for illustrative examples.",
            "landing_page_url": "https://example.com"
        }
        r = requests.post(f"{BACKEND_URL}/api/audit", data=data, timeout=15)
        if r.status_code == 200:
            live_res = r.json()
            assert "Example Domain" in live_res["page"]["title"]
            print(f" [PASS] Live public URL fetched and audited successfully! Title: \"{live_res['page']['title']}\"")
            passed_checks += 1
        else:
            print(f" [NOTE] Live fetch returned status {r.status_code}: {r.text}")
    except Exception as e:
        print(f" [NOTE] Live public network request note: {e}")

    print("\n" + "=" * 65)
    print(f"  SMOKE TEST RESULT: {passed_checks}/{total_checks} CHECKS PASSED")
    print("=" * 65)
    return passed_checks >= 5

if __name__ == "__main__":
    success = run_smoke_test()
    sys.exit(0 if success else 1)
