"""
AdMatch AI — Pydantic Schemas for API Contracts
"""
from typing import List, Optional, Dict, Any
from enum import Enum
from pydantic import BaseModel, Field, HttpUrl

class ClaimStatus(str, Enum):
    SUPPORTED = "SUPPORTED"
    CONTRADICTED = "CONTRADICTED"
    UNSUPPORTED = "UNSUPPORTED"
    UNCERTAIN = "UNCERTAIN"

class OverallStatus(str, Enum):
    FULL_MATCH = "FULL_MATCH"
    PARTIAL_MATCH = "PARTIAL_MATCH"
    HIGH_MISMATCH = "HIGH_MISMATCH"
    INSUFFICIENT_EVIDENCE = "INSUFFICIENT_EVIDENCE"

class EvidenceItem(BaseModel):
    text: str = Field(..., description="Exact quoted sentence from landing page")
    source: str = Field(default="main_text", description="HTML element or document section")
    similarity: float = Field(..., description="Semantic cosine similarity (MiniLM)")

class ClaimAudit(BaseModel):
    claim: str = Field(..., description="The advertisement claim being verified")
    status: ClaimStatus = Field(..., description="Verification verdict based on deterministic & evidence rules")
    evidence: List[EvidenceItem] = Field(default_factory=list, description="Top evidence candidates")
    reason: str = Field(..., description="Evidence-backed rationale for the verdict")
    suggestion: str = Field(..., description="Actionable recommendation for ad or landing page copy")
    category: Optional[str] = Field(default="general", description="e.g. discount, price, shipping, feature")

class ImageMatch(BaseModel):
    image_url: str = Field(..., description="Landing page image source URL")
    similarity: float = Field(..., description="CLIP cosine visual similarity score")
    alt_text: Optional[str] = Field(default=None, description="Image alt text if available")

class PageInfo(BaseModel):
    url: str
    final_url: str
    title: str
    meta_description: Optional[str] = None
    headings: List[str] = Field(default_factory=list)
    ctas: List[str] = Field(default_factory=list)
    extraction_method: str = Field(default="requests", description="'requests' or 'playwright_fallback'")
    character_count: int = 0

class AuditSummary(BaseModel):
    text_score: int = Field(..., ge=0, le=100, description="Heuristic claim consistency score (0-100)")
    visual_score: Optional[int] = Field(default=None, ge=0, le=100, description="CLIP visual score or null")
    overall_status: OverallStatus
    total_claims: int
    supported_count: int
    contradicted_count: int
    unsupported_count: int
    uncertain_count: int

class AuditResponse(BaseModel):
    page: PageInfo
    summary: AuditSummary
    claims: List[ClaimAudit]
    ocr_extracted_text: Optional[str] = None
    visual_matches: List[ImageMatch] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)

class ScrapeRequest(BaseModel):
    url: str

class ScrapeResponse(BaseModel):
    success: bool
    page: Optional[PageInfo] = None
    sample_text: Optional[str] = None
    warnings: List[str] = Field(default_factory=list)
    error: Optional[str] = None

class HealthResponse(BaseModel):
    status: str
    version: str
    features: Dict[str, bool]
