"""
AdMatch AI — Text Cleaning, Sentence Splitting & Claim Chunking
"""
import re
import html
from typing import List

def clean_text(text: str) -> str:
    """Normalize whitespace and unescape HTML entities."""
    if not text:
        return ""
    text = html.unescape(text)
    # Replace multiple whitespaces/tabs with single space
    text = re.sub(r"[ \t]+", " ", text)
    # Standardize line breaks
    text = re.sub(r"\r\n|\r", "\n", text)
    # Collapse 3+ newlines to 2
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()

def split_into_sentences(text: str) -> List[str]:
    """
    Splits text into clean individual sentences while preserving decimals ($49.99, 10.5%)
    and common abbreviations (e.g., i.e., vs., inc., ltd.).
    """
    if not text:
        return []

    cleaned = clean_text(text)
    # Protect decimals: replace decimal points between digits with placeholder
    protected = re.sub(r'(\d+)\.(\d+)', r'\1<DECIMAL_DOT>\2', cleaned)

    # Protect common abbreviations
    abbr_list = ["e.g.", "i.e.", "vs.", "inc.", "ltd.", "corp.", "co.", "approx.", "est."]
    for abbr in abbr_list:
        protected = re.sub(re.escape(abbr), abbr.replace(".", "<ABBR_DOT>"), protected, flags=re.IGNORECASE)

    # Split by standard sentence terminators (. ! ? \n)
    raw_sentences = re.split(r'(?<=[.!?\n])\s+', protected)

    sentences = []
    for s in raw_sentences:
        # Restore protected placeholders
        restored = s.replace('<DECIMAL_DOT>', '.').replace('<ABBR_DOT>', '.').strip()
        # Filter out empty or extremely short snippets (< 5 chars)
        if len(restored) >= 5 and re.search(r'[a-zA-Z0-9]', restored):
            sentences.append(restored)

    return sentences

def extract_claims(headline: str, description: str, ocr_text: str = "") -> List[str]:
    """
    Extracts atomic, verifiable claims from user inputs and OCR.
    Splits multi-clause sentences (e.g., 'Get 50% off and enjoy free shipping today!').
    """
    raw_chunks = []
    
    # Process headline
    if headline and headline.strip():
        raw_chunks.extend(re.split(r'[\n|•!?;]+|\s+[-–—]\s+', headline))

    # Process description
    if description and description.strip():
        # Split sentences cleanly
        desc_sentences = split_into_sentences(description)
        for s in desc_sentences:
            raw_chunks.extend(re.split(r'[\n|•!?;]+|\s+[-–—]\s+', s))

    # Process OCR text
    if ocr_text and ocr_text.strip():
        ocr_sentences = split_into_sentences(ocr_text)
        for s in ocr_sentences:
            raw_chunks.extend(re.split(r'[\n|•!?;]+|\s+[-–—]\s+', s))

    unique_claims = []
    seen = set()

    for chunk in raw_chunks:
        # Split on conjunctions if chunk is long (e.g., "... plus ...", "... and get ...")
        sub_chunks = re.split(r'\s+(?:and get|plus get|and enjoy|with)\s+', chunk, flags=re.IGNORECASE)
        for sub in sub_chunks:
            normalized = clean_text(sub)
            # Remove leading/trailing non-alphanumeric punctuation
            normalized = re.sub(r'^[^\w$£€%]+|[^\w$£€%]+$', '', normalized).strip()
            
            # Meaningful claims should have at least 5 characters and at least 2 words
            if len(normalized) >= 5 and len(normalized.split()) >= 2:
                key = normalized.lower()
                if key not in seen:
                    seen.add(key)
                    unique_claims.append(normalized)

    # If extraction found nothing (e.g., single short headline), fallback to raw inputs
    if not unique_claims:
        if headline and len(headline.strip()) >= 3:
            unique_claims.append(headline.strip())
        if description and len(description.strip()) >= 3:
            unique_claims.append(description.strip())

    return unique_claims
