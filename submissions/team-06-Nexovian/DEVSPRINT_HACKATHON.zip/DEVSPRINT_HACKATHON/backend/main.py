"""
AdMatch AI — FastAPI Application Entry Point
Exposes high-performance, validated endpoints for scraping and ad consistency auditing.
"""
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from backend.schemas import (
    AuditResponse, ScrapeRequest, ScrapeResponse, HealthResponse,
    PageInfo, ClaimAudit, EvidenceItem, ImageMatch
)
from backend.services.scraper import scrape_landing_page
from backend.services.ocr_service import extract_text_from_image, get_ocr_reader
from backend.services.text_matcher import match_claim, get_sentence_transformer
from backend.services.claim_verifier import verify_claim
from backend.services.image_matcher import match_images, get_clip_engine
from backend.services.report_service import synthesize_report
from backend.utils.text_cleaner import extract_claims

app = FastAPI(
    title="AdMatch AI Backend",
    version="1.0.0",
    description="AI-Powered Ad-to-Landing-Page Message Match & Advertising Consistency Auditor"
)

# Enable CORS for local dashboards
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health", response_model=HealthResponse)
def health_check():
    """Confirms backend is running and reports local AI model readiness instantly."""
    return HealthResponse(
        status="healthy",
        version="1.0.0",
        features={
            "semantic_text_matching": True,
            "clip_vision_matching": True,
            "easy_ocr": True
        }
    )

@app.post("/api/scrape", response_model=ScrapeResponse)
def scrape_endpoint(payload: ScrapeRequest):
    """Diagnostic endpoint to inspect scraped page elements independently."""
    try:
        data = scrape_landing_page(payload.url)
        page_info = PageInfo(
            url=data["original_url"],
            final_url=data["final_url"],
            title=data["title"],
            meta_description=data["meta_description"],
            headings=data["headings"],
            ctas=data["ctas"],
            extraction_method=data["extraction_method"],
            character_count=data["character_count"]
        )
        sample = data["main_text"][:400] + "..." if len(data["main_text"]) > 400 else data["main_text"]
        return ScrapeResponse(
            success=True,
            page=page_info,
            sample_text=sample,
            warnings=data["warnings"]
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except (TimeoutError, ConnectionError) as e:
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Scraper error: {e}")

@app.post("/api/ocr")
async def ocr_endpoint(image: UploadFile = File(...)):
    """Extracts promotional copy and offers directly from an uploaded ad creative."""
    try:
        image_bytes = await image.read()
        extracted_text, warn = extract_text_from_image(image_bytes)
        return {
            "success": True,
            "extracted_text": extracted_text,
            "warning": warn
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"OCR error: {e}")

@app.post("/api/audit", response_model=AuditResponse)
async def audit_endpoint(
    landing_page_url: str = Form(...),
    ad_headline: str = Form(""),
    ad_description: str = Form(""),
    ad_image: Optional[UploadFile] = File(None)
):
    """
    Main audit pipeline:
    1. Scrapes landing page
    2. Runs OCR on ad creative if uploaded (can auto-fill claims if text fields are empty)
    3. Splits ad text into distinct claims
    4. Retrieves candidate sentences via semantic search
    5. Performs deterministic offer and claim verification
    6. Compares ad creative with page images via CLIP (if enabled)
    7. Synthesizes transparent consistency report
    """
    warnings = []

    # 1. Process optional ad creative & OCR first
    ad_image_bytes = None
    ocr_text = ""
    if ad_image:
        ad_image_bytes = await ad_image.read()
        extracted_ocr, ocr_warn = extract_text_from_image(ad_image_bytes)
        if extracted_ocr:
            ocr_text = extracted_ocr
        if ocr_warn:
            warnings.append(ocr_warn)

    # Validate inputs: either text fields or OCR must provide claims
    if not ad_headline.strip() and not ad_description.strip() and not ocr_text.strip():
        raise HTTPException(
            status_code=400,
            detail="Please provide an ad headline, description, or upload an ad image containing readable text."
        )

    # 2. Scrape landing page
    try:
        page_data = scrape_landing_page(landing_page_url)
        warnings.extend(page_data.get("warnings", []))
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except (TimeoutError, ConnectionError) as e:
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Page fetch failed: {e}")

    # 3. Extract distinct advertising claims from headline, description, and OCR text
    claims_list = extract_claims(ad_headline, ad_description, ocr_text)
    if not claims_list:
        claims_list = [ocr_text.strip()] if ocr_text.strip() else [ad_headline.strip()]

    # 4. Sentence retrieval & claim verification
    page_sentences = page_data.get("paragraphs", [])
    verified_claims = []

    sentence_sources = page_data.get("sentence_sources", {})
    for claim_text in claims_list:
        # Retrieve evidence sentences with source locations
        evidence_raw = match_claim(claim_text, page_sentences, top_k=3, sentence_sources=sentence_sources)
        # Verify claim status against evidence
        verdict = verify_claim(claim_text, evidence_raw)

        # Convert to Pydantic items
        ev_items = [
            EvidenceItem(
                text=ev["evidence"],
                source=ev.get("source", "main_body"),
                similarity=ev["similarity"]
            )
            for ev in verdict.get("evidence", [])
        ]

        verified_claims.append(
            ClaimAudit(
                claim=verdict["claim"],
                status=verdict["status"],
                evidence=ev_items,
                reason=verdict["reason"],
                suggestion=verdict["suggestion"],
                category=verdict.get("category", "general")
            )
        )

    # 5. Visual matching with CLIP (if ad image provided)
    visual_score = None
    visual_matches = []
    if ad_image_bytes:
        v_score, v_matches, v_warns = match_images(ad_image_bytes, page_data.get("images", []))
        visual_score = v_score
        warnings.extend(v_warns)
        visual_matches = [
            ImageMatch(
                image_url=vm["image_url"],
                similarity=vm["similarity"],
                alt_text=vm.get("alt_text")
            )
            for vm in v_matches
        ]

    # 6. Synthesize final scores
    summary = synthesize_report(verified_claims, visual_score=visual_score)

    page_info = PageInfo(
        url=page_data["original_url"],
        final_url=page_data["final_url"],
        title=page_data["title"],
        meta_description=page_data["meta_description"],
        headings=page_data["headings"],
        ctas=page_data["ctas"],
        extraction_method=page_data["extraction_method"],
        character_count=page_data["character_count"]
    )

    return AuditResponse(
        page=page_info,
        summary=summary,
        claims=verified_claims,
        ocr_extracted_text=ocr_text if ocr_text else None,
        visual_matches=visual_matches,
        warnings=warnings
    )
