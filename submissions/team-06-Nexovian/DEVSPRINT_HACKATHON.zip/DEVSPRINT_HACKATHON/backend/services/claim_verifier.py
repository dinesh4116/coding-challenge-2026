"""
AdMatch AI — Evidence Verification & Offer Rule Engine
Enforces deterministic rules across percentages, currencies, dates, and eligibility,
mapping evidence to SUPPORTED, CONTRADICTED, UNSUPPORTED, or UNCERTAIN.
"""
import re
from typing import List, Dict, Any

PERCENT_REGEX = re.compile(r'(\b\d{1,3}(?:\.\d+)?\s*%\s*(?:off|discount)?\b)', re.IGNORECASE)
PRICE_REGEX = re.compile(r'([$£€₹]\s*\d+(?:\.\d{2})?|\b\d+(?:\.\d{2})?\s*(?:usd|eur|inr|gbp)\b)', re.IGNORECASE)
FREE_SHIPPING_REGEX = re.compile(r'\b(free\s+(?:shipping|delivery|dispatch))\b', re.IGNORECASE)
PAID_SHIPPING_REGEX = re.compile(r'(\b(?:shipping|delivery)\s+(?:from|starts at|costs?|fees?)\s*[$£€₹]?\s*\d+)', re.IGNORECASE)
TRIAL_REGEX = re.compile(r'(\b\d+\s*[- ]?day\s+free\s+trial\b)', re.IGNORECASE)
NO_CC_REGEX = re.compile(r'\b(no\s+credit\s+card\s+required)\b', re.IGNORECASE)

def _extract_percentages(text: str) -> List[str]:
    matches = PERCENT_REGEX.findall(text)
    return [m.strip().lower() for m in matches]

def _extract_prices(text: str) -> List[str]:
    matches = PRICE_REGEX.findall(text)
    return [re.sub(r'\s+', '', m.lower()) for m in matches]

def verify_claim(claim: str, evidence_candidates: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Verifies an individual claim against its retrieved evidence sentences.
    Returns audit dictionary with status, evidence items, reasoning, and suggestion.
    """
    clean_claim = claim.strip()
    
    # Baseline checks
    if not evidence_candidates:
        return {
            "claim": clean_claim,
            "status": "UNSUPPORTED",
            "evidence": [],
            "reason": "No relevant text or mentions found on the landing page for this claim.",
            "suggestion": "Ensure the landing page explicitly mentions this offer or value proposition.",
            "category": "general"
        }

    top_evidence = evidence_candidates[0]
    top_text = top_evidence.get("evidence", "")
    top_sim = top_evidence.get("similarity", 0.0)
    all_evidence_texts = " ".join([e.get("evidence", "") for e in evidence_candidates])

    # 1. Inspect Discount / Percentage Claims
    claim_pcts = _extract_percentages(clean_claim)
    if claim_pcts:
        claim_pct_num = re.search(r'\d+', claim_pcts[0]).group() if re.search(r'\d+', claim_pcts[0]) else None
        page_pcts = _extract_percentages(all_evidence_texts)

        if page_pcts and claim_pct_num:
            page_pct_nums = [re.search(r'\d+', p).group() for p in page_pcts if re.search(r'\d+', p)]
            if claim_pct_num in page_pct_nums:
                return {
                    "claim": clean_claim,
                    "status": "SUPPORTED",
                    "evidence": evidence_candidates,
                    "reason": f"Direct confirmation: Destination page verifies the advertised {claim_pcts[0]} promotional offer.",
                    "suggestion": "Offer claim is verified. Ensure promotional banner is above the fold.",
                    "category": "discount"
                }
            else:
                conflicting = ", ".join(page_pcts)
                return {
                    "claim": clean_claim,
                    "status": "CONTRADICTED",
                    "evidence": evidence_candidates,
                    "reason": f"Contradiction detected: Ad advertises '{claim_pcts[0]}' but destination page cites '{conflicting}'.",
                    "suggestion": f"Align advertisement copy to match the actual on-page offer ({conflicting}) to prevent bounce rates.",
                    "category": "discount"
                }
        else:
            # Claim specifies discount, but no percentages exist in candidate sentences
            return {
                "claim": clean_claim,
                "status": "UNSUPPORTED",
                "evidence": evidence_candidates,
                "reason": f"The ad promises a specific discount ({claim_pcts[0]}), but no verified promotional discount was found in page evidence.",
                "suggestion": f"Display the {claim_pcts[0]} discount and redemption code prominently on the landing page hero.",
                "category": "discount"
            }

    # 2. Inspect Price & Currency Claims
    claim_prices = _extract_prices(clean_claim)
    if claim_prices:
        page_prices = _extract_prices(all_evidence_texts)
        if page_prices:
            if any(cp in page_prices for cp in claim_prices):
                return {
                    "claim": clean_claim,
                    "status": "SUPPORTED",
                    "evidence": evidence_candidates,
                    "reason": f"Price verified: Advertised price '{claim_prices[0]}' matches page pricing.",
                    "suggestion": "Pricing is consistent.",
                    "category": "price"
                }
            else:
                return {
                    "claim": clean_claim,
                    "status": "CONTRADICTED",
                    "evidence": evidence_candidates,
                    "reason": f"Pricing discrepancy: Ad states '{claim_prices[0]}' but page mentions '{page_prices[0]}'.",
                    "suggestion": "Update the ad creative to reflect current pricing or update the product landing page.",
                    "category": "price"
                }
        else:
            return {
                "claim": clean_claim,
                "status": "UNSUPPORTED",
                "evidence": evidence_candidates,
                "reason": f"Advertised price '{claim_prices[0]}' is not mentioned in extracted page evidence.",
                "suggestion": "Display the product price clearly on the destination page.",
                "category": "price"
            }

    # 3. Inspect Shipping Claims
    if FREE_SHIPPING_REGEX.search(clean_claim):
        if FREE_SHIPPING_REGEX.search(all_evidence_texts):
            return {
                "claim": clean_claim,
                "status": "SUPPORTED",
                "evidence": evidence_candidates,
                "reason": "Free shipping promise is confirmed on the destination page.",
                "suggestion": "Shipping terms match.",
                "category": "shipping"
            }
        elif PAID_SHIPPING_REGEX.search(all_evidence_texts):
            return {
                "claim": clean_claim,
                "status": "CONTRADICTED",
                "evidence": evidence_candidates,
                "reason": "Shipping conflict: Ad states free shipping, but page indicates delivery fees apply.",
                "suggestion": "Clarify free shipping minimum thresholds or remove free shipping claim from ad.",
                "category": "shipping"
            }
        else:
            return {
                "claim": clean_claim,
                "status": "UNSUPPORTED",
                "evidence": evidence_candidates,
                "reason": "Free shipping claim is not supported by page text.",
                "suggestion": "Add a free shipping notification bar or policy badge to the destination page.",
                "category": "shipping"
            }

    # 4. Inspect Free Trial / No Credit Card Claims
    if TRIAL_REGEX.search(clean_claim) or NO_CC_REGEX.search(clean_claim):
        if TRIAL_REGEX.search(all_evidence_texts) or NO_CC_REGEX.search(all_evidence_texts):
            return {
                "claim": clean_claim,
                "status": "SUPPORTED",
                "evidence": evidence_candidates,
                "reason": "Free trial terms and conditions confirmed on the landing page.",
                "suggestion": "Trial claims align.",
                "category": "trial"
            }
        elif top_sim >= 0.65:
            return {
                "claim": clean_claim,
                "status": "UNCERTAIN",
                "evidence": evidence_candidates,
                "reason": "Page mentions trials or signups, but specific trial duration/terms are ambiguous.",
                "suggestion": "Explicitly state trial duration and payment terms near the CTA.",
                "category": "trial"
            }
        else:
            return {
                "claim": clean_claim,
                "status": "UNSUPPORTED",
                "evidence": evidence_candidates,
                "reason": "Free trial promise was not substantiated in page evidence.",
                "suggestion": "Clarify trial terms directly beneath the signup button.",
                "category": "trial"
            }

    # 5. General Semantic Claims Evaluation
    if top_sim >= 0.72:
        verdict = {
            "claim": clean_claim,
            "status": "SUPPORTED",
            "evidence": evidence_candidates,
            "reason": "High semantic alignment with page evidence.",
            "suggestion": "Claim is well-represented on the landing page.",
            "category": "feature"
        }
    elif top_sim >= 0.45:
        verdict = {
            "claim": clean_claim,
            "status": "UNCERTAIN",
            "evidence": evidence_candidates,
            "reason": "Partial topical overlap detected, but destination page lacks concrete corroboration.",
            "suggestion": "Strengthen hero copy to directly echo this key advertisement claim.",
            "category": "feature"
        }
    else:
        verdict = {
            "claim": clean_claim,
            "status": "UNSUPPORTED",
            "evidence": evidence_candidates,
            "reason": "Extracted page content does not sufficiently substantiate this advertising statement.",
            "suggestion": "Add explicit copy or testimonials supporting this claim on the destination page.",
            "category": "feature"
        }

    # Inspect placement prominence: penalize / flag claims hidden in fine-print footer
    top_source = top_evidence.get("source", "").lower()
    if "footer" in top_source or "fine print" in top_source:
        verdict["reason"] += " (⚠️ Placement Alert: Found only in fine-print footer, not in hero or main section)."
        verdict["suggestion"] += " Elevate this promise from the footer to the main hero section to build trust."

    return verdict
