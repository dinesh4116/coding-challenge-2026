"""
AdMatch AI — OCR Service for Advertisement Creatives
Safely extracts embedded text from promotional images using EasyOCR with lazy loading.
"""
import io
import numpy as np
from typing import Tuple, Optional
from PIL import Image

_ocr_reader = None

def get_ocr_reader():
    """Lazy singleton for EasyOCR English reader with automatic retry."""
    global _ocr_reader
    if _ocr_reader is None:
        try:
            import easyocr
            _ocr_reader = easyocr.Reader(['en'], gpu=False, verbose=False)
        except Exception as e:
            print(f"EasyOCR reader init note: {e}")
            return None
    return _ocr_reader

def extract_text_from_image(image_bytes: bytes) -> Tuple[str, Optional[str]]:
    """
    Validates uploaded image and runs OCR.
    Returns (extracted_text, warning_or_error)
    """
    if not image_bytes:
        return "", None

    # Validate image buffer with Pillow
    try:
        img = Image.open(io.BytesIO(image_bytes))
        img.verify()
    except Exception as e:
        return "", f"Invalid image file: {e}"

    # Re-open for reading after verify
    img = Image.open(io.BytesIO(image_bytes)).convert("RGB")

    # Resize if extremely large to prevent OOM
    if max(img.size) > 1600:
        img.thumbnail((1600, 1600), Image.Resampling.LANCZOS)

    reader = get_ocr_reader()
    if reader is None:
        return "", "OCR engine (EasyOCR) is not currently ready; skipping creative text extraction."

    try:
        # Convert PIL image to numpy array directly for EasyOCR
        img_np = np.array(img)
        results = reader.readtext(img_np, detail=0)
        extracted = " ".join([str(r).strip() for r in results if str(r).strip()])
        return extracted, None
    except Exception as e:
        return "", f"OCR extraction error: {e}"
