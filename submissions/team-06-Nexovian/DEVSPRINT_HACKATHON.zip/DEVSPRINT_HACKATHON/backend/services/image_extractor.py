"""
AdMatch AI — Safe Landing-Page Image Extractor
Extracts, deduplicates, and validates candidate product/hero images from page HTML.
"""
from urllib.parse import urljoin, urlparse
from typing import List, Dict, Any
from bs4 import BeautifulSoup

# Patterns to filter out tracking pixels, icons, and analytics beacons
IGNORE_SUBSTRINGS = [
    "favicon", "icon", "logo-small", "badge", "tracker", "analytics",
    "pixel", "sprite", "1x1", "loader", "spinner", ".svg"
]

def extract_page_images(html_content: str, base_url: str, max_images: int = 10) -> List[Dict[str, Any]]:
    """
    Extracts high-priority visual images (og:image, hero images, main product photos).
    Returns list of dicts: [{"url": str, "alt": str}]
    """
    if not html_content:
        return []

    soup = BeautifulSoup(html_content, "html.parser")
    candidates = []
    seen_urls = set()

    # 1. Check Open Graph hero image first (highest quality ad preview)
    og_img = soup.find("meta", property="og:image") or soup.find("meta", attrs={"name": "og:image"})
    if og_img and og_img.get("content"):
        full_url = urljoin(base_url, og_img["content"].strip())
        if full_url.startswith(("http://", "https://")):
            candidates.append({"url": full_url, "alt": "Open Graph Hero Image"})
            seen_urls.add(full_url)

    # 2. Check <img> elements
    for img in soup.find_all("img"):
        src = img.get("src") or img.get("data-src") or img.get("data-original")
        if not src:
            # Check srcset for largest candidate
            srcset = img.get("srcset")
            if srcset:
                parts = srcset.split(",")
                if parts:
                    src = parts[-1].strip().split()[0]
        
        if not src:
            continue

        full_url = urljoin(base_url, src.strip())
        parsed = urlparse(full_url)
        if parsed.scheme not in ("http", "https"):
            continue

        lower_url = full_url.lower()
        if any(bad in lower_url for bad in IGNORE_SUBSTRINGS):
            continue

        # Filter out obvious tiny images using width/height attributes if declared
        width = img.get("width")
        height = img.get("height")
        try:
            if width and int(width) < 80:
                continue
            if height and int(height) < 80:
                continue
        except (ValueError, TypeError):
            pass

        if full_url not in seen_urls:
            seen_urls.add(full_url)
            alt_text = img.get("alt", "").strip() or None
            candidates.append({"url": full_url, "alt": alt_text})

        if len(candidates) >= max_images:
            break

    return candidates
