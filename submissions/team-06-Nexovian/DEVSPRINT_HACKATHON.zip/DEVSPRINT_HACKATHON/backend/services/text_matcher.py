"""
AdMatch AI — Text Semantic Retrieval Engine
Loads sentence-transformers/all-MiniLM-L6-v2 lazily and ranks webpage sentences
for each advertising claim using cosine similarity.
"""
from typing import List, Dict, Any
import numpy as np

_model_instance = None
_model_failed = False

def get_sentence_transformer():
    """Lazy-load singleton instance of all-MiniLM-L6-v2."""
    global _model_instance, _model_failed
    if _model_instance is None and not _model_failed:
        try:
            from sentence_transformers import SentenceTransformer
            _model_instance = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
        except Exception:
            # Fall back to lexical matcher if weights/PyTorch are not yet installed
            _model_failed = True
            _model_instance = None
    return _model_instance

def _lexical_similarity(claim: str, sentence: str) -> float:
    """Fallback Jaccard + token overlap similarity if PyTorch is unavailable."""
    claim_words = set(claim.lower().split())
    sent_words = set(sentence.lower().split())
    if not claim_words or not sent_words:
        return 0.0
    intersection = claim_words.intersection(sent_words)
    union = claim_words.union(sent_words)
    # Give higher weight to overlapping non-stop words
    jaccard = len(intersection) / len(union)
    overlap = len(intersection) / max(len(claim_words), 1)
    return round((jaccard * 0.4) + (overlap * 0.6), 4)

def match_claim(
    claim: str,
    page_sentences: List[str],
    top_k: int = 3,
    sentence_sources: Dict[str, str] = None
) -> List[Dict[str, Any]]:
    """
    Ranks extracted webpage sentences against a specific advertising claim.
    Returns the top_k matching evidence candidates.
    """
    if not claim or not claim.strip() or not page_sentences:
        return []

    sources = sentence_sources or {}
    clean_claim = claim.strip()
    # Filter empty sentences
    valid_sentences = [s.strip() for s in page_sentences if s and len(s.strip()) >= 5]
    if not valid_sentences:
        return []

    model = get_sentence_transformer()

    if model is not None:
        try:
            from sklearn.metrics.pairwise import cosine_similarity
            # Vectorize claim and all candidate sentences simultaneously
            all_texts = [clean_claim] + valid_sentences
            embeddings = model.encode(all_texts, normalize_embeddings=True)
            
            claim_vec = embeddings[0:1]
            sent_vecs = embeddings[1:]
            
            sim_scores = cosine_similarity(claim_vec, sent_vecs)[0]
            ranked_indices = np.argsort(sim_scores)[::-1][:top_k]

            results = []
            for idx in ranked_indices:
                score = float(sim_scores[idx])
                s_text = valid_sentences[idx]
                results.append({
                    "evidence": s_text,
                    "similarity": round(score, 4),
                    "source": sources.get(s_text, "main_body")
                })
            return results
        except Exception:
            # Gracefully degrade to lexical matcher
            pass

    # Fallback lexical ranking
    scored = []
    for sent in valid_sentences:
        score = _lexical_similarity(clean_claim, sent)
        scored.append((sent, score))
    
    scored.sort(key=lambda x: x[1], reverse=True)
    return [
        {
            "evidence": sent,
            "similarity": round(float(score), 4),
            "source": sources.get(sent, "main_body")
        }
        for sent, score in scored[:top_k]
    ]
