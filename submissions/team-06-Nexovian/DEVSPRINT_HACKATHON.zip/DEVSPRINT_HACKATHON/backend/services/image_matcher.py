"""
AdMatch AI — CLIP Visual Similarity Service
Compares ad creative imagery against landing page imagery using CLIP embeddings.
"""
import io
import requests
from typing import List, Dict, Any, Tuple, Optional
from PIL import Image

_clip_model = None
_clip_processor = None
_clip_failed = False

def get_clip_engine():
    """Lazy singleton for CLIP model & processor."""
    global _clip_model, _clip_processor, _clip_failed
    if _clip_model is None and not _clip_failed:
        try:
            from transformers import CLIPProcessor, CLIPModel
            _clip_model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32")
            _clip_processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")
        except Exception:
            _clip_failed = True
            _clip_model = None
            _clip_processor = None
    return _clip_model, _clip_processor

def _download_image(url: str, timeout: int = 5) -> Optional[Image.Image]:
    """Safely downloads and opens candidate image with timeout and byte limit."""
    try:
        resp = requests.get(
            url,
            timeout=timeout,
            headers={"User-Agent": "Mozilla/5.0 AdMatchAI/1.0"},
            stream=True
        )
        if resp.status_code == 200:
            content = resp.raw.read(3 * 1024 * 1024)  # 3 MB cap
            img = Image.open(io.BytesIO(content)).convert("RGB")
            # Resize candidate to standard thumbnail
            img.thumbnail((400, 400))
            return img
    except Exception:
        pass
    return None

def match_images(
    ad_image_bytes: bytes,
    landing_images: List[Dict[str, Any]]
) -> Tuple[Optional[int], List[Dict[str, Any]], List[str]]:
    """
    Ranks landing page images against the ad creative using CLIP.
    Returns (visual_score, matched_candidates, warnings)
    """
    warnings = []
    if not ad_image_bytes:
        return None, [], warnings

    if not landing_images:
        warnings.append("No suitable images extracted from destination page for visual comparison.")
        return None, [], warnings

    model, processor = get_clip_engine()
    if model is None or processor is None:
        warnings.append("CLIP visual model is not loaded; visual comparison was skipped.")
        return None, [], warnings

    try:
        import torch
        from sklearn.metrics.pairwise import cosine_similarity

        ad_img = Image.open(io.BytesIO(ad_image_bytes)).convert("RGB")
        ad_img.thumbnail((400, 400))

        # Download up to 6 candidate images
        downloaded = []
        for item in landing_images[:6]:
            img_obj = _download_image(item["url"])
            if img_obj:
                downloaded.append((item, img_obj))

        if not downloaded:
            warnings.append("Could not fetch candidate images from destination server.")
            return None, [], warnings

        # Prepare batch
        cand_items = [d[0] for d in downloaded]
        cand_imgs = [d[1] for d in downloaded]
        all_imgs = [ad_img] + cand_imgs

        inputs = processor(images=all_imgs, return_tensors="pt")
        with torch.no_grad():
            img_features = model.get_image_features(**inputs)
            # Normalize embeddings
            img_features = img_features / img_features.norm(dim=-1, keepdim=True)

        ad_vec = img_features[0:1].cpu().numpy()
        cand_vecs = img_features[1:].cpu().numpy()

        scores = cosine_similarity(ad_vec, cand_vecs)[0]

        ranked = []
        for i, score in enumerate(scores):
            raw_sim = float(score)
            ranked.append({
                "image_url": cand_items[i]["url"],
                "alt_text": cand_items[i].get("alt"),
                "similarity": round(raw_sim, 4)
            })

        ranked.sort(key=lambda x: x["similarity"], reverse=True)

        # Compute heuristic visual score (0-100) based on top match
        # CLIP image-to-image cosine similarities for natural photos typically sit between 0.4 and 0.95
        top_sim = ranked[0]["similarity"] if ranked else 0.0
        # Scale 0.4 - 0.9 to 0 - 100 heuristic
        scaled_score = max(0, min(100, int(((top_sim - 0.35) / 0.55) * 100)))

        return scaled_score, ranked, warnings

    except Exception as e:
        warnings.append(f"Visual matching calculation encountered an issue: {e}")
        return None, [], warnings
