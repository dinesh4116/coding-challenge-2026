"""
AdMatch AI — Audit Report & Score Synthesis Engine
Computes transparent heuristic scores and structured audit summaries.
"""
from typing import List, Dict, Any, Tuple
from backend.schemas import ClaimAudit, ClaimStatus, OverallStatus, AuditSummary

def synthesize_report(claims: List[ClaimAudit], visual_score: Any = None) -> AuditSummary:
    """
    Synthesizes overall consistency scores and categorical counts.
    """
    total = len(claims)
    if total == 0:
        return AuditSummary(
            text_score=0,
            visual_score=visual_score,
            overall_status=OverallStatus.INSUFFICIENT_EVIDENCE,
            total_claims=0,
            supported_count=0,
            contradicted_count=0,
            unsupported_count=0,
            uncertain_count=0
        )

    supported = sum(1 for c in claims if c.status == ClaimStatus.SUPPORTED)
    contradicted = sum(1 for c in claims if c.status == ClaimStatus.CONTRADICTED)
    unsupported = sum(1 for c in claims if c.status == ClaimStatus.UNSUPPORTED)
    uncertain = sum(1 for c in claims if c.status == ClaimStatus.UNCERTAIN)

    # Calculate weighted text consistency score
    weighted_scores = []
    total_weights = []

    for c in claims:
        # High-stakes claims (discounts, pricing, shipping promises) get higher weighting
        weight = 1.5 if c.category in ("discount", "price", "shipping") else 1.0
        
        if c.status == ClaimStatus.SUPPORTED:
            val = 1.0
        elif c.status == ClaimStatus.UNCERTAIN:
            val = 0.45
        elif c.status == ClaimStatus.UNSUPPORTED:
            val = 0.15
        else: # CONTRADICTED
            val = 0.0

        weighted_scores.append(weight * val)
        total_weights.append(weight)

    raw_ratio = sum(weighted_scores) / sum(total_weights) if total_weights else 0.0
    text_score = int(round(raw_ratio * 100))

    # Determine overall status
    if contradicted > 0:
        overall_status = OverallStatus.HIGH_MISMATCH
    elif text_score >= 75:
        overall_status = OverallStatus.FULL_MATCH
    elif text_score >= 45:
        overall_status = OverallStatus.PARTIAL_MATCH
    else:
        overall_status = OverallStatus.INSUFFICIENT_EVIDENCE

    return AuditSummary(
        text_score=text_score,
        visual_score=visual_score,
        overall_status=overall_status,
        total_claims=total,
        supported_count=supported,
        contradicted_count=contradicted,
        unsupported_count=unsupported,
        uncertain_count=uncertain
    )
