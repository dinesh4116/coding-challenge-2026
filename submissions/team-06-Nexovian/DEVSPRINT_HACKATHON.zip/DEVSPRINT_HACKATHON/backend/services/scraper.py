"""
AdMatch AI — Production-Grade Web Scraper Service
Handles SSRF validation, BeautifulSoup extraction, Trafilatura article parsing,
and Playwright JavaScript-rendering fallback.
"""
import re
import requests
from typing import Dict, Any, List
from bs4 import BeautifulSoup
import trafilatura

from backend.utils.url_security import validate_url
from backend.utils.text_cleaner import clean_text, split_into_sentences
from backend.services.image_extractor import extract_page_images

DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/123.0.0.0 Safari/537.36 AdMatchAI/1.0"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}

MAX_BODY_CHARS = 20000
MAX_RESPONSE_BYTES = 5 * 1024 * 1024  # 5 MB
REQUEST_TIMEOUT = 10  # seconds

def _extract_ctas(soup: BeautifulSoup) -> List[str]:
    """Extract action buttons, link labels, and prominent CTA targets."""
    ctas = []
    seen = set()
    cta_patterns = re.compile(
        r"(buy|shop|get|order|claim|start|try|sign up|join|download|learn|subscribe|book|reserve)",
        re.IGNORECASE
    )

    # 1. Search button tags
    for btn in soup.find_all(["button", "input"]):
        text = btn.get_text() or btn.get("value") or ""
        cleaned = clean_text(text)
        if 2 <= len(cleaned) <= 50 and cleaned.lower() not in seen:
            seen.add(cleaned.lower())
            ctas.append(cleaned)

    # 2. Search prominent links with button classes or CTA phrasing
    for a in soup.find_all("a"):
        classes = " ".join(a.get("class", []))
        role = a.get("role", "")
        text = clean_text(a.get_text())
        if not text or len(text) > 50 or len(text) < 2:
            continue

        if "btn" in classes.lower() or role == "button" or cta_patterns.search(text):
            if text.lower() not in seen:
                seen.add(text.lower())
                ctas.append(text)

        if len(ctas) >= 12:
            break

    return ctas

def _scrape_with_playwright(url: str) -> str:
    """Fallback headless browser render for JS-heavy single-page applications."""
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page(
                user_agent=DEFAULT_HEADERS["User-Agent"]
            )
            page.goto(url, wait_until="networkidle", timeout=12000)
            content = page.content()
            browser.close()
            return content
    except Exception:
        return ""

def scrape_landing_page(url: str, allow_local_for_testing: bool = False) -> Dict[str, Any]:
    """
    Main scraping entry point.
    Returns structured page payload matching AdMatch AI audit specification.
    """
    warnings = []
    
    # 1. Security & URL validation
    is_valid, err_msg = validate_url(url, allow_local_for_testing=allow_local_for_testing)
    if not is_valid:
        raise ValueError(f"URL validation error: {err_msg}")

    final_url = url
    raw_html = ""
    extraction_method = "requests"

    # 2. Fetch or load page content
    import os
    cleaned_local_path = url.replace("file:///", "").replace("file://", "")
    if os.path.exists(cleaned_local_path):
        try:
            with open(cleaned_local_path, "r", encoding="utf-8", errors="replace") as f:
                raw_html = f.read()
            final_url = url
            extraction_method = "local_snapshot"
        except Exception as e:
            raise IOError(f"Could not read local snapshot file: {e}")
    else:
        # Fetch page via Requests
        try:
            session = requests.Session()
            resp = session.get(
                url,
                headers=DEFAULT_HEADERS,
                timeout=REQUEST_TIMEOUT,
                allow_redirects=True,
                stream=True
            )
            resp.raise_for_status()

            # Revalidate all redirect hops against SSRF constraints
            for redirect_hop in resp.history:
                valid_hop, hop_err = validate_url(redirect_hop.url, allow_local_for_testing=allow_local_for_testing)
                if not valid_hop:
                    raise ValueError(f"Prohibited redirect destination ({redirect_hop.url}): {hop_err}")
            
            valid_final, final_err = validate_url(resp.url, allow_local_for_testing=allow_local_for_testing)
            if not valid_final:
                raise ValueError(f"Final redirect resolved to prohibited destination ({resp.url}): {final_err}")

            # Check content-type header
            content_type = resp.headers.get("content-type", "").lower()
            if "text/html" not in content_type and "application/xhtml+xml" not in content_type:
                warnings.append(f"Content-Type is '{content_type}', expected HTML.")

            final_url = resp.url
            
            # Read limited chunk to prevent memory bloat
            content_chunks = []
            bytes_read = 0
            for chunk in resp.iter_content(chunk_size=8192):
                bytes_read += len(chunk)
                content_chunks.append(chunk)
                if bytes_read >= MAX_RESPONSE_BYTES:
                    warnings.append("Page exceeded 5MB limit; content was truncated.")
                    break
            
            raw_html = b"".join(content_chunks).decode(resp.encoding or "utf-8", errors="replace")

        except requests.exceptions.Timeout:
            raise TimeoutError(f"Connection timed out while fetching {url} ({REQUEST_TIMEOUT}s limit).")
        except requests.exceptions.RequestException as e:
            raise ConnectionError(f"HTTP fetch failed for {url}: {e}")

    # 3. Extract text with Trafilatura
    clean_main_text = ""
    if raw_html:
        clean_main_text = trafilatura.extract(
            raw_html,
            include_comments=False,
            include_tables=True,
            no_fallback=False
        ) or ""

    # 4. Fallback: If text is minimal (<120 chars), check if client-side JS is needed
    if len(clean_main_text.strip()) < 120:
        pw_html = _scrape_with_playwright(final_url)
        if pw_html:
            pw_text = trafilatura.extract(pw_html, include_tables=True) or ""
            if len(pw_text.strip()) > len(clean_main_text.strip()):
                raw_html = pw_html
                clean_main_text = pw_text
                extraction_method = "playwright_fallback"
                warnings.append("Extracted via Playwright JavaScript-rendering fallback.")

    # 5. Parse Structured HTML via BeautifulSoup
    soup = BeautifulSoup(raw_html, "html.parser")

    # If Trafilatura still produced nothing, extract directly from BeautifulSoup body
    if not clean_main_text.strip():
        for tag in soup(["script", "style", "noscript", "svg", "nav", "footer"]):
            tag.decompose()
        body_tag = soup.body or soup
        clean_main_text = clean_text(body_tag.get_text())
        if not clean_main_text.strip():
            warnings.append("Page body text was empty or inaccessible.")

    # Cap text length to prevent downstream token spikes
    if len(clean_main_text) > MAX_BODY_CHARS:
        clean_main_text = clean_main_text[:MAX_BODY_CHARS]
        warnings.append(f"Main text capped at {MAX_BODY_CHARS} characters.")

    # Page Title
    title = ""
    if soup.title and soup.title.string:
        title = clean_text(soup.title.string)
    elif soup.h1:
        title = clean_text(soup.h1.get_text())
    else:
        title = "Untitled Page"

    # Meta Description
    meta_desc_tag = (
        soup.find("meta", attrs={"name": "description"}) or
        soup.find("meta", attrs={"property": "og:description"})
    )
    meta_description = clean_text(meta_desc_tag.get("content", "")) if meta_desc_tag else None

    # Headings (H1, H2, H3)
    headings = []
    for h in soup.find_all(["h1", "h2", "h3"]):
        h_text = clean_text(h.get_text())
        if 3 <= len(h_text) <= 120 and h_text not in headings:
            headings.append(h_text)
        if len(headings) >= 15:
            break

    # Action CTAs
    ctas = _extract_ctas(soup)

    # Relevant Images
    images = extract_page_images(raw_html, final_url, max_images=10)

    # Sentences for evidence mapping
    paragraphs = split_into_sentences(clean_main_text)

    # Track sentence section placements (Hero vs Main Body vs Footer)
    sentence_sources = {}
    footer_tag = soup.find("footer") or soup.find(class_=re.compile(r"fine|disclaimer", re.I))
    if footer_tag:
        for fs in split_into_sentences(footer_tag.get_text()):
            sentence_sources[fs] = "footer / fine print"

    hero_tag = soup.find(class_=re.compile(r"hero|banner", re.I)) or soup.find("header")
    if hero_tag:
        for hs in split_into_sentences(hero_tag.get_text()):
            sentence_sources[hs] = "hero section"

    # Also include headings in candidate sentences if not present
    for h in headings:
        if h not in paragraphs:
            paragraphs.insert(0, h)
            sentence_sources[h] = "headline / H1-H3"

    return {
        "original_url": url,
        "final_url": final_url,
        "title": title,
        "meta_description": meta_description,
        "headings": headings,
        "main_text": clean_main_text,
        "paragraphs": paragraphs,
        "sentence_sources": sentence_sources,
        "ctas": ctas,
        "images": images,
        "extraction_method": extraction_method,
        "character_count": len(clean_main_text),
        "warnings": warnings,
    }
