import { AdCreative, CreativeVariableImpact, AngleArchetype, EnvironmentSetting, HumanPresence, ProductProminence, TextOverlayType, ColorTone, PerformanceTier } from '../types/ad';

import adBreakoutUgc from '../assets/images/ad_breakout_ugc_counter_1791612000781.jpg';
import adFailedStudio from '../assets/images/ad_failed_minimal_studio_1791612021043.jpg';
import adFounderDemo from '../assets/images/ad_founder_demonstration_1791612039869.jpg';
import adSplitComparison from '../assets/images/ad_split_comparison_test_1791612062678.jpg';

export const FEATURED_IMAGES = {
  breakoutUgc: adBreakoutUgc,
  failedStudio: adFailedStudio,
  founderDemo: adFounderDemo,
  splitComparison: adSplitComparison,
};

// Anchor curated hero ads that demonstrate the extreme contrast
const anchorAds: AdCreative[] = [
  {
    id: 'AD-014',
    name: 'Morning Routine Messy Countertop #02',
    channel: 'Meta Feed',
    dateShipped: '2026-08-14',
    spend: 64200,
    impressions: 2140000,
    clicks: 57780,
    ctr: 2.7,
    hookRate: 44.8,
    cpa: 16.40,
    roas: 3.84,
    revenue: 246528,
    performanceTier: 'Breakout Winner',
    imageUrl: adBreakoutUgc,
    creativeVariables: {
      angleArchetype: 'Authentic UGC',
      productProminence: 'High (>40%)',
      humanPresence: 'Hands Holding Only',
      environment: 'Kitchen / Morning Counter',
      textOverlay: 'Bold Benefit Headline',
      colorTone: 'Warm Natural Sun',
      vibeScore: 'Empirically Engineered',
    },
    whyItPerformed: 'Unpolished morning kitchen lighting blends seamlessly into native social feeds. Stopped the scroll without triggering ad-blindness. The bold 1-line benefit directly tackled sluggish mornings.',
  },
  {
    id: 'AD-082',
    name: 'Minimalist Studio Packshot White #09',
    channel: 'Meta Feed',
    dateShipped: '2026-07-28',
    spend: 18400,
    impressions: 480000,
    clicks: 4320,
    ctr: 0.9,
    hookRate: 14.2,
    cpa: 82.50,
    roas: 0.62,
    revenue: 11408,
    performanceTier: 'Money Bleeder',
    imageUrl: adFailedStudio,
    creativeVariables: {
      angleArchetype: 'Sterile Studio Packshot',
      productProminence: 'Medium (20-40%)',
      humanPresence: 'No Human',
      environment: 'Seamless Pure White',
      textOverlay: 'Minimal Brand Tagline',
      colorTone: 'Cold Clinical White',
      vibeScore: 'High Vibes / Zero Data',
    },
    whyItFailed: 'Sterile studio packshot on pure white looks like an Amazon catalogue thumbnail or sterile banner ad. High cognitive friction, zero emotional context, no tangible proof of benefit.',
  },
  {
    id: 'AD-047',
    name: 'Founder Studio Transparency Demo #01',
    channel: 'Instagram Stories',
    dateShipped: '2026-09-02',
    spend: 42100,
    impressions: 1390000,
    clicks: 44480,
    ctr: 3.2,
    hookRate: 46.2,
    cpa: 17.80,
    roas: 3.48,
    revenue: 146508,
    performanceTier: 'Breakout Winner',
    imageUrl: adFounderDemo,
    creativeVariables: {
      angleArchetype: 'Founder Hands-On Demo',
      productProminence: 'High (>40%)',
      humanPresence: 'Direct Gaze',
      environment: 'Workshop / Loft',
      textOverlay: 'Bold Benefit Headline',
      colorTone: 'Warm Natural Sun',
      vibeScore: 'Empirically Engineered',
    },
    whyItPerformed: 'Founder looking straight into the lens triggers evolutionary social trust signals. Holding bottle close creates tactile scale. Clear, transparent ingredient breakdown.',
  },
  {
    id: 'AD-063',
    name: 'Chaos vs Clarity Split Comparison #04',
    channel: 'Meta Feed',
    dateShipped: '2026-08-22',
    spend: 38900,
    impressions: 1210000,
    clicks: 35090,
    ctr: 2.9,
    hookRate: 41.5,
    cpa: 19.10,
    roas: 3.12,
    revenue: 121368,
    performanceTier: 'Breakout Winner',
    imageUrl: adSplitComparison,
    creativeVariables: {
      angleArchetype: 'Split Problem vs Solution',
      productProminence: 'High (>40%)',
      humanPresence: 'Hands Holding Only',
      environment: 'Kitchen / Morning Counter',
      textOverlay: 'Bold Benefit Headline',
      colorTone: 'Warm Natural Sun',
      vibeScore: 'Empirically Engineered',
    },
    whyItPerformed: 'Visual juxtaposition instantly agitates the chaotic morning pain point (12 scattered pill bottles) and provides instant cognitive relief in a single glance.',
  },
];

// Systematic generator for the remaining 196 ads to reach exactly 200 ads in the quarterly cohort
function generateCohortAds(): AdCreative[] {
  const ads: AdCreative[] = [...anchorAds];

  const archetypes: AngleArchetype[] = [
    'Authentic UGC',
    'Sterile Studio Packshot',
    'Founder Hands-On Demo',
    'Split Problem vs Solution',
    'Customer Review & Press',
    'Ingredient / Texture Macro',
    'Meme / Organic Screenshot',
  ];

  const environments: EnvironmentSetting[] = [
    'Kitchen / Morning Counter',
    'Bathroom / Mirror',
    'Seamless Pure White',
    'Studio Gradient',
    'Outdoor Sunlight',
    'Workshop / Loft',
  ];

  const humanPresences: HumanPresence[] = [
    'Direct Gaze',
    'Hands Holding Only',
    'Background Lifestyle',
    'No Human',
  ];

  const textOverlays: TextOverlayType[] = [
    'Bold Benefit Headline',
    'Real Review Quote',
    'Minimal Brand Tagline',
    'Discount / Offer Hook',
    'No Text',
  ];

  const channels: Array<AdCreative['channel']> = [
    'Meta Feed',
    'Instagram Stories',
    'TikTok Carousel',
    'Pinterest',
  ];

  // Distribution targets for the 200 ads:
  // - Breakout Winners: 12 total (4 in anchor + 8 generated)
  // - Core Performers: 28 total
  // - Breakeven: 70 total
  // - Money Bleeders: 90 total (1 in anchor + 89 generated)
  
  let idCounter = 1;
  const takenIds = new Set(anchorAds.map((a) => a.id));

  const addGeneratedAd = (tier: PerformanceTier) => {
    while (takenIds.has(`AD-${String(idCounter).padStart(3, '0')}`)) {
      idCounter++;
    }
    const id = `AD-${String(idCounter).padStart(3, '0')}`;
    takenIds.add(id);

    let roas: number;
    let cpa: number;
    let hookRate: number;
    let ctr: number;
    let spend: number;
    let archetype: AngleArchetype;
    let env: EnvironmentSetting;
    let human: HumanPresence;
    let text: TextOverlayType;
    let color: ColorTone;
    let vibe: AdCreative['creativeVariables']['vibeScore'];
    let whyReason: string;

    if (tier === 'Breakout Winner') {
      roas = +(3.0 + Math.random() * 1.3).toFixed(2);
      cpa = +(14 + Math.random() * 7).toFixed(2);
      hookRate = +(38 + Math.random() * 11).toFixed(1);
      ctr = +(2.4 + Math.random() * 1.1).toFixed(1);
      spend = Math.round(24000 + Math.random() * 45000);
      archetype = Math.random() > 0.4 ? 'Authentic UGC' : (Math.random() > 0.5 ? 'Founder Hands-On Demo' : 'Customer Review & Press');
      env = Math.random() > 0.5 ? 'Kitchen / Morning Counter' : 'Bathroom / Mirror';
      human = Math.random() > 0.5 ? 'Hands Holding Only' : 'Direct Gaze';
      text = Math.random() > 0.5 ? 'Bold Benefit Headline' : 'Real Review Quote';
      color = 'Warm Natural Sun';
      vibe = 'Empirically Engineered';
      whyReason = 'High thumb-stop rate driven by relatable real-world framing and instant value-proposition clarity.';
    } else if (tier === 'Core Performer') {
      roas = +(2.1 + Math.random() * 0.8).toFixed(2);
      cpa = +(22 + Math.random() * 9).toFixed(2);
      hookRate = +(30 + Math.random() * 9).toFixed(1);
      ctr = +(1.9 + Math.random() * 0.7).toFixed(1);
      spend = Math.round(8000 + Math.random() * 18000);
      archetype = archetypes[Math.floor(Math.random() * archetypes.length)];
      if (archetype === 'Sterile Studio Packshot') archetype = 'Ingredient / Texture Macro';
      env = environments[Math.floor(Math.random() * environments.length)];
      human = humanPresences[Math.floor(Math.random() * humanPresences.length)];
      text = textOverlays[Math.floor(Math.random() * textOverlays.length)];
      color = Math.random() > 0.5 ? 'Warm Natural Sun' : 'Earthy Amber';
      vibe = 'Intuitive / Semi-Tested';
      whyReason = 'Solid conversion efficiency with consistent click-through, but hook fatigue capped higher scaling.';
    } else if (tier === 'Breakeven') {
      roas = +(1.4 + Math.random() * 0.65).toFixed(2);
      cpa = +(32 + Math.random() * 15).toFixed(2);
      hookRate = +(22 + Math.random() * 8).toFixed(1);
      ctr = +(1.3 + Math.random() * 0.7).toFixed(1);
      spend = Math.round(2000 + Math.random() * 5000);
      archetype = archetypes[Math.floor(Math.random() * archetypes.length)];
      env = environments[Math.floor(Math.random() * environments.length)];
      human = humanPresences[Math.floor(Math.random() * humanPresences.length)];
      text = textOverlays[Math.floor(Math.random() * textOverlays.length)];
      color = Math.random() > 0.4 ? 'Earthy Amber' : 'Pastel Pop';
      vibe = 'Intuitive / Semi-Tested';
      whyReason = 'Struggles to stand out from generic category ads; high CPMs and moderate drop-off at cart.';
    } else {
      // Money Bleeder
      roas = +(0.4 + Math.random() * 0.85).toFixed(2);
      cpa = +(48 + Math.random() * 65).toFixed(2);
      hookRate = +(11 + Math.random() * 11).toFixed(1);
      ctr = +(0.6 + Math.random() * 0.6).toFixed(1);
      spend = Math.round(1200 + Math.random() * 4500);
      archetype = Math.random() > 0.45 ? 'Sterile Studio Packshot' : (Math.random() > 0.5 ? 'Ingredient / Texture Macro' : 'Meme / Organic Screenshot');
      env = Math.random() > 0.5 ? 'Seamless Pure White' : 'Studio Gradient';
      human = 'No Human';
      text = Math.random() > 0.5 ? 'Minimal Brand Tagline' : 'No Text';
      color = Math.random() > 0.5 ? 'Cold Clinical White' : 'Pastel Pop';
      vibe = 'High Vibes / Zero Data';
      whyReason = 'Severe ad-blindness triggered by polished catalog aesthetic. Zero emotional hook or relatable lifestyle context.';
    }

    const impressions = Math.round(spend * (28 + Math.random() * 14));
    const clicks = Math.round(impressions * (ctr / 100));
    const revenue = Math.round(spend * roas);

    // Pick a date in Q3/Q4 2026
    const month = Math.floor(Math.random() * 3) + 7; // 7, 8, 9
    const day = Math.floor(Math.random() * 28) + 1;
    const dateShipped = `2026-0${month}-${String(day).padStart(2, '0')}`;

    const channel = channels[Math.floor(Math.random() * channels.length)];

    const creative: AdCreative = {
      id,
      name: `${archetype} Variant #${String(idCounter).padStart(2, '0')}`,
      channel,
      dateShipped,
      spend,
      impressions,
      clicks,
      ctr,
      hookRate,
      cpa,
      roas,
      revenue,
      performanceTier: tier,
      creativeVariables: {
        angleArchetype: archetype,
        productProminence: (Math.random() > 0.6 ? 'High (>40%)' : (Math.random() > 0.5 ? 'Medium (20-40%)' : 'Low (<20%)')),
        humanPresence: human,
        environment: env,
        textOverlay: text,
        colorTone: color,
        vibeScore: vibe,
      },
      whyItPerformed: tier === 'Breakout Winner' || tier === 'Core Performer' ? whyReason : undefined,
      whyItFailed: tier === 'Breakeven' || tier === 'Money Bleeder' ? whyReason : undefined,
    };

    ads.push(creative);
  };

  // Remaining:
  // 8 more Breakout Winners (total 12)
  for (let i = 0; i < 8; i++) addGeneratedAd('Breakout Winner');
  // 28 Core Performers
  for (let i = 0; i < 28; i++) addGeneratedAd('Core Performer');
  // 70 Breakeven
  for (let i = 0; i < 70; i++) addGeneratedAd('Breakeven');
  // 89 Money Bleeders (total 90)
  for (let i = 0; i < 89; i++) addGeneratedAd('Money Bleeder');

  // Sort by id for consistent cataloging
  return ads.sort((a, b) => a.id.localeCompare(b.id));
}

export const COHORT_ADS: AdCreative[] = generateCohortAds();

// Summary calculations for the entire 200-ad cohort
export const COHORT_SUMMARY = {
  quarter: 'Q3/Q4 Performance Review',
  totalAds: COHORT_ADS.length, // exactly 200
  totalSpend: COHORT_ADS.reduce((acc, ad) => acc + ad.spend, 0),
  totalRevenue: COHORT_ADS.reduce((acc, ad) => acc + ad.revenue, 0),
  blendedRoas: +(COHORT_ADS.reduce((acc, ad) => acc + ad.revenue, 0) / COHORT_ADS.reduce((acc, ad) => acc + ad.spend, 0)).toFixed(2),
  avgCpa: +(COHORT_ADS.reduce((acc, ad) => acc + ad.cpa, 0) / COHORT_ADS.length).toFixed(2),
  avgHookRate: +(COHORT_ADS.reduce((acc, ad) => acc + ad.hookRate, 0) / COHORT_ADS.length).toFixed(1),
  avgCtr: +(COHORT_ADS.reduce((acc, ad) => acc + ad.ctr, 0) / COHORT_ADS.length).toFixed(2),
  tierBreakdown: {
    breakoutWinners: COHORT_ADS.filter((a) => a.performanceTier === 'Breakout Winner'),
    corePerformers: COHORT_ADS.filter((a) => a.performanceTier === 'Core Performer'),
    breakeven: COHORT_ADS.filter((a) => a.performanceTier === 'Breakeven'),
    moneyBleeders: COHORT_ADS.filter((a) => a.performanceTier === 'Money Bleeder'),
  },
};

// Power Law Stat: Revenue driven by top 12 ads vs bottom 188
const top12Revenue = COHORT_SUMMARY.tierBreakdown.breakoutWinners.reduce((acc, a) => acc + a.revenue, 0);
export const POWER_LAW_STATS = {
  topWinnersCount: 12,
  topWinnersPercentageOfSpend: +(
    (COHORT_SUMMARY.tierBreakdown.breakoutWinners.reduce((acc, a) => acc + a.spend, 0) / COHORT_SUMMARY.totalSpend) * 100
  ).toFixed(1),
  topWinnersPercentageOfRevenue: +((top12Revenue / COHORT_SUMMARY.totalRevenue) * 100).toFixed(1),
  bleedersCount: COHORT_SUMMARY.tierBreakdown.moneyBleeders.length,
  bleedersWastedSpend: COHORT_SUMMARY.tierBreakdown.moneyBleeders.reduce((acc, a) => acc + a.spend, 0),
};

// Empirical Creative Variable Impact Analysis (The "Vibes vs Reality" Matrix)
export const CREATIVE_VARIABLE_IMPACTS: CreativeVariableImpact[] = [
  {
    category: 'Visual Framing & Setting',
    variableName: 'Lived-in Kitchen / Morning Counter',
    adCount: 38,
    avgRoas: 3.18,
    avgCpa: 18.60,
    avgHookRate: 42.4,
    roasDeltaPercent: +78.6,
    status: 'High Performer',
    explanation: 'Matches consumer feed habits; feels native and un-sponsored, bypassing sub-conscious banner blindness.',
  },
  {
    category: 'Visual Framing & Setting',
    variableName: 'Seamless Pure White Studio',
    adCount: 52,
    avgRoas: 0.94,
    avgCpa: 54.20,
    avgHookRate: 15.1,
    roasDeltaPercent: -47.2,
    status: 'Vibe Trap',
    explanation: 'Designers preferred it because it looked "clean and premium". Users immediately processed it as catalogue junk mail.',
  },
  {
    category: 'Human Presence',
    variableName: 'Human Hands Holding Product (Scale)',
    adCount: 46,
    avgRoas: 2.96,
    avgCpa: 20.40,
    avgHookRate: 39.8,
    roasDeltaPercent: +66.3,
    status: 'High Performer',
    explanation: 'Establishes instant tactile scale, mirror-neuron empathy, and realistic product usage without staging fatigue.',
  },
  {
    category: 'Human Presence',
    variableName: 'Isolated Product / Zero Human Element',
    adCount: 78,
    avgRoas: 1.12,
    avgCpa: 48.90,
    avgHookRate: 16.8,
    roasDeltaPercent: -37.1,
    status: 'Vibe Trap',
    explanation: 'Lacks spatial context; leaves prospective buyers unsure of bottle size, texture, and everyday routine integration.',
  },
  {
    category: 'Human Presence',
    variableName: 'Founder Direct Gaze & Voice',
    adCount: 16,
    avgRoas: 3.24,
    avgCpa: 17.50,
    avgHookRate: 45.2,
    roasDeltaPercent: +82.0,
    status: 'High Performer',
    explanation: 'Direct human eye contact triggers highest initial 3-second hold rate (45.2%), conferring personal accountability.',
  },
  {
    category: 'Text & Copy Hooks',
    variableName: 'Bold 1-Line Pain-Point Headline',
    adCount: 42,
    avgRoas: 2.88,
    avgCpa: 21.30,
    avgHookRate: 38.6,
    roasDeltaPercent: +61.8,
    status: 'High Performer',
    explanation: 'Forces instant problem recognition in mobile feed before the user scrolls past. High cognitive fluency.',
  },
  {
    category: 'Text & Copy Hooks',
    variableName: 'Subtle Minimalist Brand Tagline',
    adCount: 64,
    avgRoas: 1.05,
    avgCpa: 52.80,
    avgHookRate: 14.7,
    roasDeltaPercent: -41.0,
    status: 'Vibe Trap',
    explanation: 'Vague poetic slogans ("Embrace the Bloom") communicate zero concrete utility to a cold prospect.',
  },
  {
    category: 'Text & Copy Hooks',
    variableName: 'Verified Customer Review Quote',
    adCount: 31,
    avgRoas: 2.74,
    avgCpa: 22.90,
    avgHookRate: 36.2,
    roasDeltaPercent: +53.9,
    status: 'High Performer',
    explanation: 'Direct social proof answers objection before click; third-party attribution outperforms brand boast.',
  },
  {
    category: 'Creative Archetype',
    variableName: 'Chaos vs Clarity Split Juxtaposition',
    adCount: 18,
    avgRoas: 3.06,
    avgCpa: 19.40,
    avgHookRate: 41.0,
    roasDeltaPercent: +71.9,
    status: 'High Performer',
    explanation: 'Left-vs-right split creates immediate cognitive contrast (before vs after), making the product value tangible.',
  },
  {
    category: 'Creative Archetype',
    variableName: 'Glossy Ingredient Texture Macro',
    adCount: 29,
    avgRoas: 1.34,
    avgCpa: 42.10,
    avgHookRate: 24.3,
    roasDeltaPercent: -24.7,
    status: 'Vibe Trap',
    explanation: 'Looks gorgeous on the art director mood board, but users had no idea what problem the serum was actually solving.',
  },
];
