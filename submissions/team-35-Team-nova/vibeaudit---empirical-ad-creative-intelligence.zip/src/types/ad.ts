export type PerformanceTier = 'Breakout Winner' | 'Core Performer' | 'Breakeven' | 'Money Bleeder';

export type AngleArchetype =
  | 'Authentic UGC'
  | 'Sterile Studio Packshot'
  | 'Founder Hands-On Demo'
  | 'Split Problem vs Solution'
  | 'Customer Review & Press'
  | 'Ingredient / Texture Macro'
  | 'Meme / Organic Screenshot';

export type ProductProminence = 'High (>40%)' | 'Medium (20-40%)' | 'Low (<20%)';

export type HumanPresence = 'Direct Gaze' | 'Hands Holding Only' | 'Background Lifestyle' | 'No Human';

export type EnvironmentSetting =
  | 'Kitchen / Morning Counter'
  | 'Bathroom / Mirror'
  | 'Seamless Pure White'
  | 'Studio Gradient'
  | 'Outdoor Sunlight'
  | 'Workshop / Loft';

export type TextOverlayType =
  | 'Bold Benefit Headline'
  | 'Real Review Quote'
  | 'Minimal Brand Tagline'
  | 'Discount / Offer Hook'
  | 'No Text';

export type ColorTone = 'Warm Natural Sun' | 'Cold Clinical White' | 'Earthy Amber' | 'Pastel Pop';

export interface AdCreative {
  id: string;
  name: string;
  channel: 'Meta Feed' | 'Instagram Stories' | 'TikTok Carousel' | 'Pinterest';
  dateShipped: string;
  spend: number;
  impressions: number;
  clicks: number;
  ctr: number; // percentage, e.g. 2.4%
  hookRate: number; // 3-second hold rate %, e.g. 41.2%
  cpa: number; // dollars, e.g. 18.50
  roas: number; // e.g. 3.42
  revenue: number;
  performanceTier: PerformanceTier;
  imageUrl?: string;
  creativeVariables: {
    angleArchetype: AngleArchetype;
    productProminence: ProductProminence;
    humanPresence: HumanPresence;
    environment: EnvironmentSetting;
    textOverlay: TextOverlayType;
    colorTone: ColorTone;
    vibeScore: 'High Vibes / Zero Data' | 'Intuitive / Semi-Tested' | 'Empirically Engineered';
  };
  whyItPerformed?: string;
  whyItFailed?: string;
}

export interface CreativeVariableImpact {
  category: string;
  variableName: string;
  adCount: number;
  avgRoas: number;
  avgCpa: number;
  avgHookRate: number;
  roasDeltaPercent: number; // relative to cohort baseline (1.78x)
  status: 'High Performer' | 'Moderate' | 'Vibe Trap';
  explanation: string;
}
