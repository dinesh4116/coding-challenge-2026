import React, { useState, useMemo } from 'react';
import { COHORT_ADS, FEATURED_IMAGES } from '../data/cohortData';
import { AdCreative, PerformanceTier, AngleArchetype } from '../types/ad';
import { Search, Filter, ArrowUpDown, LayoutGrid, Table as TableIcon, ExternalLink, ChevronLeft, ChevronRight, Eye } from 'lucide-react';

interface CohortExplorerProps {
  onSelectAd: (ad: AdCreative) => void;
  onCompareAds: (winnerId: string, loserId: string) => void;
}

export const CohortExplorer: React.FC<CohortExplorerProps> = ({ onSelectAd, onCompareAds }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTier, setSelectedTier] = useState<string>('all');
  const [selectedArchetype, setSelectedArchetype] = useState<string>('all');
  const [selectedChannel, setSelectedChannel] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'roas' | 'spend' | 'cpa' | 'hookRate'>('roas');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 24;

  const filteredAds = useMemo(() => {
    return COHORT_ADS.filter((ad) => {
      // Search
      const matchSearch =
        ad.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        ad.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        ad.creativeVariables.angleArchetype.toLowerCase().includes(searchQuery.toLowerCase()) ||
        ad.creativeVariables.environment.toLowerCase().includes(searchQuery.toLowerCase());

      if (!matchSearch) return false;

      // Tier filter
      if (selectedTier !== 'all' && ad.performanceTier !== selectedTier) return false;

      // Archetype filter
      if (selectedArchetype !== 'all' && ad.creativeVariables.angleArchetype !== selectedArchetype) return false;

      // Channel filter
      if (selectedChannel !== 'all' && ad.channel !== selectedChannel) return false;

      return true;
    }).sort((a, b) => {
      let valA = a[sortBy];
      let valB = b[sortBy];
      if (sortOrder === 'desc') {
        return valB - valA;
      }
      return valA - valB;
    });
  }, [searchQuery, selectedTier, selectedArchetype, selectedChannel, sortBy, sortOrder]);

  const totalPages = Math.ceil(filteredAds.length / pageSize) || 1;
  const paginatedAds = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredAds.slice(start, start + pageSize);
  }, [filteredAds, currentPage, pageSize]);

  const handleSortChange = (newSortBy: 'roas' | 'spend' | 'cpa' | 'hookRate') => {
    if (sortBy === newSortBy) {
      setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc');
    } else {
      setSortBy(newSortBy);
      setSortOrder(newSortBy === 'cpa' ? 'asc' : 'desc'); // For CPA, default to asc (cheaper is better)
    }
  };

  // Helper for ad thumbnail / placeholder styling
  const getAdImage = (ad: AdCreative) => {
    if (ad.imageUrl) return ad.imageUrl;
    // Map by archetype for high fidelity visual representation
    if (ad.creativeVariables.angleArchetype === 'Authentic UGC') return FEATURED_IMAGES.breakoutUgc;
    if (ad.creativeVariables.angleArchetype === 'Sterile Studio Packshot') return FEATURED_IMAGES.failedStudio;
    if (ad.creativeVariables.angleArchetype === 'Founder Hands-On Demo') return FEATURED_IMAGES.founderDemo;
    if (ad.creativeVariables.angleArchetype === 'Split Problem vs Solution') return FEATURED_IMAGES.splitComparison;
    return FEATURED_IMAGES.breakoutUgc;
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Top Header & Context */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">
              The 200-Ad Creative Genome (Q3/Q4 Cohort)
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Every single variant shipped last quarter cataloged by creative variables, spend allocation, and commercial return. Click any ad for forensic deconstruction.
            </p>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center gap-2 self-start md:self-auto">
            <div className="flex items-center bg-slate-100 p-1 rounded-lg text-xs">
              <button
                onClick={() => setViewMode('grid')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors ${
                  viewMode === 'grid'
                    ? 'bg-white text-slate-900 shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <LayoutGrid className="w-3.5 h-3.5" />
                <span>Visual Cards</span>
              </button>
              <button
                onClick={() => setViewMode('table')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors ${
                  viewMode === 'table'
                    ? 'bg-white text-slate-900 shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <TableIcon className="w-3.5 h-3.5" />
                <span>Data Table</span>
              </button>
            </div>
          </div>
        </div>

        {/* Filter Controls Row */}
        <div className="mt-6 pt-6 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Search Input */}
          <div className="relative lg:col-span-2">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Search by ID, name, angle, environment..."
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-slate-900 focus:bg-white transition-colors"
            />
          </div>

          {/* Tier Filter */}
          <div>
            <select
              value={selectedTier}
              onChange={(e) => {
                setSelectedTier(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
            >
              <option value="all">All Tiers (200 Ads)</option>
              <option value="Breakout Winner">Breakout Winners (12)</option>
              <option value="Core Performer">Core Performers (28)</option>
              <option value="Breakeven">Breakeven / Neutral (70)</option>
              <option value="Money Bleeder">Money Bleeders (90)</option>
            </select>
          </div>

          {/* Archetype Filter */}
          <div>
            <select
              value={selectedArchetype}
              onChange={(e) => {
                setSelectedArchetype(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
            >
              <option value="all">All Angles</option>
              <option value="Authentic UGC">Authentic UGC</option>
              <option value="Sterile Studio Packshot">Sterile Studio Packshot</option>
              <option value="Founder Hands-On Demo">Founder Demo</option>
              <option value="Split Problem vs Solution">Split Before/After</option>
              <option value="Customer Review & Press">Review & Press</option>
              <option value="Ingredient / Texture Macro">Ingredient Macro</option>
              <option value="Meme / Organic Screenshot">Meme / Organic</option>
            </select>
          </div>

          {/* Channel Filter */}
          <div>
            <select
              value={selectedChannel}
              onChange={(e) => {
                setSelectedChannel(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
            >
              <option value="all">All Channels</option>
              <option value="Meta Feed">Meta Feed</option>
              <option value="Instagram Stories">Instagram Stories</option>
              <option value="TikTok Carousel">TikTok Carousel</option>
              <option value="Pinterest">Pinterest</option>
            </select>
          </div>
        </div>

        {/* Sort Pills Row */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500 pt-3 border-t border-slate-100">
          <div className="flex items-center gap-2">
            <span className="font-medium text-slate-600">Sort by:</span>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => handleSortChange('roas')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  sortBy === 'roas'
                    ? 'bg-slate-900 text-white font-semibold'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                ROAS {sortBy === 'roas' && (sortOrder === 'desc' ? '↓' : '↑')}
              </button>
              <button
                onClick={() => handleSortChange('spend')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  sortBy === 'spend'
                    ? 'bg-slate-900 text-white font-semibold'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Spend {sortBy === 'spend' && (sortOrder === 'desc' ? '↓' : '↑')}
              </button>
              <button
                onClick={() => handleSortChange('cpa')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  sortBy === 'cpa'
                    ? 'bg-slate-900 text-white font-semibold'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                CPA {sortBy === 'cpa' && (sortOrder === 'asc' ? '↑' : '↓')}
              </button>
              <button
                onClick={() => handleSortChange('hookRate')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  sortBy === 'hookRate'
                    ? 'bg-slate-900 text-white font-semibold'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                3s Hook Rate {sortBy === 'hookRate' && (sortOrder === 'desc' ? '↓' : '↑')}
              </button>
            </div>
          </div>

          <div className="text-slate-500 font-mono tabular-nums">
            Showing <strong className="text-slate-900">{filteredAds.length}</strong> of 200 ads
          </div>
        </div>
      </div>

      {/* Grid View */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {paginatedAds.map((ad) => {
            const isWinner = ad.performanceTier === 'Breakout Winner';
            const isBleeder = ad.performanceTier === 'Money Bleeder';
            const isCore = ad.performanceTier === 'Core Performer';

            return (
              <div
                key={ad.id}
                onClick={() => onSelectAd(ad)}
                className="bg-white border border-slate-200 hover:border-slate-400 rounded-xl overflow-hidden shadow-xs hover:shadow-md transition-all cursor-pointer group flex flex-col"
              >
                {/* Visual Thumbnail */}
                <div className="relative aspect-square w-full bg-slate-100 overflow-hidden">
                  <img
                    src={getAdImage(ad)}
                    alt={ad.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Floating Performance Indicator */}
                  <div className="absolute top-2.5 left-2.5">
                    <span
                      className={`text-[11px] font-bold px-2 py-0.5 rounded shadow-xs ${
                        isWinner
                          ? 'bg-emerald-600 text-white'
                          : isCore
                          ? 'bg-indigo-600 text-white'
                          : isBleeder
                          ? 'bg-rose-600 text-white'
                          : 'bg-slate-700 text-white'
                      }`}
                    >
                      {ad.performanceTier}
                    </span>
                  </div>

                  <div className="absolute bottom-2.5 right-2.5 bg-black/75 backdrop-blur-xs text-white text-[11px] font-mono px-2 py-0.5 rounded">
                    {ad.channel}
                  </div>
                </div>

                {/* Content & Metrics */}
                <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    <div className="flex items-center justify-between text-xs text-slate-400 font-mono mb-1">
                      <span>{ad.id}</span>
                      <span>{ad.dateShipped}</span>
                    </div>
                    <h3 className="text-sm font-bold text-slate-900 line-clamp-1 group-hover:text-indigo-600 transition-colors">
                      {ad.name}
                    </h3>
                    <div className="text-xs text-slate-500 mt-1 line-clamp-1">
                      {ad.creativeVariables.angleArchetype} · {ad.creativeVariables.environment}
                    </div>
                  </div>

                  {/* 3 Metric Pills */}
                  <div className="grid grid-cols-3 gap-1.5 pt-2 border-t border-slate-100 text-center text-xs">
                    <div className="bg-slate-50 p-1.5 rounded">
                      <div className="text-[10px] text-slate-400 uppercase font-medium">ROAS</div>
                      <div
                        className={`font-mono font-bold tabular-nums ${
                          isWinner
                            ? 'text-emerald-700'
                            : isBleeder
                            ? 'text-rose-700'
                            : 'text-slate-900'
                        }`}
                      >
                        {ad.roas.toFixed(2)}x
                      </div>
                    </div>

                    <div className="bg-slate-50 p-1.5 rounded">
                      <div className="text-[10px] text-slate-400 uppercase font-medium">CPA</div>
                      <div className="font-mono font-bold text-slate-800 tabular-nums">
                        ${ad.cpa.toFixed(1)}
                      </div>
                    </div>

                    <div className="bg-slate-50 p-1.5 rounded">
                      <div className="text-[10px] text-slate-400 uppercase font-medium">Hook</div>
                      <div className="font-mono font-bold text-slate-800 tabular-nums">
                        {ad.hookRate.toFixed(1)}%
                      </div>
                    </div>
                  </div>

                  {/* Vibe score badge */}
                  <div className="text-[11px] text-slate-500 flex items-center justify-between pt-1">
                    <span className="truncate">{ad.creativeVariables.textOverlay}</span>
                    <span className="text-indigo-600 font-semibold group-hover:translate-x-0.5 transition-transform shrink-0">
                      View →
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Table View */
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/80 text-slate-500 font-semibold">
                  <th className="py-3 px-4">Ad ID & Name</th>
                  <th className="py-3 px-3">Tier</th>
                  <th className="py-3 px-3">Archetype</th>
                  <th className="py-3 px-3">Setting</th>
                  <th className="py-3 px-3">Channel</th>
                  <th className="py-3 px-3 text-right">Spend</th>
                  <th className="py-3 px-3 text-right">ROAS</th>
                  <th className="py-3 px-3 text-right">CPA</th>
                  <th className="py-3 px-3 text-right">Hook (3s)</th>
                  <th className="py-3 px-3 text-right">CTR</th>
                  <th className="py-3 px-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {paginatedAds.map((ad) => {
                  const isWinner = ad.performanceTier === 'Breakout Winner';
                  const isBleeder = ad.performanceTier === 'Money Bleeder';

                  return (
                    <tr
                      key={ad.id}
                      onClick={() => onSelectAd(ad)}
                      className="hover:bg-slate-50/80 transition-colors cursor-pointer"
                    >
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">{ad.name}</div>
                        <div className="text-[11px] text-slate-400 font-mono">{ad.id}</div>
                      </td>
                      <td className="py-3 px-3">
                        <span
                          className={`inline-block font-semibold px-2 py-0.5 rounded text-[10px] ${
                            isWinner
                              ? 'bg-emerald-100 text-emerald-800'
                              : isBleeder
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {ad.performanceTier}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-slate-700">
                        {ad.creativeVariables.angleArchetype}
                      </td>
                      <td className="py-3 px-3 text-slate-500">
                        {ad.creativeVariables.environment}
                      </td>
                      <td className="py-3 px-3 text-slate-500 font-mono">
                        {ad.channel}
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700">
                        ${ad.spend.toLocaleString()}
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums font-bold">
                        <span className={isWinner ? 'text-emerald-700' : isBleeder ? 'text-rose-700' : 'text-slate-900'}>
                          {ad.roas.toFixed(2)}x
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-800">
                        ${ad.cpa.toFixed(2)}
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-800">
                        {ad.hookRate.toFixed(1)}%
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-800">
                        {ad.ctr.toFixed(1)}%
                      </td>
                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectAd(ad);
                          }}
                          className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition-colors text-[11px]"
                        >
                          Deconstruct
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between border-t border-slate-200 pt-4">
          <div className="text-xs text-slate-500 font-mono tabular-nums">
            Page {currentPage} of {totalPages}
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            {Array.from({ length: totalPages }).map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentPage(idx + 1)}
                className={`w-7 h-7 text-xs rounded font-medium transition-colors ${
                  currentPage === idx + 1
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {idx + 1}
              </button>
            ))}
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
