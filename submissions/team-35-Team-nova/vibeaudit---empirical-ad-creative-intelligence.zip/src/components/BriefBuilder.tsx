import React, { useState } from 'react';
import { Sparkles, FileText, Download, Copy, Check, Printer, AlertTriangle, ShieldCheck, RefreshCw, Layers } from 'lucide-react';

interface BriefData {
  briefMetadata?: {
    title?: string;
    quarter?: string;
    targetGoal?: string;
    budgetAllocation?: string;
    productionTarget?: string;
    targetMetrics?: {
      targetRoas?: string;
      targetCpa?: string;
      targetHookRate?: string;
      targetCtr?: string;
    };
  };
  executiveSummary?: {
    theProblem?: string;
    theEmpiricalShift?: string;
    coreHypothesis?: string;
  };
  creativeDirectives?: Array<{
    conceptId?: string;
    name?: string;
    primaryArchetype?: string;
    empiricalJustification?: string;
    visualFraming?: string;
    lightingAndSet?: string;
    humanElement?: string;
    copyHookFormulas?: string[];
    designerExecutionNotes?: string;
    predictedPerformanceRange?: string;
  }>;
  testingMatrix?: Array<{
    testCell?: string;
    variableIsolated?: string;
    controlState?: string;
    variantState?: string;
    hypothesis?: string;
    successMetric?: string;
  }>;
  bannedVibeRules?: Array<{
    bannedTrope?: string;
    whyItKillsRoas?: string;
    allowedAlternative?: string;
  }>;
  productionChecklist?: string[];
}

const DEFAULT_BRIEF: BriefData = {
  briefMetadata: {
    title: 'Q1 Performance Creative Brief: Empirical Scaled Acquisition',
    quarter: 'Q1 2027',
    targetGoal: 'Scale DTC Acquisition at <$20 CPA (Phase 1)',
    budgetAllocation: '$180,000 across 24 variants',
    productionTarget: '24 systematic variants (reduced from 200 unguided shots)',
    targetMetrics: {
      targetRoas: '2.85x blended',
      targetCpa: '$18.50',
      targetHookRate: '42.0% 3-sec thumb-stop',
      targetCtr: '2.6%',
    },
  },
  executiveSummary: {
    theProblem: 'In Q3/Q4, our team shipped 200 creative variants. Only 12 broke out (6%), while 90 money-bleeders burned $198.4k because creative was greenlit on aesthetic instincts (sterile studio packshots, unanchored floating bottles, poetic slogans).',
    theEmpiricalShift: 'This brief eliminates creative guesswork. Instead of flooding Meta with 200 random visual vibes, we will produce exactly 24 disciplined creative cells isolating 3 proven statistical winners: Lived-in Countertop UGC (+78.6% ROAS), Founder Direct Gaze (+82.0% ROAS), and Chaos vs Clarity Split (+71.9% ROAS).',
    coreHypothesis: 'Grounding the product in authentic, relatable daily friction points with visible human interaction and 1-line objection headlines will compress blended CPA by 44% and elevate blended ROAS above 2.8x.',
  },
  creativeDirectives: [
    {
      conceptId: 'DIR-01',
      name: 'The 7:15 AM Kitchen Countertop Ritual',
      primaryArchetype: 'Authentic Lived-in UGC',
      empiricalJustification: 'Lived-in kitchen counters drove 3.18x avg ROAS across 38 ads in Q3/Q4 (+78.6% above cohort baseline).',
      visualFraming: 'Natural morning sunlight hitting an unpolished wood or stone countertop. Subtle morning steam from a mug in the background. Camera held at eye level to replicate smartphone perspective.',
      lightingAndSet: 'Warm 3200K natural window light. No high-key studio strobes. Retain organic environment details (spilled coffee beans, linen towel).',
      humanElement: 'Human hand reaching in from frame left or holding bottle at a 45-degree angle to provide immediate physical scale.',
      copyHookFormulas: [
        '"The afternoon slump is not a willpower issue. It is a cortisol drop."',
        '"Replace 6 morning pills with 1 dropper before your first meeting."',
        '"Why 14,000 remote workers stopped buying 3PM iced matchas."',
      ],
      designerExecutionNotes: 'Do not color-grade like a high-fashion perfume campaign. Keep contrast natural. Text overlay must use high-contrast sans serif centered or in top third.',
      predictedPerformanceRange: '3.2x – 3.9x ROAS | $15 – $19 CPA',
    },
    {
      conceptId: 'DIR-02',
      name: 'The Founder Transparency Bench Demo',
      primaryArchetype: 'Founder Hands-On Demo',
      empiricalJustification: 'Founder direct eye contact delivered 45.2% average thumb-stop rate in Q3/Q4—the highest of any visual archetype.',
      visualFraming: 'Founder sitting in natural studio workshop, holding product directly towards the camera lens (filling 35% of frame). Natural direct eye contact.',
      lightingAndSet: 'Diffused daylight. Workstation background with brown packaging boxes and green plants to signal small-batch craftsmanship.',
      humanElement: 'Founder face in upper half; two hands presenting bottle clearly in lower third.',
      copyHookFormulas: [
        '"I spent 2 years formulating this because every clean serum gave me breakouts."',
        '"Why we refuse to use synthetic preservatives (and what we use instead)."',
        '"What 90% of adaptogen brands hide in their proprietary blend label."',
      ],
      designerExecutionNotes: 'Authenticity is the conversion engine. Avoid airbrushing skin texture. Keep frame grounded and approachable.',
      predictedPerformanceRange: '3.0x – 3.6x ROAS | $16 – $21 CPA',
    },
    {
      conceptId: 'DIR-03',
      name: 'Chaos vs Clarity Split Juxtaposition',
      primaryArchetype: 'Problem vs Solution Split',
      empiricalJustification: 'Split before/after visual contrast generated 3.06x ROAS and $19.40 CPA across 18 cohort tests.',
      visualFraming: 'Top-down flat lay divided down center. Left: 12 cluttered medicine pill bottles with messy sticky notes. Right: 1 sleek amber bottle on neutral linen with clean green botanical sprig.',
      lightingAndSet: 'Consistent overhead lighting. High visual clarity across both sides with visible division line.',
      humanElement: 'Optional hands organizing right side, or purely product-centric split.',
      copyHookFormulas: [
        '"Before: 12 confusing supplements. After: 1 daily dropper."',
        '"Simplify your morning from 15 minutes of anxiety to 10 seconds of clarity."',
      ],
      designerExecutionNotes: 'The left side must look legitimately chaotic and stressful; the right side must evoke an instant sigh of relief.',
      predictedPerformanceRange: '2.9x – 3.4x ROAS | $17 – $22 CPA',
    },
  ],
  testingMatrix: [
    {
      testCell: 'Cell A (Hook Isolated)',
      variableIsolated: 'Headline: Pain Point vs Direct Benefit',
      controlState: '"Tired of 3PM fatigue?"',
      variantState: '"Sustained energy from 8am to 6pm without the crash."',
      hypothesis: 'Direct positive benefit will decrease CPA by 18% on Meta Feed.',
      successMetric: 'CTR > 2.4%, CPA < $18.00',
    },
    {
      testCell: 'Cell B (Visual Framing)',
      variableIsolated: 'Human Hand Holding vs Still Counter Placement',
      controlState: 'Hand grasping bottle firmly',
      variantState: 'Bottle placed next to steaming coffee mug',
      hypothesis: 'Hand interaction creates physical mirror empathy, lifting 3s hook rate by +25%.',
      successMetric: 'Hook Rate > 42%',
    },
    {
      testCell: 'Cell C (Social Proof)',
      variableIsolated: 'Star Rating Badge vs Real Customer Review Quote',
      controlState: '5-Star Graphic + "Rated 4.9 by 2,000+ customers"',
      variantState: '"The only thing that stopped my postpartum brain fog." — Sarah K.',
      hypothesis: 'Specific first-person customer testimonial outperforms generic badge by +32% ROAS.',
      successMetric: 'ROAS > 3.2x',
    },
  ],
  bannedVibeRules: [
    {
      bannedTrope: 'Seamless Pure White Studio Packshots',
      whyItKillsRoas: 'Generated 0.94x average ROAS in Q3/Q4 (-47.2% below baseline). Mobile users process it as catalog spam.',
      allowedAlternative: 'Lived-in morning kitchen counter, bathroom shelf, or natural desk setup with realistic daylight.',
    },
    {
      bannedTrope: 'Isolated Floating Bottles with Zero Human Element',
      whyItKillsRoas: 'Delivered only 16.8% thumb-stop rate and $48.90 CPA due to lack of physical scale and tactile empathy.',
      allowedAlternative: 'Always include human hands interacting with bottle or founder holding it to establish scale.',
    },
    {
      bannedTrope: 'Poetic Brand Slogans ("Embrace the Bloom")',
      whyItKillsRoas: 'Averaged 1.05x ROAS and $52.80 CPA. Vague brand marketing communicates zero functional utility to cold traffic.',
      allowedAlternative: 'Bold 1-line customer objection hook, quantitative timeframe, or real customer quote.',
    },
  ],
  productionChecklist: [
    'Image resolution: 1080x1350 (4:5) for Feed and 1080x1920 (9:16) for Stories/Reels',
    'Product occupies at least 30% of canvas area with clear label legibility',
    'Headline text rendered in high-contrast bold sans-serif with minimum 32pt scale on mobile',
    'No unverified medical claims; focus on daily ritual and mental clarity benefits',
    'Visual contains real-world lighting with authentic physical shadows',
    'All 24 variants strictly assigned to isolated test cells in the Testing Matrix',
  ],
};

export const BriefBuilder: React.FC = () => {
  const [brief, setBrief] = useState<BriefData>(DEFAULT_BRIEF);
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);

  // Brief configuration inputs
  const [quarter, setQuarter] = useState('Q1 2027');
  const [campaignGoal, setCampaignGoal] = useState('Scale DTC Customer Acquisition at <$20 CPA');
  const [targetRoas, setTargetRoas] = useState('2.85x');
  const [targetCpa, setTargetCpa] = useState('$18.50');
  const [budget, setBudget] = useState('$180,000');
  const [variantsCount, setVariantsCount] = useState(24);

  const handleGenerateBrief = async () => {
    setIsGenerating(true);
    try {
      const response = await fetch('/api/generate-brief', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetQuarter: quarter,
          campaignGoal,
          targetRoas,
          targetCpa,
          budget,
          totalVariants: variantsCount,
          selectedWinningArchetypes: [
            'Authentic Countertop UGC (+78.6% ROAS lift in Q3/Q4)',
            'Founder Hands-On Demo (+82.0% ROAS lift in Q3/Q4)',
            'Chaos vs Clarity Split Comparison (+71.9% ROAS lift in Q3/Q4)',
          ],
          bannedVibeTropes: [
            'Seamless pure white studio packshots (-47.2% ROAS in Q3/Q4)',
            'Floating unanchored bottles with zero human presence',
            'Vague poetic brand slogans ("Embrace Your Glow")',
          ],
        }),
      });

      const resData = await response.json();
      if (resData.success && resData.data) {
        setBrief(resData.data);
      }
    } catch (err) {
      console.error('Error generating brief:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopyMarkdown = () => {
    const md = `# ${brief.briefMetadata?.title || 'Q1 Performance Creative Brief'}
Quarter: ${brief.briefMetadata?.quarter}
Goal: ${brief.briefMetadata?.targetGoal}
Target ROAS: ${brief.briefMetadata?.targetMetrics?.targetRoas}
Target CPA: ${brief.briefMetadata?.targetMetrics?.targetCpa}

## Executive Summary
${brief.executiveSummary?.theProblem}
${brief.executiveSummary?.theEmpiricalShift}

## Creative Directives
${brief.creativeDirectives
  ?.map(
    (d) => `### ${d.name} (${d.conceptId})
- Archetype: ${d.primaryArchetype}
- Framing: ${d.visualFraming}
- Lighting: ${d.lightingAndSet}
- Copy Hooks:
${d.copyHookFormulas?.map((c) => `  * ${c}`).join('\n')}
- Execution Notes: ${d.designerExecutionNotes}
`
  )
  .join('\n')}

## Banned Vibe Tropes
${brief.bannedVibeRules?.map((b) => `- BANNED: ${b.bannedTrope} (Why: ${b.whyItKillsRoas}) -> USE: ${b.allowedAlternative}`).join('\n')}
`;

    navigator.clipboard.writeText(md);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Top Configuration Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 uppercase tracking-wider">
              <FileText className="w-3.5 h-3.5" />
              <span>The Anti-Vibes Creative Brief Engine</span>
            </div>
            <h1 className="text-xl font-extrabold text-slate-900 tracking-tight mt-1">
              Data-Backed Creative Brief for Next Quarter
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Replaces vague art direction with mathematical guardrails derived from 200 ads. Ship 24 systematic tests instead of 200 blind shots.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyMarkdown}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-xs"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied Markdown' : 'Copy Brief'}</span>
            </button>
            <button
              onClick={() => window.print()}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / PDF</span>
            </button>
          </div>
        </div>

        {/* Inputs Strip */}
        <div className="mt-6 pt-6 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
          <div>
            <label className="block text-slate-500 font-medium mb-1">Target Quarter</label>
            <input
              type="text"
              value={quarter}
              onChange={(e) => setQuarter(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-md font-medium text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-slate-500 font-medium mb-1">Campaign Goal</label>
            <input
              type="text"
              value={campaignGoal}
              onChange={(e) => setCampaignGoal(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-md font-medium text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
            />
          </div>
          <div>
            <label className="block text-slate-500 font-medium mb-1">Target ROAS</label>
            <input
              type="text"
              value={targetRoas}
              onChange={(e) => setTargetRoas(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-md font-medium font-mono text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
            />
          </div>
          <div>
            <label className="block text-slate-500 font-medium mb-1">Target CPA</label>
            <input
              type="text"
              value={targetCpa}
              onChange={(e) => setTargetCpa(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-md font-medium font-mono text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
            />
          </div>
          <div>
            <label className="block text-slate-500 font-medium mb-1">Batch Size</label>
            <input
              type="number"
              value={variantsCount}
              onChange={(e) => setVariantsCount(Number(e.target.value))}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-md font-medium font-mono text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
            />
          </div>
        </div>

        <div className="mt-4 pt-3 flex justify-end">
          <button
            onClick={handleGenerateBrief}
            disabled={isGenerating}
            className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-bold hover:bg-slate-800 disabled:opacity-50 transition-colors flex items-center gap-2 shadow-sm"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Re-synthesizing Brief with Gemini...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>Synthesize Empirical Brief with Gemini</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* The Printable / Viewable Brief Document */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-10 shadow-sm space-y-10">
        {/* Document Header */}
        <div className="border-b border-slate-200 pb-6 space-y-2">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 font-mono">
            <span>DOC-ID: CB-{brief.briefMetadata?.quarter?.replace(/\s+/g, '') || 'Q12027'}</span>
            <span>STATUS: EMPIRICALLY APPROVED</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            {brief.briefMetadata?.title}
          </h2>
          <div className="flex flex-wrap gap-4 text-xs text-slate-600 pt-1">
            <span><strong>Target:</strong> {brief.briefMetadata?.targetGoal}</span>
            <span>·</span>
            <span><strong>Budget:</strong> {brief.briefMetadata?.budgetAllocation}</span>
            <span>·</span>
            <span><strong>Variants:</strong> {brief.briefMetadata?.productionTarget}</span>
          </div>
        </div>

        {/* 4 Target Metrics Strip */}
        {brief.briefMetadata?.targetMetrics && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-slate-50 rounded-xl border border-slate-100 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-semibold">Target ROAS</span>
              <div className="font-mono text-base font-bold text-slate-900 mt-0.5">
                {brief.briefMetadata.targetMetrics.targetRoas}
              </div>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-semibold">Target CPA</span>
              <div className="font-mono text-base font-bold text-slate-900 mt-0.5">
                {brief.briefMetadata.targetMetrics.targetCpa}
              </div>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-semibold">Target Hook (3s)</span>
              <div className="font-mono text-base font-bold text-slate-900 mt-0.5">
                {brief.briefMetadata.targetMetrics.targetHookRate}
              </div>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-semibold">Target CTR</span>
              <div className="font-mono text-base font-bold text-slate-900 mt-0.5">
                {brief.briefMetadata.targetMetrics.targetCtr}
              </div>
            </div>
          </div>
        )}

        {/* 1. Executive Summary */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            1. Executive Summary & The Empirical Shift
          </h3>
          <div className="space-y-2 text-xs sm:text-sm text-slate-700 leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-100">
            <p>
              <strong className="text-slate-900">The Problem:</strong> {brief.executiveSummary?.theProblem}
            </p>
            <p>
              <strong className="text-slate-900">The Shift:</strong> {brief.executiveSummary?.theEmpiricalShift}
            </p>
            <p>
              <strong className="text-slate-900">Core Hypothesis:</strong> {brief.executiveSummary?.coreHypothesis}
            </p>
          </div>
        </div>

        {/* 2. Creative Directives (Specific production concepts) */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            2. Production Creative Directives (The 3 Approved Concepts)
          </h3>
          <div className="grid grid-cols-1 gap-6">
            {brief.creativeDirectives?.map((dir, idx) => (
              <div key={idx} className="border border-slate-200 rounded-xl p-5 space-y-4 bg-white">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                  <div>
                    <span className="text-xs font-mono font-bold text-indigo-600 mr-2">{dir.conceptId}</span>
                    <strong className="text-sm font-bold text-slate-900">{dir.name}</strong>
                  </div>
                  <span className="text-xs font-medium text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded self-start sm:self-auto">
                    {dir.predictedPerformanceRange}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-2">
                    <div>
                      <strong className="text-slate-800 block">Visual Framing & Perspective:</strong>
                      <span className="text-slate-600">{dir.visualFraming}</span>
                    </div>
                    <div>
                      <strong className="text-slate-800 block">Lighting & Set Dressing:</strong>
                      <span className="text-slate-600">{dir.lightingAndSet}</span>
                    </div>
                    <div>
                      <strong className="text-slate-800 block">Human Element:</strong>
                      <span className="text-slate-600">{dir.humanElement}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div>
                      <strong className="text-slate-800 block">Required Copy Hook Formulas:</strong>
                      <ul className="list-disc pl-4 space-y-1 text-slate-700 mt-1">
                        {dir.copyHookFormulas?.map((hook, hIdx) => (
                          <li key={hIdx}>{hook}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="pt-2 border-t border-slate-100">
                      <strong className="text-slate-800 block">Designer Execution Mandate:</strong>
                      <span className="text-slate-600">{dir.designerExecutionNotes}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 3. The Systematic Testing Matrix */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            3. The 24-Cell Systematic Testing Matrix (Isolate Single Variables)
          </h3>
          <p className="text-xs text-slate-500">
            Never change headline and visual simultaneously. Isolate one variable per cell to know exactly which element moved the metric.
          </p>

          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                  <th className="py-2.5 px-3">Test Cell</th>
                  <th className="py-2.5 px-3">Variable Isolated</th>
                  <th className="py-2.5 px-3">Control (A)</th>
                  <th className="py-2.5 px-3">Variant (B)</th>
                  <th className="py-2.5 px-3">Hypothesis</th>
                  <th className="py-2.5 px-3">Primary Gate</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {brief.testingMatrix?.map((test, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/50">
                    <td className="py-3 px-3 font-mono font-bold text-slate-900">{test.testCell}</td>
                    <td className="py-3 px-3 font-semibold text-slate-800">{test.variableIsolated}</td>
                    <td className="py-3 px-3 text-slate-600">{test.controlState}</td>
                    <td className="py-3 px-3 text-slate-900 font-medium">{test.variantState}</td>
                    <td className="py-3 px-3 text-slate-600">{test.hypothesis}</td>
                    <td className="py-3 px-3 font-mono font-semibold text-emerald-700">{test.successMetric}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* 4. Banned Vibe Tropes (Negative Constraints) */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-rose-900 uppercase tracking-wider flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-600" />
            <span>4. Banned Vibe Tropes (Zero Budget Permitted)</span>
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {brief.bannedVibeRules?.map((rule, idx) => (
              <div key={idx} className="p-4 bg-rose-50/60 border border-rose-200 rounded-xl text-xs space-y-2">
                <strong className="text-rose-900 font-bold block">{rule.bannedTrope}</strong>
                <p className="text-rose-800 leading-relaxed">
                  <span className="font-semibold">Why banned:</span> {rule.whyItKillsRoas}
                </p>
                <div className="pt-2 border-t border-rose-200 text-slate-800">
                  <span className="font-bold text-emerald-800">Allowed Alternative:</span> {rule.allowedAlternative}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 5. Production & Export Checklist */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            5. Pre-Flight Production Checklist
          </h3>
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-700">
              {brief.productionChecklist?.map((item, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <span className="text-emerald-600 font-bold">✓</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
