import React from 'react';
import { Sparkles, FileText, BarChart3, Layers, Swords, Search } from 'lucide-react';

interface TopNavProps {
  activeTab: 'overview' | 'explorer' | 'battle' | 'evaluator' | 'brief';
  setActiveTab: (tab: 'overview' | 'explorer' | 'battle' | 'evaluator' | 'brief') => void;
  onOpenQuickEvaluate?: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({ activeTab, setActiveTab }) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text element Brand wordmark */}
          <button
            onClick={() => setActiveTab('overview')}
            className="flex items-center gap-2.5 text-left text-slate-900 font-bold text-lg tracking-tight whitespace-nowrap shrink-0 hover:opacity-90 transition-opacity"
          >
            <span className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center font-mono text-sm font-semibold">
              VA
            </span>
            <span>VibeAudit</span>
            <span className="text-xs font-normal text-slate-500 hidden sm:inline">
              · DTC Creative Intelligence
            </span>
          </button>

          {/* Zone 2: Clean single-line nav links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <button
              onClick={() => setActiveTab('overview')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
                activeTab === 'overview'
                  ? 'text-slate-900 border-slate-900 font-semibold'
                  : 'border-transparent'
              }`}
            >
              Cohort Diagnostics
            </button>
            <button
              onClick={() => setActiveTab('explorer')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
                activeTab === 'explorer'
                  ? 'text-slate-900 border-slate-900 font-semibold'
                  : 'border-transparent'
              }`}
            >
              200-Ad Genome
            </button>
            <button
              onClick={() => setActiveTab('battle')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
                activeTab === 'battle'
                  ? 'text-slate-900 border-slate-900 font-semibold'
                  : 'border-transparent'
              }`}
            >
              Winner vs Bleeder
            </button>
            <button
              onClick={() => setActiveTab('evaluator')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
                activeTab === 'evaluator'
                  ? 'text-slate-900 border-slate-900 font-semibold'
                  : 'border-transparent'
              }`}
            >
              AI Pre-Flight Lab
            </button>
            <button
              onClick={() => setActiveTab('brief')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
                activeTab === 'brief'
                  ? 'text-slate-900 border-slate-900 font-semibold'
                  : 'border-transparent'
              }`}
            >
              Next-Q Brief
            </button>
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setActiveTab('brief')}
              className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 shadow-sm flex items-center gap-1.5"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Generate Q1 Brief</span>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile navigation row */}
      <div className="md:hidden flex items-center overflow-x-auto border-t border-slate-100 px-4 py-2 gap-4 text-xs font-medium text-slate-600 bg-slate-50">
        <button
          onClick={() => setActiveTab('overview')}
          className={`whitespace-nowrap shrink-0 ${activeTab === 'overview' ? 'text-slate-900 font-bold' : ''}`}
        >
          Diagnostics
        </button>
        <button
          onClick={() => setActiveTab('explorer')}
          className={`whitespace-nowrap shrink-0 ${activeTab === 'explorer' ? 'text-slate-900 font-bold' : ''}`}
        >
          200 Ads
        </button>
        <button
          onClick={() => setActiveTab('battle')}
          className={`whitespace-nowrap shrink-0 ${activeTab === 'battle' ? 'text-slate-900 font-bold' : ''}`}
        >
          Arena
        </button>
        <button
          onClick={() => setActiveTab('evaluator')}
          className={`whitespace-nowrap shrink-0 ${activeTab === 'evaluator' ? 'text-slate-900 font-bold' : ''}`}
        >
          Lab
        </button>
        <button
          onClick={() => setActiveTab('brief')}
          className={`whitespace-nowrap shrink-0 ${activeTab === 'brief' ? 'text-slate-900 font-bold' : ''}`}
        >
          Brief
        </button>
      </div>
    </header>
  );
};
