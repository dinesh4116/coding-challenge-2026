import React, { useState } from 'react';
import { COHORT_SUMMARY, POWER_LAW_STATS, CREATIVE_VARIABLE_IMPACTS, FEATURED_IMAGES } from '../data/cohortData';
import { TrendingUp, TrendingDown, AlertTriangle, ArrowRight, CheckCircle2, DollarSign, Filter, Sparkles, Eye, ShieldAlert } from 'lucide-react';

interface CohortOverviewProps {
  onNavigateTab: (tab: 'overview' | 'explorer' | 'battle' | 'evaluator' | 'brief') => void;
  onSelectAdForDetail?: (adId: string) => void;
}

export const CohortOverview: React.FC<CohortOverviewProps> = ({ onNavigateTab, onSelectAdForDetail }) => {
  const [impactFilter, setImpactFilter] = useState<'all' | 'high' | 'traps'>('all');

  const filteredImpacts = CREATIVE_VARIABLE_IMPACTS.filter((item) => {
    if (impactFilter === 'high') return item.status === 'High Performer';
    if (impactFilter === 'traps') return item.status === 'Vibe Trap';
    return true;
  });

  return (
    <div className="space-y-10 pb-16">
      {/* Hero Headline & Problem Statement */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 border-b border-slate-100 pb-6">
          <div className="max-w-3xl space-y-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-700 uppercase tracking-wider">
              <span>Quarterly Creative Post-Mortem</span>
              <span aria-hidden="true">·</span>
              <span>200 Image Ads Analyzed</span>
              <span aria-hidden="true">·</span>
              <span>$624.8k Cohort Spend</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Why 80% of Image Ads Failed — And How to Stop Writing Briefs on "Vibes"
            </h1>
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
              Last quarter, your team shipped 200 creative variants. Only 12 broke out. The creative director called the winners "serendipitous" and the losers "good brand equity." Below is the mathematical breakdown of what actually stopped the scroll and drove checkout conversion.
            </p>
          </div>

          <div className="flex flex-wrap lg:flex-col gap-2 shrink-0">
            <button
              onClick={() => onNavigateTab('brief')}
              className="px-4 py-2.5 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition-colors flex items-center justify-center gap-2 shadow-sm"
            >
              <span>Build Empirical Q1 Brief</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onNavigateTab('battle')}
              className="px-4 py-2.5 bg-slate-100 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-200 transition-colors flex items-center justify-center gap-2"
            >
              <span>Compare Winner vs Bleeder</span>
            </button>
          </div>
        </div>

        {/* 4-Column KPI Strip (tabular figures, clean metadata) */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-6">
          <div className="p-4 rounded-lg bg-slate-50 border border-slate-100">
            <div className="text-xs text-slate-500 font-medium">Total Ads Shipped</div>
            <div className="text-2xl font-bold text-slate-900 font-mono tabular-nums mt-1">200</div>
            <div className="text-xs text-slate-500 mt-1">
              Across Meta, IG & TikTok
            </div>
          </div>

          <div className="p-4 rounded-lg bg-slate-50 border border-slate-100">
            <div className="text-xs text-slate-500 font-medium">Breakout Winners (Top 6%)</div>
            <div className="text-2xl font-bold text-emerald-700 font-mono tabular-nums mt-1">
              {POWER_LAW_STATS.topWinnersCount} Ads
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Drove <span className="font-semibold text-slate-700 font-mono">{POWER_LAW_STATS.topWinnersPercentageOfRevenue}%</span> of revenue
            </div>
          </div>

          <div className="p-4 rounded-lg bg-slate-50 border border-slate-100">
            <div className="text-xs text-slate-500 font-medium">Money Bleeders (Failed)</div>
            <div className="text-2xl font-bold text-rose-700 font-mono tabular-nums mt-1">
              {POWER_LAW_STATS.bleedersCount} Ads
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Burned <span className="font-semibold text-rose-600 font-mono">${(POWER_LAW_STATS.bleedersWastedSpend / 1000).toFixed(1)}k</span> at &lt;1.2x ROAS
            </div>
          </div>

          <div className="p-4 rounded-lg bg-slate-50 border border-slate-100">
            <div className="text-xs text-slate-500 font-medium">Blended Cohort ROAS</div>
            <div className="text-2xl font-bold text-slate-900 font-mono tabular-nums mt-1">
              {COHORT_SUMMARY.blendedRoas}x
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Target was <span className="font-semibold font-mono">2.40x</span> (Vibe drag)
            </div>
          </div>
        </div>
      </div>

      {/* The Power Law Reality: Top Performer vs Bleeder Case Study */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              The Aesthetic Illusion: 3.84x ROAS vs 0.62x ROAS
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              What the design team thought was "messy" printed $246k in revenue. What they thought was "clean luxury" lost $18k.
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('battle')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 transition-colors flex items-center gap-1 self-start sm:self-auto"
          >
            <span>Open Interactive Side-by-Side Arena</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Winner Card */}
          <div className="border border-emerald-200 bg-emerald-50/30 rounded-xl p-5 flex flex-col sm:flex-row gap-5 items-start">
            <div className="w-full sm:w-44 h-44 rounded-lg overflow-hidden bg-slate-200 shrink-0 border border-emerald-300">
              <img
                src={FEATURED_IMAGES.breakoutUgc}
                alt="Breakout Winner: Morning Countertop UGC"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="space-y-3 flex-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded">
                  BREAKOUT WINNER · AD-014
                </span>
                <span className="text-xs text-slate-500 font-mono">Meta Feed</span>
              </div>
              <h3 className="text-sm font-bold text-slate-900">
                Morning Routine Messy Countertop #02
              </h3>
              <div className="grid grid-cols-3 gap-2 py-2 border-y border-emerald-100 text-xs">
                <div>
                  <span className="text-slate-500 block">ROAS</span>
                  <span className="font-bold text-emerald-700 font-mono text-sm tabular-nums">3.84x</span>
                </div>
                <div>
                  <span className="text-slate-500 block">CPA</span>
                  <span className="font-bold text-slate-900 font-mono text-sm tabular-nums">$16.40</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Hook (3s)</span>
                  <span className="font-bold text-slate-900 font-mono text-sm tabular-nums">44.8%</span>
                </div>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                <strong className="text-slate-800">Why it worked:</strong> Lived-in morning counter with natural steam & sunlight looked native in the feed. A bold 1-line headline directly articulated afternoon brain fog relief.
              </p>
            </div>
          </div>

          {/* Loser Card */}
          <div className="border border-rose-200 bg-rose-50/30 rounded-xl p-5 flex flex-col sm:flex-row gap-5 items-start">
            <div className="w-full sm:w-44 h-44 rounded-lg overflow-hidden bg-slate-200 shrink-0 border border-rose-300">
              <img
                src={FEATURED_IMAGES.failedStudio}
                alt="Money Bleeder: Minimalist Studio Packshot"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="space-y-3 flex-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-rose-800 bg-rose-100 px-2.5 py-0.5 rounded">
                  MONEY BLEEDER · AD-082
                </span>
                <span className="text-xs text-slate-500 font-mono">Meta Feed</span>
              </div>
              <h3 className="text-sm font-bold text-slate-900">
                Minimalist Studio Packshot White #09
              </h3>
              <div className="grid grid-cols-3 gap-2 py-2 border-y border-rose-100 text-xs">
                <div>
                  <span className="text-slate-500 block">ROAS</span>
                  <span className="font-bold text-rose-700 font-mono text-sm tabular-nums">0.62x</span>
                </div>
                <div>
                  <span className="text-slate-500 block">CPA</span>
                  <span className="font-bold text-rose-800 font-mono text-sm tabular-nums">$82.50</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Hook (3s)</span>
                  <span className="font-bold text-slate-900 font-mono text-sm tabular-nums">14.2%</span>
                </div>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                <strong className="text-slate-800">The "Vibe Trap":</strong> Approved because it felt "clean and upscale." In reality, users instantly scrolled past because it looked like cold corporate catalogue spam with no human connection.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Empirical Creative Variable Impact Matrix */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              Empirical Creative Variable Impact (The "Vibes vs Reality" Matrix)
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Statistical performance delta calculated across all 200 ads relative to the cohort baseline (1.74x ROAS, $36.20 CPA).
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-medium">
            <button
              onClick={() => setImpactFilter('all')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                impactFilter === 'all'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Variables ({CREATIVE_VARIABLE_IMPACTS.length})
            </button>
            <button
              onClick={() => setImpactFilter('high')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                impactFilter === 'high'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Winning Drivers
            </button>
            <button
              onClick={() => setImpactFilter('traps')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                impactFilter === 'traps'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Vibe Traps
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-xs font-semibold text-slate-500">
                <th className="py-3 px-4">Creative Feature</th>
                <th className="py-3 px-3">Category</th>
                <th className="py-3 px-3 text-right">Ads</th>
                <th className="py-3 px-3 text-right">Avg ROAS</th>
                <th className="py-3 px-3 text-right">ROAS Lift</th>
                <th className="py-3 px-3 text-right">Avg CPA</th>
                <th className="py-3 px-3 text-right">3s Hook</th>
                <th className="py-3 px-4">Commercial Mechanism</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {filteredImpacts.map((item, idx) => {
                const isWinner = item.status === 'High Performer';
                return (
                  <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-semibold text-slate-900">
                      <div className="flex items-center gap-2">
                        {isWinner ? (
                          <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                        ) : (
                          <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />
                        )}
                        <span>{item.variableName}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-3 text-slate-500">
                      {item.category}
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-600">
                      {item.adCount}
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono tabular-nums font-bold text-slate-900">
                      {item.avgRoas.toFixed(2)}x
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono tabular-nums font-bold">
                      <span
                        className={
                          item.roasDeltaPercent > 0
                            ? 'text-emerald-700'
                            : 'text-rose-700'
                        }
                      >
                        {item.roasDeltaPercent > 0 ? '+' : ''}
                        {item.roasDeltaPercent.toFixed(1)}%
                      </span>
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-800">
                      ${item.avgCpa.toFixed(2)}
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-800">
                      {item.avgHookRate.toFixed(1)}%
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 max-w-xs">
                      {item.explanation}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Cohort Directives: Why the next brief must change */}
      <div className="bg-slate-900 text-white rounded-xl p-6 sm:p-8">
        <div className="max-w-3xl space-y-4">
          <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider">
            Leadership Mandate for Next Quarter
          </div>
          <h3 className="text-xl sm:text-2xl font-bold tracking-tight">
            Stop producing 200 random ads. Ship 24 systematic hypothesis tests.
          </h3>
          <p className="text-sm text-slate-300 leading-relaxed">
            The previous process burned $198,400 testing slight variations of sterile studio packshots because the team lacked an empirical taxonomy. For the upcoming quarter, we replace vague art direction ("make it feel vibrant and elevated") with strict creative parameters:
          </p>

          <ul className="space-y-2 text-xs sm:text-sm text-slate-300 pt-2">
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>Ban Seamless White Studio:</strong> Zero budget allocated to floating bottle renders. All imagery must be anchored in lived-in environments (kitchens, desks, bathrooms).
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>Mandate Human Element:</strong> Every hero creative must feature human hands holding the product to convey tangible scale and tactile interaction.
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>Headline Directness:</strong> Replace poetic brand taglines ("Embrace Your Vitality") with 1-line customer objection or benefit hooks ("Afternoon brain fog stopped in 15 minutes").
              </span>
            </li>
          </ul>

          <div className="pt-4 flex flex-wrap gap-3">
            <button
              onClick={() => onNavigateTab('brief')}
              className="px-5 py-2.5 bg-white text-slate-900 rounded-lg text-xs font-bold hover:bg-slate-100 transition-colors shadow-sm"
            >
              Open Next-Quarter Brief Builder
            </button>
            <button
              onClick={() => onNavigateTab('explorer')}
              className="px-5 py-2.5 bg-slate-800 text-slate-200 rounded-lg text-xs font-semibold hover:bg-slate-700 transition-colors"
            >
              Inspect All 200 Ads in Cohort
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
