import React, { useState } from 'react';
import { AdCreative } from '../types/ad';
import { FEATURED_IMAGES } from '../data/cohortData';
import { X, CheckCircle2, AlertOctagon, ArrowUpRight, BarChart2, ShieldAlert, Sparkles, Layers } from 'lucide-react';

interface AdDetailModalProps {
  ad: AdCreative | null;
  onClose: () => void;
  onCompareWithOpposite: (adId: string) => void;
}

export const AdDetailModal: React.FC<AdDetailModalProps> = ({ ad, onClose, onCompareWithOpposite }) => {
  const [activeHotspot, setActiveHotspot] = useState<'hook' | 'product' | 'text' | 'environment'>('hook');

  if (!ad) return null;

  const isWinner = ad.performanceTier === 'Breakout Winner';
  const isBleeder = ad.performanceTier === 'Money Bleeder';
  const isCore = ad.performanceTier === 'Core Performer';

  const getAdImage = () => {
    if (ad.imageUrl) return ad.imageUrl;
    if (ad.creativeVariables.angleArchetype === 'Authentic UGC') return FEATURED_IMAGES.breakoutUgc;
    if (ad.creativeVariables.angleArchetype === 'Sterile Studio Packshot') return FEATURED_IMAGES.failedStudio;
    if (ad.creativeVariables.angleArchetype === 'Founder Hands-On Demo') return FEATURED_IMAGES.founderDemo;
    if (ad.creativeVariables.angleArchetype === 'Split Problem vs Solution') return FEATURED_IMAGES.splitComparison;
    return FEATURED_IMAGES.breakoutUgc;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-4xl w-full max-h-[92vh] overflow-hidden flex flex-col shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/80">
          <div className="flex items-center gap-3">
            <span
              className={`text-xs font-bold px-2.5 py-1 rounded ${
                isWinner
                  ? 'bg-emerald-100 text-emerald-800'
                  : isCore
                  ? 'bg-indigo-100 text-indigo-800'
                  : isBleeder
                  ? 'bg-rose-100 text-rose-800'
                  : 'bg-slate-200 text-slate-800'
              }`}
            >
              {ad.performanceTier}
            </span>
            <div className="text-xs font-mono text-slate-500">
              {ad.id} · {ad.channel} · {ad.dateShipped}
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Left Column: Image with interactive visual inspection */}
          <div className="space-y-4">
            <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-slate-900 border border-slate-200 shadow-inner group">
              <img
                src={getAdImage()}
                alt={ad.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />

              {/* Hotspot Markers */}
              <button
                onClick={() => setActiveHotspot('hook')}
                className={`absolute top-6 left-8 w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold border-2 transition-transform ${
                  activeHotspot === 'hook'
                    ? 'bg-indigo-600 text-white border-white scale-125 ring-2 ring-indigo-400'
                    : 'bg-white/90 text-slate-900 border-indigo-600 hover:scale-110'
                }`}
              >
                1
              </button>

              <button
                onClick={() => setActiveHotspot('product')}
                className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold border-2 transition-transform ${
                  activeHotspot === 'product'
                    ? 'bg-indigo-600 text-white border-white scale-125 ring-2 ring-indigo-400'
                    : 'bg-white/90 text-slate-900 border-indigo-600 hover:scale-110'
                }`}
              >
                2
              </button>

              <button
                onClick={() => setActiveHotspot('text')}
                className={`absolute bottom-12 left-8 w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold border-2 transition-transform ${
                  activeHotspot === 'text'
                    ? 'bg-indigo-600 text-white border-white scale-125 ring-2 ring-indigo-400'
                    : 'bg-white/90 text-slate-900 border-indigo-600 hover:scale-110'
                }`}
              >
                3
              </button>

              <button
                onClick={() => setActiveHotspot('environment')}
                className={`absolute top-8 right-8 w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold border-2 transition-transform ${
                  activeHotspot === 'environment'
                    ? 'bg-indigo-600 text-white border-white scale-125 ring-2 ring-indigo-400'
                    : 'bg-white/90 text-slate-900 border-indigo-600 hover:scale-110'
                }`}
              >
                4
              </button>
            </div>

            {/* Hotspot Explanation Box */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs">
              <div className="flex items-center gap-2 font-bold text-slate-900 mb-1">
                <span className="w-4 h-4 rounded-full bg-indigo-600 text-white flex items-center justify-center text-[10px]">
                  {activeHotspot === 'hook' ? '1' : activeHotspot === 'product' ? '2' : activeHotspot === 'text' ? '3' : '4'}
                </span>
                <span>
                  {activeHotspot === 'hook' && 'Point 1: 3-Second Hook & Eye Landing'}
                  {activeHotspot === 'product' && 'Point 2: Product Prominence & Physical Scale'}
                  {activeHotspot === 'text' && 'Point 3: Text Contrast & Value Proposition'}
                  {activeHotspot === 'environment' && 'Point 4: Environmental Setting & Trust Signals'}
                </span>
              </div>
              <p className="text-slate-600 leading-relaxed">
                {activeHotspot === 'hook' &&
                  (isWinner
                    ? 'Direct eye path hits natural warmth and context immediately; does not look like corporate promotion, achieving 44.8% 3s thumb-stop rate.'
                    : 'Sterile unanchored composition fails to trigger social curiosity; high scroll-velocity dropoff (14.2% thumb-stop rate).')}
                {activeHotspot === 'product' &&
                  `Product occupies ${ad.creativeVariables.productProminence} of frame. ${
                    isWinner
                      ? 'Human hands provide instant physical scale; the consumer immediately registers the exact bottle dimensions.'
                      : 'Product appears isolated with no scale indicators, increasing cognitive barrier to purchase.'
                  }`}
                {activeHotspot === 'text' &&
                  `Text overlay type: ${ad.creativeVariables.textOverlay}. ${
                    isWinner
                      ? 'High-contrast 1-line benefit directly solves an immediate physical problem before the user clicks.'
                      : 'Vague brand tagline or unreadable font failed to communicate utility on a 6-inch smartphone glass.'
                  }`}
                {activeHotspot === 'environment' &&
                  `Setting: ${ad.creativeVariables.environment} with ${ad.creativeVariables.colorTone} lighting. ${
                    isWinner
                      ? 'Natural morning environment connects with daily routine; low resistance to purchase.'
                      : 'Sterile seamless background created an impersonal catalogue aesthetic.'
                  }`}
              </p>
            </div>
          </div>

          {/* Right Column: Creative Genome & Commercial Metrics */}
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-slate-900">{ad.name}</h2>
              <p className="text-xs text-slate-500 mt-1">
                Commercial performance & forensic variable breakdown
              </p>
            </div>

            {/* KPI Metric Strip */}
            <div className="grid grid-cols-3 gap-2 p-3 bg-slate-50 border border-slate-200 rounded-xl text-center text-xs">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-semibold">ROAS</span>
                <div
                  className={`font-mono text-base font-extrabold tabular-nums mt-0.5 ${
                    isWinner ? 'text-emerald-700' : isBleeder ? 'text-rose-700' : 'text-slate-900'
                  }`}
                >
                  {ad.roas.toFixed(2)}x
                </div>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-semibold">CPA</span>
                <div className="font-mono text-base font-extrabold text-slate-900 tabular-nums mt-0.5">
                  ${ad.cpa.toFixed(2)}
                </div>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Hook (3s)</span>
                <div className="font-mono text-base font-extrabold text-slate-900 tabular-nums mt-0.5">
                  {ad.hookRate.toFixed(1)}%
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Spend</span>
                <div className="font-mono text-xs font-bold text-slate-800 tabular-nums mt-0.5">
                  ${ad.spend.toLocaleString()}
                </div>
              </div>
              <div className="pt-2 border-t border-slate-200">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Revenue</span>
                <div className="font-mono text-xs font-bold text-slate-800 tabular-nums mt-0.5">
                  ${ad.revenue.toLocaleString()}
                </div>
              </div>
              <div className="pt-2 border-t border-slate-200">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">CTR</span>
                <div className="font-mono text-xs font-bold text-slate-800 tabular-nums mt-0.5">
                  {ad.ctr.toFixed(1)}%
                </div>
              </div>
            </div>

            {/* Creative Variable Genome */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Creative Variable Genome
              </h4>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-[10px] text-slate-400 block font-medium">Angle Archetype</span>
                  <span className="font-semibold text-slate-800">{ad.creativeVariables.angleArchetype}</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-[10px] text-slate-400 block font-medium">Environment</span>
                  <span className="font-semibold text-slate-800">{ad.creativeVariables.environment}</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-[10px] text-slate-400 block font-medium">Human Element</span>
                  <span className="font-semibold text-slate-800">{ad.creativeVariables.humanPresence}</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-[10px] text-slate-400 block font-medium">Text Overlay</span>
                  <span className="font-semibold text-slate-800">{ad.creativeVariables.textOverlay}</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-[10px] text-slate-400 block font-medium">Color Tone</span>
                  <span className="font-semibold text-slate-800">{ad.creativeVariables.colorTone}</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-[10px] text-slate-400 block font-medium">Vibe Risk Profile</span>
                  <span
                    className={`font-semibold ${
                      ad.creativeVariables.vibeScore === 'Empirically Engineered'
                        ? 'text-emerald-700'
                        : ad.creativeVariables.vibeScore === 'High Vibes / Zero Data'
                        ? 'text-rose-700'
                        : 'text-amber-700'
                    }`}
                  >
                    {ad.creativeVariables.vibeScore}
                  </span>
                </div>
              </div>
            </div>

            {/* Forensic Autopsy / Diagnosis */}
            <div
              className={`p-4 rounded-xl border text-xs leading-relaxed space-y-1.5 ${
                isWinner
                  ? 'bg-emerald-50/50 border-emerald-200 text-emerald-950'
                  : 'bg-rose-50/50 border-rose-200 text-rose-950'
              }`}
            >
              <div className="font-bold flex items-center gap-1.5">
                {isWinner ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Forensic Success Drivers</span>
                  </>
                ) : (
                  <>
                    <AlertOctagon className="w-4 h-4 text-rose-600" />
                    <span>The "Vibe Trap" Autopsy</span>
                  </>
                )}
              </div>
              <p>
                {ad.whyItPerformed || ad.whyItFailed}
              </p>
            </div>

            {/* Footer Actions */}
            <div className="pt-2 flex items-center justify-between gap-3">
              <button
                onClick={() => {
                  onClose();
                  onCompareWithOpposite(ad.id);
                }}
                className="w-full py-2.5 px-4 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition-colors flex items-center justify-center gap-2 shadow-sm"
              >
                <span>Compare Head-to-Head</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
