import React, { useState } from 'react';
import { FEATURED_IMAGES } from '../data/cohortData';
import { Sparkles, Upload, AlertTriangle, CheckCircle2, ArrowRight, ShieldCheck, RefreshCw, Zap } from 'lucide-react';

interface AnalysisResult {
  detectedVariables?: {
    angleArchetype?: string;
    productProminence?: string;
    humanPresence?: string;
    environment?: string;
    textOverlayQuality?: string;
    colorTone?: string;
  };
  empiricalVerdict?: {
    predictedTier?: string;
    predictedRoasRange?: string;
    predictedCpaRange?: string;
    vibeRiskLevel?: string;
    summaryVerdict?: string;
  };
  vibeTrapsDetected?: string[];
  empiricalStrengths?: string[];
  actionableFixes?: Array<{
    element: string;
    currentObservation: string;
    recommendedAdjustment: string;
    expectedUplift: string;
  }>;
  nextQuarterBriefDirective?: string;
}

export const CreativeEvaluator: React.FC = () => {
  const [selectedPreset, setSelectedPreset] = useState<'sampleStudio' | 'sampleUgc' | 'sampleSplit' | 'custom'>('sampleUgc');
  const [customImageBase64, setCustomImageBase64] = useState<string | null>(null);
  const [adTitle, setAdTitle] = useState('Morning Ritual Adaptogen Drops #01');
  const [targetGoal, setTargetGoal] = useState('Scale DTC Cold Traffic at <$20 CPA');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const getCurrentImage = () => {
    if (selectedPreset === 'custom' && customImageBase64) return customImageBase64;
    if (selectedPreset === 'sampleStudio') return FEATURED_IMAGES.failedStudio;
    if (selectedPreset === 'sampleSplit') return FEATURED_IMAGES.splitComparison;
    return FEATURED_IMAGES.breakoutUgc;
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      setCustomImageBase64(reader.result as string);
      setSelectedPreset('custom');
      setAdTitle(file.name.replace(/\.[^/.]+$/, ''));
    };
    reader.readAsDataURL(file);
  };

  const runAnalysis = async () => {
    setIsAnalyzing(true);
    setErrorMsg(null);
    setAnalysisResult(null);

    try {
      const imageUri = getCurrentImage();

      // Convert image path to base64 if it's one of the bundled assets
      let base64ToSend = imageUri;
      if (!imageUri.startsWith('data:')) {
        // Fetch the local asset and convert to base64
        const res = await fetch(imageUri);
        const blob = await res.blob();
        const reader = new FileReader();
        base64ToSend = await new Promise((resolve) => {
          reader.onloadend = () => resolve(reader.result as string);
          reader.readAsDataURL(blob);
        });
      }

      const response = await fetch('/api/analyze-creative', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: base64ToSend,
          mimeType: 'image/jpeg',
          adTitle,
          targetGoal,
          cohortContext: 'Benchmark against 200-ad Q3/Q4 cohort ($624k spend, 1.74x baseline ROAS, 12 winners, 90 bleeders).',
        }),
      });

      const resData = await response.json();
      if (!response.ok || !resData.success) {
        throw new Error(resData.error || 'Failed to complete analysis.');
      }

      setAnalysisResult(resData.data);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Error communicating with analysis engine.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-semibold text-indigo-700 uppercase tracking-wider">
              <Zap className="w-3.5 h-3.5" />
              <span>Gemini Vision Pre-Flight Audit</span>
            </div>
            <h1 className="text-xl font-extrabold text-slate-900 tracking-tight mt-1">
              Test New Ads Against Empirical Winning Archetypes Before Burning Spend
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Upload unreleased mockups or select sample creatives. The AI evaluates visual variables against the 200-ad cohort performance model to flag vibe traps and predict ROAS tier.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <label className="cursor-pointer px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-xs">
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Custom Ad Image</span>
              <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
            </label>
          </div>
        </div>

        {/* Preset Selectors */}
        <div className="mt-6 pt-6 border-t border-slate-100 flex flex-wrap items-center gap-2 text-xs">
          <span className="font-medium text-slate-600 mr-1">Test Presets:</span>
          <button
            onClick={() => {
              setSelectedPreset('sampleUgc');
              setAdTitle('Morning Countertop Adaptogen Routine');
            }}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              selectedPreset === 'sampleUgc'
                ? 'bg-slate-900 text-white font-semibold'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Lived-in Countertop UGC (High-Win Potential)
          </button>
          <button
            onClick={() => {
              setSelectedPreset('sampleStudio');
              setAdTitle('Minimalist Studio Serum Packshot');
            }}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              selectedPreset === 'sampleStudio'
                ? 'bg-slate-900 text-white font-semibold'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Sterile Studio Packshot (Vibe Trap Test)
          </button>
          <button
            onClick={() => {
              setSelectedPreset('sampleSplit');
              setAdTitle('Chaos vs Clarity Medicine Cabinet Split');
            }}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              selectedPreset === 'sampleSplit'
                ? 'bg-slate-900 text-white font-semibold'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Problem vs Solution Split Juxtaposition
          </button>
          {customImageBase64 && (
            <button
              onClick={() => setSelectedPreset('custom')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                selectedPreset === 'custom'
                  ? 'bg-indigo-600 text-white font-semibold'
                  : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100'
              }`}
            >
              Uploaded Custom Creative
            </button>
          )}
        </div>
      </div>

      {/* Main Workbench */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Image preview and test parameters */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Creative Under Audit
            </h3>

            <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-slate-900 border border-slate-200">
              <img
                src={getCurrentImage()}
                alt="Ad under audit"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="space-y-3 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Creative Label
                </label>
                <input
                  type="text"
                  value={adTitle}
                  onChange={(e) => setAdTitle(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Campaign Target Objective
                </label>
                <input
                  type="text"
                  value={targetGoal}
                  onChange={(e) => setTargetGoal(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
              </div>

              <button
                onClick={runAnalysis}
                disabled={isAnalyzing}
                className="w-full py-2.5 px-4 bg-slate-900 text-white rounded-lg text-xs font-bold hover:bg-slate-800 disabled:opacity-50 transition-all flex items-center justify-center gap-2 shadow-sm"
              >
                {isAnalyzing ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Deconstructing Visual Variables...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Run Pre-Flight Empirical Audit</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Audit Results */}
        <div className="lg:col-span-7 space-y-4">
          {errorMsg && (
            <div className="p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {!analysisResult && !isAnalyzing && (
            <div className="bg-white border border-dashed border-slate-300 rounded-xl p-12 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-500 mx-auto flex items-center justify-center">
                <Sparkles className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-slate-800">No Active Audit</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Click <strong>Run Pre-Flight Empirical Audit</strong> to benchmark this creative against the 200-ad cohort performance taxonomy.
              </p>
            </div>
          )}

          {isAnalyzing && (
            <div className="bg-white border border-slate-200 rounded-xl p-12 text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-indigo-50 text-indigo-600 mx-auto flex items-center justify-center animate-spin">
                <RefreshCw className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-slate-900">
                  Deconstructing Creative Anatomy
                </h4>
                <p className="text-xs text-slate-500">
                  Detecting hook archetype, product prominence ratio, cognitive load, and comparing with $624k cohort winners...
                </p>
              </div>
            </div>
          )}

          {analysisResult && (
            <div className="space-y-6">
              {/* Verdict Summary Box */}
              <div
                className={`p-6 rounded-xl border ${
                  analysisResult.empiricalVerdict?.vibeRiskLevel === 'Empirically Grounded'
                    ? 'bg-emerald-50/50 border-emerald-200'
                    : analysisResult.empiricalVerdict?.vibeRiskLevel === 'Extreme Vibe Trap'
                    ? 'bg-rose-50/50 border-rose-200'
                    : 'bg-amber-50/50 border-amber-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
                    Predicted Performance Tier
                  </span>
                  <span
                    className={`text-xs font-bold px-2.5 py-0.5 rounded ${
                      analysisResult.empiricalVerdict?.vibeRiskLevel === 'Empirically Grounded'
                        ? 'bg-emerald-200 text-emerald-900'
                        : analysisResult.empiricalVerdict?.vibeRiskLevel === 'Extreme Vibe Trap'
                        ? 'bg-rose-200 text-rose-900'
                        : 'bg-amber-200 text-amber-900'
                    }`}
                  >
                    {analysisResult.empiricalVerdict?.predictedTier || 'Core Performer'}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 my-4 text-xs">
                  <div className="bg-white/80 p-2.5 rounded-lg border border-slate-200/60">
                    <span className="text-[10px] text-slate-500 block">Expected ROAS</span>
                    <span className="font-bold font-mono text-slate-900 text-sm">
                      {analysisResult.empiricalVerdict?.predictedRoasRange || '2.4x - 3.1x'}
                    </span>
                  </div>
                  <div className="bg-white/80 p-2.5 rounded-lg border border-slate-200/60">
                    <span className="text-[10px] text-slate-500 block">Expected CPA</span>
                    <span className="font-bold font-mono text-slate-900 text-sm">
                      {analysisResult.empiricalVerdict?.predictedCpaRange || '$18 - $24'}
                    </span>
                  </div>
                  <div className="bg-white/80 p-2.5 rounded-lg border border-slate-200/60 col-span-2 sm:col-span-1">
                    <span className="text-[10px] text-slate-500 block">Vibe Risk Profile</span>
                    <span className="font-bold text-slate-900">
                      {analysisResult.empiricalVerdict?.vibeRiskLevel || 'Empirically Grounded'}
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-700 leading-relaxed font-medium">
                  {analysisResult.empiricalVerdict?.summaryVerdict}
                </p>
              </div>

              {/* Detected Variable Breakdown */}
              {analysisResult.detectedVariables && (
                <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Computer Vision Feature Extraction
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
                    <div className="p-2 bg-slate-50 rounded border border-slate-100">
                      <span className="text-[10px] text-slate-400 block">Archetype</span>
                      <span className="font-semibold text-slate-800">
                        {analysisResult.detectedVariables.angleArchetype}
                      </span>
                    </div>
                    <div className="p-2 bg-slate-50 rounded border border-slate-100">
                      <span className="text-[10px] text-slate-400 block">Product Prominence</span>
                      <span className="font-semibold text-slate-800">
                        {analysisResult.detectedVariables.productProminence}
                      </span>
                    </div>
                    <div className="p-2 bg-slate-50 rounded border border-slate-100">
                      <span className="text-[10px] text-slate-400 block">Human Presence</span>
                      <span className="font-semibold text-slate-800">
                        {analysisResult.detectedVariables.humanPresence}
                      </span>
                    </div>
                    <div className="p-2 bg-slate-50 rounded border border-slate-100">
                      <span className="text-[10px] text-slate-400 block">Environment</span>
                      <span className="font-semibold text-slate-800">
                        {analysisResult.detectedVariables.environment}
                      </span>
                    </div>
                    <div className="p-2 bg-slate-50 rounded border border-slate-100">
                      <span className="text-[10px] text-slate-400 block">Text Quality</span>
                      <span className="font-semibold text-slate-800">
                        {analysisResult.detectedVariables.textOverlayQuality}
                      </span>
                    </div>
                    <div className="p-2 bg-slate-50 rounded border border-slate-100">
                      <span className="text-[10px] text-slate-400 block">Color Tone</span>
                      <span className="font-semibold text-slate-800">
                        {analysisResult.detectedVariables.colorTone}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Vibe Traps Detected */}
              {analysisResult.vibeTrapsDetected && analysisResult.vibeTrapsDetected.length > 0 && (
                <div className="bg-rose-50/50 border border-rose-200 rounded-xl p-5 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-rose-900 uppercase tracking-wider">
                    <AlertTriangle className="w-4 h-4 text-rose-600" />
                    <span>Identified "Vibe Traps" (Instinct vs Reality Pitfalls)</span>
                  </div>
                  <ul className="space-y-1.5 text-xs text-rose-950">
                    {analysisResult.vibeTrapsDetected.map((trap, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-rose-500 font-bold">✕</span>
                        <span>{trap}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Actionable Fixes Before Launch */}
              {analysisResult.actionableFixes && analysisResult.actionableFixes.length > 0 && (
                <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Recommended Adjustments Before Launch
                  </h4>
                  <div className="space-y-3">
                    {analysisResult.actionableFixes.map((fix, idx) => (
                      <div key={idx} className="p-3 bg-slate-50 rounded-lg border border-slate-100 text-xs space-y-1">
                        <div className="flex items-center justify-between font-bold text-slate-900">
                          <span>{fix.element}</span>
                          <span className="text-emerald-700 font-mono text-[11px] font-semibold bg-emerald-50 px-2 py-0.5 rounded">
                            {fix.expectedUplift}
                          </span>
                        </div>
                        <div className="text-slate-500">
                          <strong className="text-slate-700">Observation:</strong> {fix.currentObservation}
                        </div>
                        <div className="text-slate-800">
                          <strong className="text-indigo-700">Directive:</strong> {fix.recommendedAdjustment}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
