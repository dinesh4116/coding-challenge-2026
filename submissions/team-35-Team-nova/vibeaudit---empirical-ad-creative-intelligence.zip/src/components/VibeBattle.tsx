import React, { useState } from 'react';
import { COHORT_ADS, FEATURED_IMAGES } from '../data/cohortData';
import { AdCreative } from '../types/ad';
import { Swords, ArrowRight, CheckCircle2, XCircle, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';

interface VibeBattleProps {
  initialWinnerId?: string;
  initialLoserId?: string;
  onNavigateToBrief: () => void;
}

export const VibeBattle: React.FC<VibeBattleProps> = ({
  initialWinnerId = 'AD-014',
  initialLoserId = 'AD-082',
  onNavigateToBrief,
}) => {
  const [winnerId, setWinnerId] = useState(initialWinnerId);
  const [loserId, setLoserId] = useState(initialLoserId);

  const winnerAds = COHORT_ADS.filter((a) => a.performanceTier === 'Breakout Winner' || a.performanceTier === 'Core Performer');
  const loserAds = COHORT_ADS.filter((a) => a.performanceTier === 'Money Bleeder' || a.performanceTier === 'Breakeven');

  const winner = COHORT_ADS.find((a) => a.id === winnerId) || COHORT_ADS[0];
  const loser = COHORT_ADS.find((a) => a.id === loserId) || COHORT_ADS[1];

  const getAdImage = (ad: AdCreative) => {
    if (ad.imageUrl) return ad.imageUrl;
    if (ad.creativeVariables.angleArchetype === 'Authentic UGC') return FEATURED_IMAGES.breakoutUgc;
    if (ad.creativeVariables.angleArchetype === 'Sterile Studio Packshot') return FEATURED_IMAGES.failedStudio;
    if (ad.creativeVariables.angleArchetype === 'Founder Hands-On Demo') return FEATURED_IMAGES.founderDemo;
    if (ad.creativeVariables.angleArchetype === 'Split Problem vs Solution') return FEATURED_IMAGES.splitComparison;
    return FEATURED_IMAGES.breakoutUgc;
  };

  const roasMultiplier = (winner.roas / Math.max(loser.roas, 0.1)).toFixed(1);
  const cpaSavings = Math.max(loser.cpa - winner.cpa, 0).toFixed(2);
  const hookGain = (winner.hookRate - loser.hookRate).toFixed(1);

  return (
    <div className="space-y-8 pb-16">
      {/* Header */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-indigo-700 uppercase tracking-wider">
              <Swords className="w-3.5 h-3.5" />
              <span>Head-to-Head Forensic Arena</span>
            </div>
            <h1 className="text-xl font-extrabold text-slate-900 tracking-tight mt-1">
              The Forensic Delta: What Separates a 3.8x Winner from a 0.6x Bleeder?
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Select any top-performing ad and any money-bleeding ad to isolate the exact variables that determined commercial success or failure.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onNavigateToBrief}
              className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition-colors shadow-sm"
            >
              Export Lessons to Q1 Brief
            </button>
          </div>
        </div>

        {/* Ad Selectors */}
        <div className="mt-6 pt-6 border-t border-slate-100 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-3 bg-emerald-50/50 border border-emerald-200 rounded-lg">
            <label className="block text-[11px] font-bold text-emerald-900 uppercase tracking-wider mb-1">
              Select High-Performing Winner
            </label>
            <select
              value={winnerId}
              onChange={(e) => setWinnerId(e.target.value)}
              className="w-full py-1.5 px-2.5 text-xs bg-white border border-emerald-300 rounded-md font-medium text-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-600"
            >
              {winnerAds.map((ad) => (
                <option key={ad.id} value={ad.id}>
                  {ad.id} · {ad.name} ({ad.roas.toFixed(2)}x ROAS, ${ad.cpa.toFixed(1)} CPA)
                </option>
              ))}
            </select>
          </div>

          <div className="p-3 bg-rose-50/50 border border-rose-200 rounded-lg">
            <label className="block text-[11px] font-bold text-rose-900 uppercase tracking-wider mb-1">
              Select Under-Performing Bleeder
            </label>
            <select
              value={loserId}
              onChange={(e) => setLoserId(e.target.value)}
              className="w-full py-1.5 px-2.5 text-xs bg-white border border-rose-300 rounded-md font-medium text-slate-800 focus:outline-none focus:ring-1 focus:ring-rose-600"
            >
              {loserAds.map((ad) => (
                <option key={ad.id} value={ad.id}>
                  {ad.id} · {ad.name} ({ad.roas.toFixed(2)}x ROAS, ${ad.cpa.toFixed(1)} CPA)
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Delta Performance Callout */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="text-xs font-medium text-slate-500">ROAS Multiplier</div>
          <div className="text-2xl font-extrabold text-emerald-700 font-mono tabular-nums mt-1">
            +{roasMultiplier}x Higher
          </div>
          <div className="text-xs text-slate-500 mt-1">
            {winner.roas.toFixed(2)}x vs {loser.roas.toFixed(2)}x
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="text-xs font-medium text-slate-500">Customer Acquisition Cost</div>
          <div className="text-2xl font-extrabold text-slate-900 font-mono tabular-nums mt-1">
            -${cpaSavings} Cheaper
          </div>
          <div className="text-xs text-slate-500 mt-1">
            ${winner.cpa.toFixed(2)} vs ${loser.cpa.toFixed(2)}
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="text-xs font-medium text-slate-500">3-Second Thumb-Stop Rate</div>
          <div className="text-2xl font-extrabold text-slate-900 font-mono tabular-nums mt-1">
            +{hookGain}% Lift
          </div>
          <div className="text-xs text-slate-500 mt-1">
            {winner.hookRate.toFixed(1)}% vs {loser.hookRate.toFixed(1)}%
          </div>
        </div>
      </div>

      {/* Side-by-Side Visual & Variable Comparison */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* WINNER COLUMN */}
        <div className="bg-white border-2 border-emerald-500 rounded-2xl overflow-hidden shadow-sm flex flex-col">
          <div className="bg-emerald-600 text-white px-5 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-200" />
              <span className="text-xs font-bold uppercase tracking-wider">The Empirical Winner</span>
            </div>
            <span className="text-xs font-mono font-bold">{winner.id}</span>
          </div>

          <div className="p-6 flex-1 space-y-6">
            {/* Visual Box */}
            <div className="aspect-square w-full rounded-xl overflow-hidden bg-slate-100 border border-slate-200">
              <img
                src={getAdImage(winner)}
                alt={winner.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            <div>
              <h3 className="text-base font-bold text-slate-900">{winner.name}</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Channel: {winner.channel} · Spend: ${winner.spend.toLocaleString()}
              </p>
            </div>

            {/* Metric Strip */}
            <div className="grid grid-cols-3 gap-2 bg-emerald-50/60 border border-emerald-100 p-3 rounded-lg text-center text-xs">
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-semibold">ROAS</span>
                <div className="font-mono font-extrabold text-emerald-700 text-base">{winner.roas.toFixed(2)}x</div>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-semibold">CPA</span>
                <div className="font-mono font-extrabold text-slate-900 text-base">${winner.cpa.toFixed(2)}</div>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-semibold">Hook</span>
                <div className="font-mono font-extrabold text-slate-900 text-base">{winner.hookRate.toFixed(1)}%</div>
              </div>
            </div>

            {/* Variable Breakdown */}
            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Angle Archetype:</span>
                <span className="font-semibold text-slate-900">{winner.creativeVariables.angleArchetype}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Environment:</span>
                <span className="font-semibold text-slate-900">{winner.creativeVariables.environment}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Human Presence:</span>
                <span className="font-semibold text-slate-900">{winner.creativeVariables.humanPresence}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Text Overlay:</span>
                <span className="font-semibold text-slate-900">{winner.creativeVariables.textOverlay}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Lighting Tone:</span>
                <span className="font-semibold text-slate-900">{winner.creativeVariables.colorTone}</span>
              </div>
            </div>

            {/* Psychological Driver */}
            <div className="p-4 bg-emerald-50 rounded-xl text-xs text-emerald-950 leading-relaxed border border-emerald-200">
              <strong className="block text-emerald-900 font-bold mb-1">Commercial Mechanism:</strong>
              {winner.whyItPerformed || 'Authentic organic setting bypassed mobile banner blindness; clear headline addressed a real friction point before the user scrolled away.'}
            </div>
          </div>
        </div>

        {/* LOSER COLUMN */}
        <div className="bg-white border-2 border-rose-400 rounded-2xl overflow-hidden shadow-sm flex flex-col">
          <div className="bg-rose-600 text-white px-5 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <XCircle className="w-4 h-4 text-rose-200" />
              <span className="text-xs font-bold uppercase tracking-wider">The "Vibe Trap" Bleeder</span>
            </div>
            <span className="text-xs font-mono font-bold">{loser.id}</span>
          </div>

          <div className="p-6 flex-1 space-y-6">
            {/* Visual Box */}
            <div className="aspect-square w-full rounded-xl overflow-hidden bg-slate-100 border border-slate-200">
              <img
                src={getAdImage(loser)}
                alt={loser.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            <div>
              <h3 className="text-base font-bold text-slate-900">{loser.name}</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Channel: {loser.channel} · Spend: ${loser.spend.toLocaleString()}
              </p>
            </div>

            {/* Metric Strip */}
            <div className="grid grid-cols-3 gap-2 bg-rose-50/60 border border-rose-100 p-3 rounded-lg text-center text-xs">
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-semibold">ROAS</span>
                <div className="font-mono font-extrabold text-rose-700 text-base">{loser.roas.toFixed(2)}x</div>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-semibold">CPA</span>
                <div className="font-mono font-extrabold text-slate-900 text-base">${loser.cpa.toFixed(2)}</div>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-semibold">Hook</span>
                <div className="font-mono font-extrabold text-slate-900 text-base">{loser.hookRate.toFixed(1)}%</div>
              </div>
            </div>

            {/* Variable Breakdown */}
            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Angle Archetype:</span>
                <span className="font-semibold text-slate-900">{loser.creativeVariables.angleArchetype}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Environment:</span>
                <span className="font-semibold text-slate-900">{loser.creativeVariables.environment}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Human Presence:</span>
                <span className="font-semibold text-slate-900">{loser.creativeVariables.humanPresence}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Text Overlay:</span>
                <span className="font-semibold text-slate-900">{loser.creativeVariables.textOverlay}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Lighting Tone:</span>
                <span className="font-semibold text-slate-900">{loser.creativeVariables.colorTone}</span>
              </div>
            </div>

            {/* Why the team fell into the vibe trap */}
            <div className="p-4 bg-rose-50 rounded-xl text-xs text-rose-950 leading-relaxed border border-rose-200">
              <strong className="block text-rose-900 font-bold mb-1">The Vibe Illusion:</strong>
              {loser.whyItFailed || 'Approved because it looked "clean, polished, and on-brand." In live auctions, users treated it as corporate banner noise with zero personal relevance.'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
