/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { TopNav } from './components/TopNav';
import { CohortOverview } from './components/CohortOverview';
import { CohortExplorer } from './components/CohortExplorer';
import { VibeBattle } from './components/VibeBattle';
import { CreativeEvaluator } from './components/CreativeEvaluator';
import { BriefBuilder } from './components/BriefBuilder';
import { AdDetailModal } from './components/AdDetailModal';
import { AdCreative } from './types/ad';
import { COHORT_ADS } from './data/cohortData';

export default function App() {
  const [activeTab, setActiveTab] = useState<'overview' | 'explorer' | 'battle' | 'evaluator' | 'brief'>('overview');
  const [selectedAd, setSelectedAd] = useState<AdCreative | null>(null);
  const [battleWinnerId, setBattleWinnerId] = useState<string>('AD-014');
  const [battleLoserId, setBattleLoserId] = useState<string>('AD-082');

  const handleSelectAdForDetail = (adId: string) => {
    const found = COHORT_ADS.find((a) => a.id === adId);
    if (found) {
      setSelectedAd(found);
    }
  };

  const handleCompareWithOpposite = (adId: string) => {
    const found = COHORT_ADS.find((a) => a.id === adId);
    if (!found) return;

    if (found.performanceTier === 'Breakout Winner' || found.performanceTier === 'Core Performer') {
      setBattleWinnerId(found.id);
      setBattleLoserId('AD-082');
    } else {
      setBattleLoserId(found.id);
      setBattleWinnerId('AD-014');
    }
    setActiveTab('battle');
  };

  const handleCompareSpecificAds = (winnerId: string, loserId: string) => {
    setBattleWinnerId(winnerId);
    setBattleLoserId(loserId);
    setActiveTab('battle');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* Top Bar Contract Compliant Navigation */}
      <TopNav activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        {activeTab === 'overview' && (
          <CohortOverview
            onNavigateTab={setActiveTab}
            onSelectAdForDetail={handleSelectAdForDetail}
          />
        )}

        {activeTab === 'explorer' && (
          <CohortExplorer
            onSelectAd={(ad) => setSelectedAd(ad)}
            onCompareAds={handleCompareSpecificAds}
          />
        )}

        {activeTab === 'battle' && (
          <VibeBattle
            initialWinnerId={battleWinnerId}
            initialLoserId={battleLoserId}
            onNavigateToBrief={() => setActiveTab('brief')}
          />
        )}

        {activeTab === 'evaluator' && <CreativeEvaluator />}

        {activeTab === 'brief' && <BriefBuilder />}
      </main>

      {/* Deconstruction Modal */}
      {selectedAd && (
        <AdDetailModal
          ad={selectedAd}
          onClose={() => setSelectedAd(null)}
          onCompareWithOpposite={handleCompareWithOpposite}
        />
      )}

      {/* Clean Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-800">VibeAudit</span>
            <span>·</span>
            <span>Empirical Ad Creative Intelligence Platform</span>
          </div>
          <div className="flex items-center gap-4">
            <span>200-Ad Cohort Database</span>
            <span>·</span>
            <span>Zero-Vibes Creative Strategy</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
