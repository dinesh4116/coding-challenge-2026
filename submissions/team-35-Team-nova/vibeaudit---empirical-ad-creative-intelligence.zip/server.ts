import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '25mb' }));

// Initialize Google GenAI client (User-Agent header required by guidelines)
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// API: Analyze an ad creative with Gemini Vision against the 200-ad cohort empirical model
app.post('/api/analyze-creative', async (req, res) => {
  try {
    const { imageBase64, mimeType = 'image/jpeg', adTitle, targetGoal, cohortContext } = req.body;

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ error: 'GEMINI_API_KEY is not configured on the server.' });
    }

    const systemPrompt = `You are the Principal Creative Strategist and Quantitative Marketing Scientist for a high-growth consumer brand.
You analyze image ads against an empirical dataset of 200 ads from the previous quarter ($624k spend cohort).
In that cohort, 80% of ads failed ("Vibe Traps") because they relied on aesthetic instincts (sterile studio packshots, floating bottles, low-contrast typography, vague luxury slogans).
The 6% breakout winners (ROAS > 3.0x, CPA < $20) shared concrete empirical patterns:
- Real-world environments (sunlit kitchen counters, lived-in medicine cabinets, messy desks)
- Human element (hands holding product or natural founder direct gaze)
- High product prominence with clear scale
- Bold, high-contrast 1-line benefit headline or authentic customer review quote
- Zero clinical, sterile, floating-product catalogue clichés

Your task is to analyze the provided image ad and give a rigorous, anti-vibe evaluation. Return a JSON response adhering to this structure:
{
  "detectedVariables": {
    "angleArchetype": string,
    "productProminence": string (e.g. "High (>40%)", "Medium (20-40%)", "Low (<20%)"),
    "humanPresence": string (e.g. "Hands holding product", "Direct gaze", "No human"),
    "environment": string (e.g. "Authentic lived-in space", "Seamless studio", "Outdoor"),
    "textOverlayQuality": string (e.g. "High-contrast benefit hook", "Low-contrast subtle", "None"),
    "colorTone": string (e.g. "Warm natural sunlight", "Clinical cold white", "Earthy warm")
  },
  "empiricalVerdict": {
    "predictedTier": "Breakout Winner (High ROAS)" | "Core Performer (Viable)" | "Money Bleeder (High Risk)",
    "predictedRoasRange": string (e.g. "2.8x - 3.4x"),
    "predictedCpaRange": string (e.g. "$16 - $21"),
    "vibeRiskLevel": "Extreme Vibe Trap" | "Moderate Aesthetic Drift" | "Empirically Grounded",
    "summaryVerdict": string
  },
  "vibeTrapsDetected": [
    string
  ],
  "empiricalStrengths": [
    string
  ],
  "actionableFixes": [
    {
      "element": string,
      "currentObservation": string,
      "recommendedAdjustment": string,
      "expectedUplift": string
    }
  ],
  "nextQuarterBriefDirective": string
}
Return ONLY valid JSON with no markdown wrapping.`;

    const promptText = `Analyze this ad creative for consumer brand campaign. Target goal: ${targetGoal || 'Scale DTC Acquisition at <$22 CPA'}.
Additional context: ${adTitle ? `Ad label: ${adTitle}. ` : ''}${cohortContext || 'Benchmark against 200-ad Q3/Q4 cohort.'}`;

    let contentsPayload: any;
    if (imageBase64) {
      // Clean base64 string if it contains data URI header
      const cleanBase64 = imageBase64.includes('base64,')
        ? imageBase64.split('base64,')[1]
        : imageBase64;

      contentsPayload = {
        parts: [
          {
            inlineData: {
              mimeType: mimeType || 'image/jpeg',
              data: cleanBase64,
            },
          },
          { text: promptText },
        ],
      };
    } else {
      contentsPayload = {
        parts: [{ text: `${promptText}\nNote: Analyze based on the creative description provided: ${adTitle}` }],
      };
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: contentsPayload,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text || '{}';
    let parsedData;
    try {
      parsedData = JSON.parse(responseText);
    } catch {
      parsedData = { rawText: responseText };
    }

    res.json({ success: true, data: parsedData });
  } catch (error: any) {
    console.error('Error analyzing creative:', error);
    res.status(500).json({ error: error.message || 'Failed to analyze creative.' });
  }
});

// API: Generate an empirical, anti-vibe creative brief for the next quarter
app.post('/api/generate-brief', async (req, res) => {
  try {
    const {
      targetQuarter = 'Q1 2027',
      campaignGoal = 'Scale DTC Acquisition',
      targetRoas = '2.8x',
      targetCpa = '$20.00',
      budget = '$180,000',
      totalVariants = 24,
      selectedWinningArchetypes = ['Authentic Countertop UGC', 'Founder Hands-On Demo', 'Split Problem vs Solution'],
      bannedVibeTropes = ['Seamless pure white studio packshots', 'Floating unanchored bottles', 'Vague philosophical slogans', 'Unreadable ultra-light serif overlays'],
      customDirectives = '',
    } = req.body;

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ error: 'GEMINI_API_KEY is not configured on the server.' });
    }

    const systemPrompt = `You are a world-class Quantitative Creative Strategist.
The team previously shipped 200 ads on instinct/vibes, resulting in 80% wasted spend and only 12 true winners.
Your mission is to write an exhaustive, razor-sharp, empirical Creative Brief for the next quarter (${targetQuarter}) that is completely insulated from "vibes".
Every recommendation must stem from the statistical performance evidence of the 200-ad cohort.

Respond with structured JSON in this schema:
{
  "briefMetadata": {
    "title": string,
    "quarter": string,
    "targetGoal": string,
    "budgetAllocation": string,
    "productionTarget": string,
    "targetMetrics": {
      "targetRoas": string,
      "targetCpa": string,
      "targetHookRate": string,
      "targetCtr": string
    }
  },
  "executiveSummary": {
    "theProblem": string,
    "theEmpiricalShift": string,
    "coreHypothesis": string
  },
  "creativeDirectives": [
    {
      "conceptId": string,
      "name": string,
      "primaryArchetype": string,
      "empiricalJustification": string,
      "visualFraming": string,
      "lightingAndSet": string,
      "humanElement": string,
      "copyHookFormulas": [string],
      "designerExecutionNotes": string,
      "predictedPerformanceRange": string
    }
  ],
  "testingMatrix": [
    {
      "testCell": string,
      "variableIsolated": string,
      "controlState": string,
      "variantState": string,
      "hypothesis": string,
      "successMetric": string
    }
  ],
  "bannedVibeRules": [
    {
      "bannedTrope": string,
      "whyItKillsRoas": string,
      "allowedAlternative": string
    }
  ],
  "productionChecklist": [string]
}
Return ONLY valid JSON.`;

    const userPrompt = `Generate the ${targetQuarter} Empirical Creative Brief.
Parameters:
- Goal: ${campaignGoal}
- Budget: ${budget}
- Target ROAS: ${targetRoas}
- Target CPA: ${targetCpa}
- Planned Variants: ${totalVariants} (systematic testing instead of 200 random shots)
- Winning Archetypes to scale: ${selectedWinningArchetypes.join(', ')}
- Banned Vibe Tropes: ${bannedVibeTropes.join(', ')}
${customDirectives ? `- Additional Directives: ${customDirectives}` : ''}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: userPrompt,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text || '{}';
    let briefData;
    try {
      briefData = JSON.parse(responseText);
    } catch {
      briefData = { rawText: responseText };
    }

    res.json({ success: true, data: briefData });
  } catch (error: any) {
    console.error('Error generating brief:', error);
    res.status(500).json({ error: error.message || 'Failed to generate brief.' });
  }
});

// API: Multi-Ad Cohort Synthesis
app.post('/api/diagnose-cohort', async (req, res) => {
  try {
    const { cohortSummary } = req.body;
    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ error: 'GEMINI_API_KEY is not configured on the server.' });
    }

    const systemPrompt = `You are a Principal Creative Strategist analyzing a DTC brand's 200-ad quarterly performance database.
Synthesize the statistical disconnect between design team intuition and commercial reality.
Provide 4 punchy, non-obvious statistical discoveries, 3 strategic directives for leadership, and an executive autopsy on why the studio catalog aesthetic burned capital.
Return JSON:
{
  "cohortHeadline": string,
  "topDiscoveries": [
    {
      "metric": string,
      "finding": string,
      "strategicImpact": string
    }
  ],
  "theVibeTrapAutopsy": {
    "whyStudioFlopped": string,
    "whyUgcSucceeded": string,
    "theCognitiveFrictionCost": string
  },
  "leadershipRecommendations": [string]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Cohort summary: ${JSON.stringify(cohortSummary || {})}`,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text || '{}';
    res.json({ success: true, data: JSON.parse(responseText) });
  } catch (error: any) {
    console.error('Error diagnosing cohort:', error);
    res.status(500).json({ error: error.message || 'Failed to diagnose cohort.' });
  }
});

// Vite dev middleware or static production serving
async function setupViteOrStatic() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

setupViteOrStatic().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
