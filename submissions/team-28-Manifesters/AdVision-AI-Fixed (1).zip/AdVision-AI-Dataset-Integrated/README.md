# AdVision AI — Srishti PS-02 Dataset Integrated

Ad creative intelligence dashboard for the **PS-02 Ad Creative Intelligence** challenge.

## Included challenge dataset
- 150 creative images: `backend/data/PS-02_ad_creative_intelligence/creatives/`
- `creative_performance.csv` with spend, impressions, clicks, purchases and revenue.
- The dataset README says the brand (Halcyon) is fictional and **all images and numbers are synthetic**. Results are benchmark/demo findings, not real campaign evidence.

## Features
- Automatic pixel-level visual features: brightness, saturation, contrast, colorfulness, edge density/text-coverage estimate and aspect ratio.
- Matches images to metrics using normalized creative IDs/filenames (`AD001` matches `ad_001.png`).
- Calculates CTR, conversion rate, CPA and ROAS where applicable.
- Spearman rank correlations with sample size, p-values, effect-size interpretation, and cautious recommendations.
- Upload your own images + CSV, or click **Analyse supplied Srishti dataset** to run the bundled dataset.
- JSON report export from the dashboard.

## Run on Windows (VS Code)

### 1. Backend
Open terminal in the `AdVision-AI` project root, then:

```powershell
cd backend
py -0p
```

Use Python 3.13 (recommended; avoid Python 3.15 alpha for package compatibility):

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip setuptools wheel
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload --port 8000
```

API docs: http://127.0.0.1:8000/docs

If Python 3.13 is not installed, install it from https://www.python.org/downloads/release/python-3139/ and rerun the commands above.

### 2. Frontend
Open a **second** VS Code terminal from the project root:

```powershell
cd frontend
npm.cmd install
npm.cmd run dev
```

Open the Local URL shown by Vite, normally http://localhost:5173.

## Dataset schema accepted
The supplied dataset uses `creative_id`, `filename`, `impressions`, `clicks`, `purchases`, `spend`, and `revenue`. The backend maps `creative_id` to image ID and `purchases` to conversions automatically. For uploads, the app also accepts `image_id`, `impressions`, `clicks`, `conversions`, with optional `spend` and `revenue`.

## Important interpretation notes
- CTR = clicks / impressions × 100.
- Conversion rate = purchases / clicks × 100.
- CPA = spend / purchases.
- ROAS = revenue / spend.
- Visual attributes are measured from image pixels; text coverage is an edge-density heuristic, not OCR.
- Correlation is not causation. This dataset is small and synthetic, so do not claim the findings are proven causal design rules.
