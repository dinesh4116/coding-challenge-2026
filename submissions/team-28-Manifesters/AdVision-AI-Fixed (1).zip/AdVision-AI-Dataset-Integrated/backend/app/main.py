
from __future__ import annotations

import io
import json
import math
import re
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import pandas as pd
from PIL import Image, ImageStat, UnidentifiedImageError
from scipy.stats import spearmanr
from fastapi import FastAPI, File, HTTPException, UploadFile
from starlette.datastructures import UploadFile as StarletteUploadFile
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title="AdVision AI API",
    description="Evidence-based advertisement creative feature and performance analysis.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

MAX_IMAGE_BYTES = 12 * 1024 * 1024
MAX_CSV_BYTES = 5 * 1024 * 1024
MAX_AD_SAMPLES = 150
ALLOWED_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}


def normalise_id(value: Any) -> str:
    text = Path(str(value or "").strip()).stem.strip().lower()
    # Dataset IDs (AD001) must match filenames such as ad_001.png.
    return re.sub(r"[^a-z0-9]", "", text)


def extract_visual_features(filename: str, raw: bytes) -> dict[str, Any]:
    try:
        image = Image.open(io.BytesIO(raw)).convert("RGB")
    except (UnidentifiedImageError, OSError):
        raise ValueError(f"{filename} is not a supported or valid image.")

    width, height = image.size
    if width < 1 or height < 1:
        raise ValueError(f"{filename} has invalid dimensions.")

    # Resize for consistent, fast image processing.
    image.thumbnail((700, 700))
    rgb = np.asarray(image, dtype=np.uint8)
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)

    brightness = float(np.mean(gray) / 255 * 100)
    saturation = float(np.mean(hsv[:, :, 1]) / 255 * 100)
    contrast = float(np.std(gray) / 255 * 100)

    # Hasler-Süsstrunk-style colorfulness approximation.
    r, g, b = [rgb[:, :, i].astype(np.float32) for i in range(3)]
    rg = np.abs(r - g)
    yb = np.abs(0.5 * (r + g) - b)
    colorfulness = float(np.sqrt(np.std(rg) ** 2 + np.std(yb) ** 2)
                         + 0.3 * np.sqrt(np.mean(rg) ** 2 + np.mean(yb) ** 2))
    colorfulness = min(100.0, colorfulness)

    # Heuristic, not OCR: estimates how edge-dense/text-like the image is.
    # This must be labelled approximate; it does not claim to read text.
    edges = cv2.Canny(gray, 80, 160)
    edge_density = float(np.mean(edges > 0) * 100)
    text_coverage_estimate = min(100.0, edge_density * 3.2)

    return {
        "image_id": Path(filename).stem,
        "filename": filename,
        "width": int(width),
        "height": int(height),
        "aspect_ratio": round(width / height, 3),
        "brightness": round(brightness, 2),
        "saturation": round(saturation, 2),
        "contrast": round(contrast, 2),
        "colorfulness": round(colorfulness, 2),
        "edge_density": round(edge_density, 2),
        "text_coverage_estimate": round(text_coverage_estimate, 2),
    }


def safe_float_series(series: pd.Series, name: str) -> pd.Series:
    result = pd.to_numeric(series, errors="coerce")
    if result.isna().any():
        raise ValueError(f"CSV column '{name}' contains missing or non-numeric values.")
    if (result < 0).any():
        raise ValueError(f"CSV column '{name}' cannot contain negative values.")
    return result


def correlate(features: list[dict], merged: pd.DataFrame, feature: str, metric: str) -> dict:
    pairs = merged[[feature, metric]].dropna()
    n = int(len(pairs))
    if n < 5 or pairs[feature].nunique() < 2 or pairs[metric].nunique() < 2:
        return {
            "feature": feature,
            "metric": metric,
            "rho": None,
            "p_value": None,
            "sample_size": n,
            "interpretation": "Insufficient variation or fewer than 5 matched ads; no reliable association reported.",
            "status": "insufficient_data",
        }
    rho, p_value = spearmanr(pairs[feature], pairs[metric])
    if not np.isfinite(rho) or not np.isfinite(p_value):
        return {
            "feature": feature, "metric": metric, "rho": None, "p_value": None,
            "sample_size": n, "interpretation": "Could not calculate a stable association.",
            "status": "insufficient_data",
        }
    abs_rho = abs(float(rho))
    strength = "weak" if abs_rho < 0.3 else ("moderate" if abs_rho < 0.6 else "strong")
    direction = "positive" if rho > 0 else ("negative" if rho < 0 else "no")
    if p_value < 0.05:
        status = "association_detected"
        interpretation = f"{strength.capitalize()} {direction} association observed (Spearman ρ={rho:.2f}, p={p_value:.3f}). This is correlation, not causation."
    else:
        status = "not_statistically_clear"
        interpretation = f"Observed {direction} association (Spearman ρ={rho:.2f}), but evidence is not statistically clear at p<0.05 (p={p_value:.3f})."
    return {
        "feature": feature,
        "metric": metric,
        "rho": round(float(rho), 3),
        "p_value": round(float(p_value), 4),
        "sample_size": n,
        "interpretation": interpretation,
        "status": status,
    }


@app.get("/")
def root():
    return {"name": "AdVision AI API", "status": "ok", "docs": "/docs"}


@app.get("/api/health")
def health():
    return {"status": "healthy"}


def visual_recommendations(item: dict[str, Any]) -> list[dict[str, str]]:
    tips: list[dict[str, str]] = []
    brightness = float(item["brightness"])
    contrast = float(item["contrast"])
    saturation = float(item["saturation"])
    text_estimate = float(item["text_coverage_estimate"])
    ratio = float(item["aspect_ratio"])

    if brightness < 30:
        tips.append({"title": "Check image brightness", "priority": "Medium",
                     "reason": f"Measured brightness is low ({brightness:.1f}/100).",
                     "action": "Preview a brighter version while preserving product colours and detail."})
    elif brightness > 85:
        tips.append({"title": "Check highlight detail", "priority": "Low",
                     "reason": f"Measured brightness is high ({brightness:.1f}/100).",
                     "action": "Check that light areas and small text remain visible on mobile screens."})
    if contrast < 12:
        tips.append({"title": "Improve tonal separation", "priority": "Medium",
                     "reason": f"Measured contrast is low ({contrast:.1f}/100).",
                     "action": "Test stronger separation between the subject, background and text."})
    if saturation < 15:
        tips.append({"title": "Review colour emphasis", "priority": "Low",
                     "reason": f"Average saturation is low ({saturation:.1f}/100).",
                     "action": "If it fits the brand, test a restrained accent colour to highlight the main offer."})
    elif saturation > 85:
        tips.append({"title": "Check colour intensity", "priority": "Low",
                     "reason": f"Average saturation is high ({saturation:.1f}/100).",
                     "action": "Check that intense colours do not compete with the product or call to action."})
    if text_estimate > 45:
        tips.append({"title": "Review visual density", "priority": "Medium",
                     "reason": f"Edge-based text/detail estimate is high ({text_estimate:.1f}/100); this is not OCR.",
                     "action": "Check the creative at phone size and simplify non-essential details if it feels crowded."})
    if ratio > 1.9 or ratio < 0.65:
        tips.append({"title": "Check placement crop", "priority": "Low",
                     "reason": f"The image aspect ratio is {ratio:.2f}.",
                     "action": "Preview platform-specific crops before using square, feed or vertical placements."})
    if not tips:
        tips.append({"title": "Run a placement preview", "priority": "Low",
                     "reason": "No basic pixel-level warning crossed the heuristic thresholds.",
                     "action": "Manually review readability, brand consistency, product prominence and call-to-action clarity."})
    return tips


def build_image_only_response(image_rows: list[dict[str, Any]], errors: list[dict[str, str]], uploaded_count: int) -> dict[str, Any]:
    results = []
    recommendations = []
    for row in image_rows:
        item = dict(row)
        tips = visual_recommendations(row)
        item.update({
            "matched": False, "impressions": None, "clicks": None, "conversions": None,
            "spend": None, "revenue": None, "ctr": None, "conversion_rate": None,
            "cpa": None, "roas": None, "campaign": "", "data_source": "image_only_visual_analysis",
            "metrics_verified": False, "visual_recommendations": tips,
        })
        results.append(item)
        recommendations.extend([{**tip, "filename": row["filename"]} for tip in tips])
    return {
        "analysis_mode": "image_only",
        "summary": {
            "uploaded_images": uploaded_count, "processed_images": len(image_rows), "matched_ads": 0,
            "unmatched_images": 0, "unmatched_csv_rows": 0, "total_impressions": None,
            "total_clicks": None, "total_conversions": None, "total_spend": None,
            "overall_ctr": None, "overall_conversion_rate": None, "overall_cpa": None,
        },
        "images": results, "correlations": [], "recommendations": recommendations,
        "unmatched_images": [], "unmatched_csv_ids": [], "errors": errors,
        "data_quality": {
            "max_samples_per_analysis": MAX_AD_SAMPLES, "csv_rows": 0, "matched_ads": 0,
            "verified_matched_ads": 0, "synthetic_or_demo_rows": 0, "unverified_or_unknown_rows": 0,
            "notice": "Image-only analysis measures visual properties and provides heuristic design suggestions. It does not measure actual campaign results.",
        },
        "methodology": [
            "Visual features are measured from image pixels.",
            "Edge-based text coverage is a heuristic, not OCR.",
            "CTR, conversions, CPA and ROAS require campaign metrics and are not estimated in image-only mode.",
        ],
    }


@app.post("/api/analyze")
async def analyze(
    images: list[UploadFile] | None = File(None),
    metrics_csv: UploadFile | None = File(None),
):
    # No uploads means use the bundled benchmark dataset.
    if not images and metrics_csv is None:
        dataset_root = Path(__file__).resolve().parent.parent / "data" / "PS-02_ad_creative_intelligence"
        csv_path = dataset_root / "creative_performance.csv"
        creatives_dir = dataset_root / "creatives"
        if not csv_path.exists() or not creatives_dir.exists():
            raise HTTPException(status_code=500, detail="Bundled dataset files are missing from backend/data.")
        images = [
            StarletteUploadFile(filename=p.name, file=p.open("rb"))
            for p in sorted(creatives_dir.iterdir())
            if p.is_file() and p.suffix.lower() in ALLOWED_EXTENSIONS
        ]
        metrics_csv = StarletteUploadFile(filename=csv_path.name, file=csv_path.open("rb"))

    if not images:
        raise HTTPException(status_code=400, detail="Upload at least one ad image, or use the built-in dataset.")
    if len(images) > MAX_AD_SAMPLES:
        raise HTTPException(status_code=400, detail=f"Maximum {MAX_AD_SAMPLES} images per analysis.")

    # Process images first so image-only mode never requires a CSV.
    feature_rows: list[dict[str, Any]] = []
    errors: list[dict[str, str]] = []
    seen_ids: set[str] = set()
    for upload in images:
        filename = Path(upload.filename or "uploaded_image").name
        if Path(filename).suffix.lower() not in ALLOWED_EXTENSIONS:
            errors.append({"filename": filename, "error": "Unsupported image type."})
            continue
        raw = await upload.read()
        if not raw:
            errors.append({"filename": filename, "error": "Empty file."})
            continue
        if len(raw) > MAX_IMAGE_BYTES:
            errors.append({"filename": filename, "error": "Image exceeds 12 MB limit."})
            continue
        try:
            row = extract_visual_features(filename, raw)
            key = normalise_id(row["image_id"])
            if key in seen_ids:
                errors.append({"filename": filename, "error": "Duplicate image filename stem."})
                continue
            seen_ids.add(key)
            feature_rows.append(row)
        except (ValueError, OSError) as exc:
            errors.append({"filename": filename, "error": str(exc)})

    if not feature_rows:
        raise HTTPException(status_code=400, detail="No valid images were processed. Check file types and image contents.")

    if metrics_csv is None:
        return build_image_only_response(feature_rows, errors, len(images))

    csv_bytes = await metrics_csv.read()
    if not csv_bytes:
        raise HTTPException(status_code=400, detail="The campaign CSV is empty.")
    if len(csv_bytes) > MAX_CSV_BYTES:
        raise HTTPException(status_code=413, detail="CSV file exceeds the 5 MB limit.")
    try:
        df = pd.read_csv(io.BytesIO(csv_bytes))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Could not read CSV: {exc}")
    if df.empty:
        raise HTTPException(status_code=400, detail="The campaign CSV contains no data rows.")

    df.columns = [str(c).strip().lower() for c in df.columns]
    is_ps02_dataset = "creative_id" in df.columns and "purchases" in df.columns
    for source, target in {"creative_id": "image_id", "purchases": "conversions"}.items():
        if source in df.columns and target not in df.columns:
            df = df.rename(columns={source: target})
    if "image_id" not in df.columns and "filename" in df.columns:
        df["image_id"] = df["filename"].map(lambda value: Path(str(value)).stem)

    required = {"image_id", "impressions", "clicks", "conversions"}
    missing = required - set(df.columns)
    if missing:
        raise HTTPException(
            status_code=400,
            detail="CSV missing required columns: " + ", ".join(sorted(missing))
            + ". Required: image_id, impressions, clicks, conversions (or creative_id, impressions, clicks, purchases).",
        )

    if "data_source" not in df.columns:
        df["data_source"] = "unknown_not_verified"
    else:
        df["data_source"] = df["data_source"].fillna("unknown_not_verified").astype(str).str.strip().replace("", "unknown_not_verified")
    if is_ps02_dataset:
        df["data_source"] = "Srishti PS-02 synthetic dataset"
    if "metrics_verified" not in df.columns:
        df["metrics_verified"] = False
    else:
        df["metrics_verified"] = df["metrics_verified"].astype(str).str.strip().str.lower().isin({"true", "1", "yes", "verified"})

    df["image_key"] = df["image_id"].map(normalise_id)
    if df["image_key"].eq("").any():
        raise HTTPException(status_code=400, detail="CSV contains an empty image_id.")
    if df["image_key"].duplicated().any():
        duplicates = df.loc[df["image_key"].duplicated(), "image_id"].astype(str).tolist()
        raise HTTPException(status_code=400, detail=f"Duplicate image_id values: {', '.join(duplicates[:5])}")

    try:
        for col in ("impressions", "clicks", "conversions"):
            df[col] = safe_float_series(df[col], col)
        for col in ("spend", "revenue"):
            if col not in df.columns:
                df[col] = 0.0
            else:
                df[col] = safe_float_series(df[col], col)
        if (df["clicks"] > df["impressions"]).any():
            raise ValueError("Clicks cannot exceed impressions.")
        if (df["conversions"] > df["clicks"]).any():
            raise ValueError("Conversions cannot exceed clicks.")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    features_df = pd.DataFrame(feature_rows)
    features_df["image_key"] = features_df["image_id"].map(normalise_id)
    merged = features_df.merge(df, on="image_key", how="left", suffixes=("", "_csv"), indicator=True)
    unmatched_images = merged.loc[merged["_merge"] == "left_only", "filename"].astype(str).tolist()
    unmatched_csv = df.loc[~df["image_key"].isin(features_df["image_key"]), "image_id"].astype(str).tolist()
    matched = merged.loc[merged["_merge"] == "both"].copy()

    # Ensure metric columns exist even when no image IDs matched.
    for col in ("impressions", "clicks", "conversions", "spend", "revenue"):
        if col not in matched.columns:
            matched[col] = pd.Series(index=matched.index, dtype=float)
    matched["ctr"] = np.where(matched["impressions"] > 0, matched["clicks"] / matched["impressions"] * 100, np.nan)
    matched["conversion_rate"] = np.where(matched["clicks"] > 0, matched["conversions"] / matched["clicks"] * 100, np.nan)
    matched["cpa"] = np.where(matched["conversions"] > 0, matched["spend"] / matched["conversions"], np.nan)
    matched["roas"] = np.where(matched["spend"] > 0, matched["revenue"] / matched["spend"], np.nan)

    image_results = []
    for row in feature_rows:
        data = matched.loc[matched["image_key"] == normalise_id(row["image_id"])]
        item = dict(row)
        item["visual_recommendations"] = visual_recommendations(row)
        if len(data):
            r = data.iloc[0]
            item.update({
                "matched": True, "impressions": int(r["impressions"]), "clicks": int(r["clicks"]),
                "conversions": int(r["conversions"]), "spend": round(float(r["spend"]), 2),
                "revenue": round(float(r["revenue"]), 2) if pd.notna(r["revenue"]) else None,
                "ctr": round(float(r["ctr"]), 3) if pd.notna(r["ctr"]) else None,
                "conversion_rate": round(float(r["conversion_rate"]), 3) if pd.notna(r["conversion_rate"]) else None,
                "cpa": round(float(r["cpa"]), 2) if pd.notna(r["cpa"]) else None,
                "roas": round(float(r["roas"]), 2) if pd.notna(r["roas"]) else None,
                "campaign": str(r.get("campaign", r.get("platform", ""))) if pd.notna(r.get("campaign", r.get("platform", ""))) else "",
                "launch_date": str(r.get("launch_date", "")) if pd.notna(r.get("launch_date", "")) else "",
                "data_source": str(r.get("data_source", "unknown_not_verified")),
                "metrics_verified": bool(r.get("metrics_verified", False)),
            })
        else:
            item.update({
                "matched": False, "impressions": None, "clicks": None, "conversions": None,
                "spend": None, "revenue": None, "ctr": None, "conversion_rate": None,
                "cpa": None, "roas": None, "campaign": "", "data_source": "no_matching_metrics",
                "metrics_verified": False,
            })
        image_results.append(item)

    analysis_df = matched.loc[matched["impressions"] > 0].copy()
    correlations = []
    for feature in ["brightness", "saturation", "contrast", "colorfulness", "text_coverage_estimate", "aspect_ratio"]:
        correlations.append(correlate(feature_rows, analysis_df, feature, "ctr"))
        correlations.append(correlate(feature_rows, analysis_df, feature, "conversion_rate"))

    matched_count = int(len(matched))
    recommendations: list[dict[str, str]] = []
    if matched_count < 5:
        recommendations.append({
            "title": "Collect more matched creatives", "priority": "High",
            "reason": f"Only {matched_count} uploaded image(s) matched CSV rows. Correlation findings need at least 5 matched ads.",
            "action": "Match CSV image_id values to uploaded image filenames and collect more campaign results.",
        })
    else:
        valid_corrs = [c for c in correlations if c["status"] == "association_detected" and c["metric"] == "ctr"]
        if valid_corrs:
            strongest = max(valid_corrs, key=lambda c: abs(c["rho"] or 0))
            recommendations.append({
                "title": f"Test the {strongest['feature'].replace('_', ' ')} pattern", "priority": "Medium",
                "reason": strongest["interpretation"],
                "action": "Run a controlled A/B test while keeping audience, offer and placement as consistent as possible.",
            })
        else:
            recommendations.append({
                "title": "Avoid unsupported design conclusions", "priority": "Medium",
                "reason": "No visual feature showed a statistically clear association with CTR in this dataset.",
                "action": "Gather more data and run controlled A/B tests before making large creative changes.",
            })
    if unmatched_images or unmatched_csv:
        recommendations.append({
            "title": "Fix image-to-metrics matching", "priority": "High",
            "reason": f"{len(unmatched_images)} image(s) and {len(unmatched_csv)} CSV row(s) did not match.",
            "action": "Make each CSV image_id match the uploaded image filename without its extension.",
        })

    total_impressions = float(matched["impressions"].sum()) if not matched.empty else 0.0
    total_clicks = float(matched["clicks"].sum()) if not matched.empty else 0.0
    total_conversions = float(matched["conversions"].sum()) if not matched.empty else 0.0
    total_spend = float(matched["spend"].sum()) if not matched.empty else 0.0
    return {
        "analysis_mode": "campaign_performance",
        "summary": {
            "uploaded_images": len(images), "processed_images": len(feature_rows), "matched_ads": matched_count,
            "unmatched_images": len(unmatched_images), "unmatched_csv_rows": len(unmatched_csv),
            "total_impressions": int(total_impressions), "total_clicks": int(total_clicks),
            "total_conversions": int(total_conversions), "total_spend": round(total_spend, 2),
            "overall_ctr": round(total_clicks / total_impressions * 100, 3) if total_impressions else None,
            "overall_conversion_rate": round(total_conversions / total_clicks * 100, 3) if total_clicks else None,
            "overall_cpa": round(total_spend / total_conversions, 2) if total_conversions else None,
        },
        "images": image_results, "correlations": correlations, "recommendations": recommendations,
        "unmatched_images": unmatched_images, "unmatched_csv_ids": unmatched_csv, "errors": errors,
        "data_quality": {
            "max_samples_per_analysis": MAX_AD_SAMPLES, "csv_rows": int(len(df)), "matched_ads": matched_count,
            "verified_matched_ads": int(matched["metrics_verified"].sum()) if not matched.empty else 0,
            "synthetic_or_demo_rows": int(df["data_source"].astype(str).str.contains("synthetic|demo|sample", case=False, regex=True).sum()),
            "unverified_or_unknown_rows": int((~matched["metrics_verified"]).sum()) if not matched.empty else 0,
            "notice": "Bundled Srishti PS-02 data is synthetic benchmark data, not real campaign evidence." if is_ps02_dataset else "Uploaded campaign metrics are not independently verified by this API.",
        },
        "methodology": [
            "Visual features are measured from image pixels; edge-based text coverage is a heuristic, not OCR.",
            "CTR = clicks / impressions × 100; conversion rate = conversions / clicks × 100; CPA = spend / conversions.",
            "ROAS is calculated from supplied revenue and spend when spend is positive.",
            "Spearman correlation indicates association, not causation. Small samples and campaign differences limit conclusions.",
            "Visual recommendations are heuristic review prompts and do not guarantee campaign performance.",
        ],
    }
