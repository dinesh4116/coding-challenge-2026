# Search Term Triage Engine (PS-01)

## Setup (VS Code terminal)
    python -m venv venv
    venv\Scripts\activate          (Windows)   |   source venv/bin/activate   (Mac/Linux)
    pip install -r requirements.txt

## Run option 1: command line (minimum submission)
    python triage.py your_file.csv
    python triage.py --sample
Outputs go to the `output` folder: triage_output.csv, keywords_to_add.csv, negatives_to_add.csv.

## Run option 2: review interface
    streamlit run app.py

## Method
- PROMOTE: enough clicks and conversions, and the 95% Wilson lower bound of the term's conversion rate beats the account rate.
- BLOCK: zero conversions, low chance (1-p)^n of that at the account rate, and meaningful spend. Also blocks terms whose Wilson upper bound is below the account rate.
- NEEDS REVIEW: too few clicks, or promising terms without enough proof.
- IGNORE: enough data, close to average.
Why "conversions > 0 = promote" is wrong: 2 clicks and 1 conversion is noise, not a winner.
Change thresholds at the top of triage.py or with command line flags.
