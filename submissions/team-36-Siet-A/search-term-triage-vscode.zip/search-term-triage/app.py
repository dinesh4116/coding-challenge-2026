"""Streamlit review interface.  Run:  streamlit run app.py"""
import pandas as pd
import streamlit as st

import triage as T

st.set_page_config(page_title="Search Term Triage", layout="wide")
st.title("Search term triage")
st.caption("Upload a search-terms report. Every term gets promote, block or ignore with a reason. "
           "Thin data is sent to you for review instead of guessed.")

with st.sidebar:
    st.header("Thresholds")
    min_clicks = st.number_input("Minimum clicks to make a call", 1, 1000, T.MIN_CLICKS)
    min_conv = st.number_input("Minimum conversions to promote", 1, 100, T.MIN_CONV)
    alpha = st.number_input("Block if chance of zero conv. is below", 0.001, 0.5, T.ALPHA, step=0.01, format="%.3f")
    cost_mult = st.number_input("Block after spending x account cost per conv.", 0.0, 20.0, T.COST_MULT, step=0.25)

file = st.file_uploader("Search terms CSV", type="csv")
if st.button("Use sample data"):
    st.session_state["df"] = pd.read_csv(T.make_sample())
if file is not None:
    st.session_state["df"] = pd.read_csv(file)

if "df" not in st.session_state:
    st.info("Upload a CSV or click 'Use sample data' to begin.")
    st.stop()

try:
    out, m, s = T.run_triage(st.session_state["df"], min_clicks, min_conv, alpha, cost_mult)
except ValueError as e:
    st.error(str(e)); st.stop()

c = st.columns(6)
c[0].metric("Terms", f"{s['terms']:,}")
c[1].metric("Promote", f"{s.get('promote', 0):,}")
c[2].metric("Block", f"{s.get('block', 0):,}")
c[3].metric("Ignore", f"{s.get('ignore', 0):,}")
c[4].metric("Need review", f"{s['needs_review']:,}")
c[5].metric("Account conv. rate", f"{s['account_conv_rate']:.2%}")

f1, f2, f3, f4 = st.columns([2, 1, 1, 1])
q = f1.text_input("Search terms")
dec = f2.selectbox("Decision", ["All", "promote", "block", "ignore"])
conf = f3.selectbox("Confidence", ["All", "high", "medium", "low"])
only_rev = f4.checkbox("Needs review only")

v = out
if q:
    v = v[v[m["query"]].astype(str).str.contains(q, case=False, na=False)]
if dec != "All":
    v = v[v["decision"] == dec]
if conf != "All":
    v = v[v["confidence"] == conf]
if only_rev:
    v = v[v["needs_review"]]

st.caption(f"{len(v):,} terms. Use the last column to override a decision.")
view = v.head(1000).copy()
view["your_call"] = ""
edited = st.data_editor(
    view, use_container_width=True, height=520,
    column_config={"your_call": st.column_config.SelectboxColumn("Your call", options=["", "promote", "block", "ignore"])},
    disabled=[col for col in view.columns if col != "your_call"],
)

final = out.copy()
ov = edited["your_call"].replace("", pd.NA).dropna()
final["final_decision"] = final["decision"]
final.loc[ov.index, "final_decision"] = ov
kw, neg = T.build_exports(final, m, decision_col="final_decision")

d1, d2, d3 = st.columns(3)
d1.download_button("Full results CSV", final.to_csv(index=False), "triage_output.csv", "text/csv")
d2.download_button("Keywords to add", kw.to_csv(index=False), "keywords_to_add.csv", "text/csv")
d3.download_button("Negatives to add", neg.to_csv(index=False), "negatives_to_add.csv", "text/csv")

with st.expander("Why 'conversions > 0' is not enough"):
    st.write("A term with 2 clicks and 1 conversion shows 50%, but two clicks cannot separate luck from a real winner. "
             "Promote needs the 95% Wilson lower bound of the conversion rate to beat the account average. "
             "Block needs zero conversions, a low chance of that at the account rate, and meaningful spend. "
             "Everything else with thin data goes to review.")
