"""PS-01 Search Term Triage Engine - core logic + command line.

Usage:
    python triage.py your_file.csv
    python triage.py --sample            (makes sample_search_terms.csv and runs on it)
"""
import argparse
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

# ---------------- Thresholds (change these) ----------------
MIN_CLICKS = 15      # below this many clicks we do not make a call (needs review)
MIN_CONV = 3         # minimum conversions before a term can be promoted
ALPHA = 0.05         # block only if chance of zero conversions at account rate is below this
COST_MULT = 1.0      # block only after spending this many times the account cost per conversion
Z = 1.96             # 95% confidence for the Wilson interval

ALIAS = {
    "query": ["searchterm", "query", "querytext", "searchquery", "term", "keyword"],
    "match_type": ["matchtype", "match", "searchtermmatchtype"],
    "campaign": ["campaign", "campaignname"],
    "ad_group": ["adgroup", "adgroupname"],
    "impressions": ["impressions", "impr"],
    "clicks": ["clicks", "click"],
    "cost": ["cost", "spend", "costusd"],
    "conversions": ["conversions", "conv", "allconv"],
    "conv_value": ["conversionvalue", "convvalue", "conversionsvalue", "revenue"],
}


def find_columns(df):
    """Match the file's column names to the standard names."""
    norm = {re.sub(r"[^a-z0-9]", "", str(c).lower()): c for c in df.columns}
    m = {}
    for key, names in ALIAS.items():
        for a in names:
            if a in norm:
                m[key] = norm[a]
                break
    missing = [k for k in ("query", "clicks", "cost", "conversions") if k not in m]
    if missing:
        raise ValueError(f"Missing column(s): {missing}. Columns found: {list(df.columns)}")
    return m


def to_num(s):
    return pd.to_numeric(s.astype(str).str.replace(r"[^0-9.\-]", "", regex=True), errors="coerce").fillna(0)


def wilson(c, n, z=Z):
    """95% Wilson confidence interval for a conversion rate (safe for small samples)."""
    c, n = np.asarray(c, float), np.asarray(n, float)
    nn = np.where(n == 0, 1, n)
    p = c / nn
    d = 1 + z * z / nn
    mid = p + z * z / (2 * nn)
    span = z * np.sqrt((p * (1 - p) + z * z / (4 * nn)) / nn)
    lo, hi = (mid - span) / d, (mid + span) / d
    return np.where(n == 0, 0, lo), np.where(n == 0, 1, hi)


def run_triage(df, min_clicks=MIN_CLICKS, min_conv=MIN_CONV, alpha=ALPHA, cost_mult=COST_MULT):
    """Return (result_df, column_map, summary). Adds decision, confidence, needs_review, reason."""
    m = find_columns(df)
    n = to_num(df[m["clicks"]]).to_numpy()
    c = to_num(df[m["conversions"]]).to_numpy()
    cost = to_num(df[m["cost"]]).to_numpy()
    p = c.sum() / n.sum() if n.sum() else 0.0
    cpa = cost.sum() / c.sum() if c.sum() else np.inf
    lo, hi = wilson(c, n)
    zero = (1 - p) ** n  # chance of getting 0 conversions in n clicks at the account rate
    pc = lambda x: f"{x * 100:.1f}%"

    dec, conf, rev, why = [], [], [], []
    for i in range(len(df)):
        ni, ci, co = n[i], c[i], cost[i]
        cvr = ci / ni if ni else 0
        d, cf, rv = "ignore", "medium", False
        if ni < min_clicks:
            rv, cf = True, "low"
            r = (f"{ci:g} conv from only {ni:g} clicks, likely noise. Needs human review."
                 if ci > 0 else f"Only {ni:g} clicks, too little data to judge.")
        elif ci >= min_conv and lo[i] > p:
            d = "promote"
            cf = "high" if (lo[i] > 2 * p and ci >= 5) else "medium"
            r = f"{ni:g} clicks, {ci:g} conv, rate {pc(cvr)}. Lower bound {pc(lo[i])} beats account {pc(p)}."
        elif ci == 0 and zero[i] < alpha and co >= cost_mult * cpa:
            d = "block"
            cf = "high" if zero[i] < alpha / 5 else "medium"
            r = f"{ni:g} clicks, {co:.0f} spent, 0 conv. Only {zero[i] * 100:.1f}% chance at account rate {pc(p)}."
        elif ci > 0 and hi[i] < p and co >= cost_mult * cpa:
            d, cf = "block", "medium"
            r = f"{ni:g} clicks, {ci:g} conv. Upper bound {pc(hi[i])} is below account {pc(p)}."
        elif ci > 0 and cvr > p:
            rv, cf = True, "low"
            r = f"{ci:g} conv from {ni:g} clicks looks promising, but lower bound {pc(lo[i])} does not beat account {pc(p)}."
        elif ci == 0:
            r = f"{ni:g} clicks, 0 conv, but not enough evidence to block (expected {ni * p:.1f} conv)."
        else:
            r = f"{ni:g} clicks, {ci:g} conv, rate {pc(cvr)}, close to account {pc(p)}."
        dec.append(d); conf.append(cf); rev.append(rv); why.append(r)

    out = df.copy()
    out["decision"], out["confidence"], out["needs_review"], out["reason"] = dec, conf, rev, why
    summary = {
        "terms": len(out),
        "account_conv_rate": p,
        "account_cost_per_conv": cpa,
        **out["decision"].value_counts().to_dict(),
        "needs_review": int(out["needs_review"].sum()),
        "thresholds": dict(min_clicks=min_clicks, min_conv=min_conv, alpha=alpha, cost_mult=cost_mult),
    }
    return out, m, summary


def build_exports(out, m, decision_col="decision"):
    """Upload-ready files: keywords to add and negatives to add."""
    def pick(key):
        return out[m[key]] if key in m else ""
    base = pd.DataFrame({"Campaign": pick("campaign"), "Ad group": pick("ad_group"), "Term": out[m["query"]]})
    kw = base[out[decision_col] == "promote"].rename(columns={"Term": "Keyword"}).assign(**{"Match type": "Exact"})
    neg = base[out[decision_col] == "block"].copy()
    # Campaign-level if the same term is blocked in more than one ad group of a campaign
    grp = neg.groupby(["Campaign", "Term"])["Ad group"].transform("nunique")
    neg["Level"] = np.where(grp > 1, "Campaign", "Ad group")
    neg.loc[neg["Level"] == "Campaign", "Ad group"] = ""
    neg = neg.drop_duplicates().rename(columns={"Term": "Negative keyword"}).assign(**{"Match type": "Exact"})
    return kw.reset_index(drop=True), neg.reset_index(drop=True)


def make_sample(path="sample_search_terms.csv", rows=4000, seed=7):
    rng = np.random.default_rng(seed)
    adj = ["buy", "cheap", "best", "discount", "online", "free", "how to", "diy", "used", "near me", "2026", "review"]
    prod = ["running shoes", "white sneakers", "trail shoes", "shoe cleaner", "school shoes", "leather boots", "sandals"]
    data = []
    for _ in range(rows):
        a, b, p = rng.choice(adj), rng.choice(adj), rng.choice(prod)
        q = f"{a} {p}" if rng.random() < 0.5 else f"{a} {p} {b}"
        junk = any(w in q for w in ("free", "how to", "diy", "review"))
        buyer = any(w in q for w in ("buy", "discount", "best", "online"))
        n = max(1, int(np.exp(rng.random() * rng.random() * 6)))
        conv = int(rng.binomial(n, 0.004 if junk else 0.09 if buyer else 0.035))
        cost = round(n * (0.4 + rng.random() * 1.6), 2)
        data.append({"Search term": q, "Match type": rng.choice(["Broad", "Phrase", "Exact"]),
                     "Campaign": rng.choice(["Shoes - Search", "Care - Search"]),
                     "Ad group": rng.choice(["Core", "Brand", "Generic"]),
                     "Impressions": n * int(8 + rng.random() * 30), "Clicks": n, "Cost": cost,
                     "Conversions": conv, "Conversion value": round(conv * (20 + rng.random() * 60), 2)})
    pd.DataFrame(data).to_csv(path, index=False)
    return path


def main():
    ap = argparse.ArgumentParser(description="Search Term Triage Engine")
    ap.add_argument("csv", nargs="?", help="search terms report (.csv)")
    ap.add_argument("--sample", action="store_true", help="generate and use sample data")
    ap.add_argument("--out", default="output", help="output folder")
    ap.add_argument("--min-clicks", type=int, default=MIN_CLICKS)
    ap.add_argument("--min-conv", type=int, default=MIN_CONV)
    ap.add_argument("--alpha", type=float, default=ALPHA)
    ap.add_argument("--cost-mult", type=float, default=COST_MULT)
    a = ap.parse_args()
    path = make_sample() if a.sample else a.csv
    if not path:
        ap.error("give a CSV path or use --sample")
    df = pd.read_csv(path)
    out, m, s = run_triage(df, a.min_clicks, a.min_conv, a.alpha, a.cost_mult)
    kw, neg = build_exports(out, m)
    folder = Path(a.out); folder.mkdir(exist_ok=True)
    out.to_csv(folder / "triage_output.csv", index=False)
    kw.to_csv(folder / "keywords_to_add.csv", index=False)
    neg.to_csv(folder / "negatives_to_add.csv", index=False)
    print(f"\nTerms: {s['terms']:,}   Account conv. rate: {s['account_conv_rate']:.2%}")
    for k in ("promote", "block", "ignore"):
        print(f"  {k:8s}: {s.get(k, 0):,}")
    print(f"  needs review: {s['needs_review']:,}")
    print(f"Thresholds: {s['thresholds']}")
    print(f"Files saved in: {folder.resolve()}")


if __name__ == "__main__":
    sys.exit(main())
