@echo off
cd /d "%~dp0"
echo =============================================================
echo   QueryPilot AI - Launching Dashboard and Engine
echo =============================================================
python run.py
pause
