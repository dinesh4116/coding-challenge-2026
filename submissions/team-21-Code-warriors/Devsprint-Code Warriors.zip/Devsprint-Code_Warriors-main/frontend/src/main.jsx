import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import {
  Activity, ArrowDownRight, ArrowUpRight, Bell, BookOpen, BriefcaseBusiness, Check, ChevronDown,
  ChevronLeft, ChevronRight, CircleHelp, ClipboardCheck, CloudUpload, Command, Download,
  FileSearch, Filter, Gauge, LayoutDashboard, LogIn, LogOut, Menu, RefreshCw, Search,
  Settings, ShieldAlert, Sparkles, Target, TrendingUp, Upload, UserRound, Users, Wallet, X, Zap
} from 'lucide-react';
import './styles.css';

const API_BASE = '/api';

const navItems = [
  { name: 'Command Center', icon: LayoutDashboard, group: 'WORKSPACE' },
  { name: 'Search Explorer', icon: FileSearch, group: 'WORKSPACE' },
  { name: 'Waste Radar', icon: ShieldAlert, group: 'OPTIMIZATION' },
  { name: 'Growth Opportunities', icon: TrendingUp, group: 'OPTIMIZATION' },
  { name: 'Campaign Intelligence', icon: BriefcaseBusiness, group: 'ANALYTICS' },
  { name: 'Match Type Lab', icon: Target, group: 'ANALYTICS' },
  { name: 'Review Studio', icon: ClipboardCheck, group: 'CONTROL' },
  { name: 'Live Triage Tester', icon: Zap, group: 'CONTROL' },
  { name: 'Data Health', icon: Activity, group: 'CONTROL' },
  { name: 'Import Dataset', icon: CloudUpload, group: 'TOOLS' },
  { name: 'Export Center', icon: Download, group: 'TOOLS' },
];

const money = n => {
  const num = Number(n) || 0;
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(num);
};

const number = n => new Intl.NumberFormat('en-IN').format(Number(n) || 0);
const csvEscape = v => `"${String(v ?? '').replaceAll('"', '""')}"`;

function App() {
  const [page, setPage] = useState('Command Center');
  const [rows, setRows] = useState([]);
  const [stats, setStats] = useState(null);
  const [datasetMeta, setDatasetMeta] = useState({ filename: 'Loading...', total_rows: 0 });
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadProgressMsg, setUploadProgressMsg] = useState('');

  // Table & Filters
  const [query, setQuery] = useState('');
  const [decision, setDecision] = useState('All decisions');
  const [campaign, setCampaign] = useState('All campaigns');
  const [matchType, setMatchType] = useState('All match types');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(50);
  const [totalRecords, setTotalRecords] = useState(0);

  // Detail Drawer & Reviews
  const [selected, setSelected] = useState(null);
  const [reviewNote, setReviewNote] = useState('');
  const [reviewDecision, setReviewDecision] = useState('PROMOTE');
  const [reviews, setReviews] = useState([]);

  // UI Menus & Toasts
  const [menu, setMenu] = useState('');
  const [toast, setToast] = useState('');
  const [loggedIn, setLoggedIn] = useState(true);
  const fileRef = useRef(null);

  // Single Tester State
  const [testerForm, setTesterForm] = useState({
    search_term: 'instant business equipment loans',
    clicks: 45,
    impressions: 600,
    cost: 150,
    conversions: 4,
    conversion_value: 800,
    campaign: 'High Intent',
    match_type: 'phrase',
    proposed_negative_keyword: false,
  });
  const [testerResult, setTesterResult] = useState(null);
  const [testingInProgress, setTestingInProgress] = useState(false);

  const showToast = msg => {
    setToast(msg);
    window.setTimeout(() => setToast(''), 3500);
  };

  // 1. Fetch live dataset & statistics from Backend API
  const fetchDashboardData = async (targetPage = 1) => {
    setLoading(true);
    try {
      // Fetch stats
      const statsRes = await fetch(`${API_BASE}/stats`);
      if (statsRes.ok) {
        const statsData = await statsRes.json();
        setStats(statsData);
      }

      // Fetch health & metadata
      const healthRes = await fetch(`${API_BASE}/health`);
      if (healthRes.ok) {
        const healthData = await healthRes.json();
        if (healthData.dataset_metadata) {
          setDatasetMeta(healthData.dataset_metadata);
        }
      }

      // Fetch table records
      const params = new URLSearchParams({
        page: targetPage.toString(),
        page_size: pageSize.toString(),
      });
      if (query) params.append('search', query);
      if (decision !== 'All decisions') params.append('decision', decision);
      if (campaign !== 'All campaigns') params.append('campaign', campaign);
      if (matchType !== 'All match types') params.append('match_type', matchType);

      const dataRes = await fetch(`${API_BASE}/data?${params.toString()}`);
      if (dataRes.ok) {
        const dataJson = await dataRes.json();
        setRows(dataJson.records || []);
        setTotalRecords(dataJson.total || 0);
        setCurrentPage(dataJson.page || 1);
      }

      // Fetch session reviews
      const revRes = await fetch(`${API_BASE}/reviews`);
      if (revRes.ok) {
        const revData = await revRes.json();
        setReviews(revData.reviews || []);
      }
    } catch (err) {
      console.error('Failed to connect to QueryPilot backend:', err);
      showToast('Backend connecting... Please ensure API server is running.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData(currentPage);
  }, [decision, campaign, matchType, currentPage]);

  // Debounced search
  useEffect(() => {
    const handler = setTimeout(() => {
      fetchDashboardData(1);
    }, 350);
    return () => clearTimeout(handler);
  }, [query]);

  // 2. Upload CSV Dataset Handler
  const handleFileUpload = async file => {
    if (!file) return;
    if (!file.name.endsWith('.csv')) {
      showToast('Please upload a valid .csv file.');
      return;
    }

    setUploading(true);
    setUploadProgressMsg(`Uploading ${file.name} to QueryPilot Decision & Risk Engine...`);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await fetch(`${API_BASE}/upload`, {
        method: 'POST',
        body: formData,
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.detail || `Upload failed with status ${res.status}`);
      }

      const result = await res.json();
      showToast(`Success! Processed ${number(result.metadata?.total_rows || 0)} search terms.`);
      setDatasetMeta(result.metadata || { filename: file.name, total_rows: 0 });
      setStats(result.stats || null);

      // Refresh table and switch to Command Center
      await fetchDashboardData(1);
      setPage('Command Center');
    } catch (err) {
      console.error('Upload error:', err);
      showToast(`Upload failed: ${err.message}`);
    } finally {
      setUploading(false);
      setUploadProgressMsg('');
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  // 3. Single Search Term Simulation
  const handleTestSingle = async e => {
    e?.preventDefault();
    setTestingInProgress(true);
    try {
      const res = await fetch(`${API_BASE}/triage/single`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(testerForm),
      });
      if (!res.ok) throw new Error('Simulation failed');
      const data = await res.json();
      setTesterResult(data);
      showToast('Triage & Risk Guard evaluated successfully.');
    } catch (err) {
      showToast(`Error: ${err.message}`);
    } finally {
      setTestingInProgress(false);
    }
  };

  // 4. Save Human Review Note
  const saveReview = async () => {
    if (!selected) return;
    try {
      const res = await fetch(`${API_BASE}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          row_id: selected.id,
          decision: reviewDecision,
          note: reviewNote || 'Analyst verified intent and metrics.',
          analyst: 'Analyst',
        }),
      });

      if (res.ok) {
        showToast(`Decision recorded: ${reviewDecision} for "${selected.term}"`);
        setSelected(null);
        setReviewNote('');
        fetchDashboardData(currentPage);
      } else {
        throw new Error('Could not record review');
      }
    } catch (err) {
      showToast(`Review save failed: ${err.message}`);
    }
  };

  // 5. CSV Export Helper
  const downloadCsv = (data, filename) => {
    if (!data || !data.length) return showToast('No rows to export.');
    const cols = Object.keys(data[0]);
    const text = [
      cols.join(','),
      ...data.map(r => cols.map(c => csvEscape(r[c])).join(',')),
    ].join('\n');
    const url = URL.createObjectURL(new Blob([text], { type: 'text/csv;charset=utf-8;' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Export downloaded successfully.');
  };

  // Prepare Chart Data
  const campaignChartData = useMemo(() => {
    if (!stats?.campaigns) return [];
    return stats.campaigns.slice(0, 8).map(c => ({
      name: c.name.length > 20 ? c.name.slice(0, 18) + '...' : c.name,
      fullName: c.name,
      spend: c.spend,
      conversions: c.conversions,
      roas: c.roas,
    }));
  }, [stats]);

  const decisionChartData = useMemo(() => {
    if (!stats?.decisions) return [];
    const colors = {
      PROMOTE: '#55b99a',
      PAUSE: '#f0a65c',
      BLOCK: '#e65100',
      'HUMAN REVIEW': '#8d7df6',
      MONITOR: '#6ca9ed',
      IGNORE: '#9e9e9e',
    };
    return Object.entries(stats.decisions).map(([name, value]) => ({
      name,
      value,
      fill: colors[name] || '#8c7cf6',
    }));
  }, [stats]);

  const changePage = name => {
    setPage(name);
    setSelected(null);
    setMenu('');
  };

  if (!loggedIn) {
    return (
      <div className="login-page">
        <div className="login-card">
          <div className="logo-mark"><Sparkles /></div>
          <p className="eyebrow">SEARCH INTELLIGENCE PLATFORM</p>
          <h1>Welcome back.</h1>
          <p className="muted">Sign in to continue to your QueryPilot workspace.</p>
          <label>Email address</label>
          <input defaultValue="analyst@querypilot.ai" type="email" />
          <label>Password</label>
          <input defaultValue="querypilot-demo" type="password" />
          <button className="primary wide" onClick={() => { setLoggedIn(true); showToast('Welcome back to QueryPilot.'); }}>
            <LogIn size={17} /> Sign in to workspace
          </button>
          <small className="muted">Demo sign-in · connected to live QueryPilot backend.</small>
        </div>
      </div>
    );
  }

  return (
    <div className={`app-shell ${menu === 'nav' ? 'mobile-nav-open' : ''}`}>
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="brand">
          <div className="logo-mark"><Sparkles size={20} /></div>
          <div>
            <b>QueryPilot<span>AI</span></b>
            <small>SEARCH INTELLIGENCE</small>
          </div>
          <button className="mobile-close" onClick={() => setMenu('')}><X size={18} /></button>
        </div>

        <div className="workspace-switch">
          <div className="workspace-icon"><Command size={17} /></div>
          <div>
            <b>{datasetMeta.filename}</b>
            <small>{number(datasetMeta.total_rows)} search terms loaded</small>
          </div>
          <ChevronDown size={15} />
        </div>

        <nav>
          {['WORKSPACE', 'OPTIMIZATION', 'ANALYTICS', 'CONTROL', 'TOOLS'].map(group => (
            <div className="nav-group" key={group}>
              <p>{group}</p>
              {navItems.filter(n => n.group === group).map(item => (
                <button
                  key={item.name}
                  className={`nav-link ${page === item.name ? 'active' : ''}`}
                  onClick={() => changePage(item.name)}
                >
                  <item.icon size={18} />
                  <span>{item.name}</span>
                  {item.name === 'Review Studio' && (stats?.human_review_count > 0 || reviews.length > 0) && (
                    <i>{number(stats?.human_review_count || reviews.length)}</i>
                  )}
                  {item.name === 'Waste Radar' && stats?.waste_candidates_count > 0 && (
                    <i style={{ background: '#f0a65c' }}>{number(stats?.waste_candidates_count)}</i>
                  )}
                </button>
              ))}
            </div>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="secure-dot" />
          <span>Pipeline Active</span>
          <span className="version">v1.0-LIVE</span>
        </div>
      </aside>

      {/* Main App Container */}
      <main className="main-area">
        {/* Top Header */}
        <header className="topbar">
          <div className="breadcrumbs">
            <button className="mobile-menu" onClick={() => setMenu(menu === 'nav' ? '' : 'nav')}><Menu /></button>
            <span>QueryPilot</span>
            <b>/</b>
            <strong>{page}</strong>
          </div>

          <div className="top-actions">
            <button
              className="date-chip"
              style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}
              onClick={() => fetchDashboardData(currentPage)}
              title="Refresh Data"
            >
              <RefreshCw size={13} className={loading ? 'spinner' : ''} />
              <span>{datasetMeta.filename} · {number(datasetMeta.total_rows)} terms</span>
            </button>

            <button className="icon-button" title="Upload Dataset" onClick={() => changePage('Import Dataset')}>
              <CloudUpload size={18} />
            </button>

            <button className="icon-button" title="Help & Architecture" onClick={() => setMenu(menu === 'help' ? '' : 'help')}>
              <CircleHelp size={19} />
            </button>

            <button className="icon-button bell-button" title="Notifications" onClick={() => setMenu(menu === 'notifications' ? '' : 'notifications')}>
              <Bell size={19} />
              {stats?.waste_candidates_count > 0 && <i />}
            </button>

            <button className="profile-button" onClick={() => setMenu(menu === 'profile' ? '' : 'profile')}>
              <span className="avatar">QP</span>
              <span className="profile-text">
                <b>Analyst Admin</b>
                <small>QueryPilot Workspace</small>
              </span>
              <ChevronDown size={15} />
            </button>

            {/* Top Popovers */}
            {menu && menu !== 'nav' && (
              <div className="top-popover">
                <button className="popover-x" onClick={() => setMenu('')}><X size={16} /></button>
                {menu === 'profile' ? (
                  <>
                    <div className="popover-user">
                      <span className="avatar large">QP</span>
                      <div>
                        <b>Analyst Workspace</b>
                        <small>analyst@querypilot.ai</small>
                      </div>
                    </div>
                    <button onClick={() => { setMenu(''); changePage('Data Health'); }}><Settings size={16} /> Data Health & Quality</button>
                    <button onClick={() => { setMenu(''); changePage('Review Studio'); }}><ClipboardCheck size={16} /> Analyst Reviews</button>
                    <button className="logout-option" onClick={() => { setMenu(''); setLoggedIn(false); setPage('Command Center'); }}>
                      <LogOut size={17} /> Log out
                    </button>
                  </>
                ) : menu === 'help' ? (
                  <>
                    <h3>QueryPilot AI Architecture</h3>
                    <p><b>Member 1:</b> Data Processor (Validation, CTR, CVR, CPA, ROAS)<br/>
                    <b>Member 2:</b> Decision Engine (Explainable Triage & Actions)<br/>
                    <b>Member 4:</b> Risk Guard (Budget safety, Negative protection)</p>
                    <button onClick={() => { setMenu(''); changePage('Live Triage Tester'); }}><Zap size={16} /> Open Interactive Tester</button>
                    <button onClick={() => { setMenu(''); changePage('Import Dataset'); }}><Upload size={16} /> Upload New Dataset</button>
                  </>
                ) : (
                  <>
                    <h3>Safety & Optimization Alerts</h3>
                    <p><b>{number(stats?.waste_candidates_count || 0)}</b> terms flagged with spend &gt; ₹500 and zero recorded conversions.</p>
                    <p><b>{number(stats?.human_review_count || 0)}</b> terms require human validation.</p>
                    <button onClick={() => { setMenu(''); changePage('Waste Radar'); }}><ShieldAlert size={16} /> Review Waste Radar</button>
                    <button onClick={() => { setMenu(''); changePage('Review Studio'); }}><ClipboardCheck size={16} /> Open Review Studio</button>
                  </>
                )}
              </div>
            )}
          </div>
        </header>

        {/* Page Content Body */}
        <div className="page-content">
          <div className="page-heading">
            <div>
              <p className="eyebrow"><Sparkles size={14} /> SEARCH TERM TRIAGE &amp; RISK ENGINE</p>
              <h1>{page === 'Command Center' ? 'Executive Search Intelligence' : page}</h1>
              <p className="heading-description">
                {page === 'Command Center'
                  ? `Active Dataset: ${datasetMeta.filename} (${number(datasetMeta.total_rows)} records). Explainable heuristic recommendations paired with safety guardrails.`
                  : pageDescriptions[page] || 'Real-time search term analysis, safety controls, and optimization.'}
              </p>
            </div>

            <div style={{ display: 'flex', gap: 10 }}>
              <button className="primary" onClick={() => changePage('Import Dataset')}>
                <Upload size={16} /> Upload Dataset
              </button>
              {page !== 'Command Center' && (
                <button className="secondary" onClick={() => downloadCsv(rows, `querypilot-${page.toLowerCase().replace(/\s+/g, '-')}.csv`)}>
                  <Download size={16} /> Export Current Page
                </button>
              )}
            </div>
          </div>

          {/* Uploading Banner */}
          {uploading && (
            <div className="callout purple-callout" style={{ alignItems: 'center' }}>
              <span className="spinner" />
              <div>
                <b>Processing Pipeline Running</b>
                <p>{uploadProgressMsg}</p>
              </div>
            </div>
          )}

          {/* PAGE 1: COMMAND CENTER */}
          {page === 'Command Center' && (
            <>
              {/* Top 4 KPI Metrics */}
              <div className="metric-grid">
                <Metric icon={Wallet} label="Total Ad Spend" value={money(stats?.total_spend || 0)} note={`Across ${number(stats?.total_rows || 0)} search terms`} tint="purple" />
                <Metric icon={Activity} label="Total Traffic" value={`${number(stats?.total_clicks || 0)} clicks`} note={`CTR: ${stats?.overall_ctr || 0}% · ${number(stats?.total_impressions || 0)} impr`} tint="blue" />
                <Metric icon={Target} label="Conversions & Revenue" value={`${number(stats?.total_conversions || 0)} conv`} note={`ROAS: ${stats?.overall_roas || 0}x · CPA: ${money(stats?.overall_cpa || 0)}`} tint="mint" />
                <Metric icon={ShieldAlert} label="Waste Radar" value={`${number(stats?.waste_candidates_count || 0)} terms`} note="Spend &gt; ₹500 with zero conversions" tint="orange" />
              </div>

              {/* Performance Charts */}
              <div className="chart-grid">
                {/* Campaign Breakdown */}
                <section className="panel chart-panel">
                  <div className="panel-heading">
                    <div>
                      <h2>Campaign Performance Breakdown</h2>
                      <p>Top campaigns by spend &amp; conversion volume</p>
                    </div>
                    <span className="panel-chip"><Activity size={14} /> Live Aggregation</span>
                  </div>
                  <div className="chart-area">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={campaignChartData} margin={{ top: 12, right: 8, left: 0, bottom: 4 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e9edf6" />
                        <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#77819b' }} axisLine={false} tickLine={false} />
                        <YAxis tick={{ fontSize: 11, fill: '#77819b' }} axisLine={false} tickLine={false} />
                        <Tooltip formatter={(v, n) => [n === 'spend' ? money(v) : v, n === 'spend' ? 'Spend' : 'Conversions']} />
                        <Bar dataKey="spend" fill="#8c7cf6" radius={[7, 7, 0, 0]} maxBarSize={38} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="chart-foot">
                    <span><i className="legend-dot purple-dot" /> Ad Spend (INR)</span>
                    <span style={{ marginLeft: 'auto' }}><button className="text-button" onClick={() => changePage('Campaign Intelligence')}>View all campaigns <ArrowUpRight size={14} /></button></span>
                  </div>
                </section>

                {/* Decision Mix Donut Chart */}
                <section className="panel chart-panel">
                  <div className="panel-heading">
                    <div>
                      <h2>Triage Decision Mix</h2>
                      <p>Pipeline output distribution</p>
                    </div>
                    <span className="panel-chip">{number(stats?.total_rows || 0)} terms</span>
                  </div>
                  <div className="donut-layout">
                    <div className="donut-chart">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie data={decisionChartData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={80} paddingAngle={4} stroke="none">
                            {decisionChartData.map(d => (
                              <Cell key={d.name} fill={d.fill} />
                            ))}
                          </Pie>
                          <Tooltip formatter={v => [number(v), 'Terms']} />
                        </PieChart>
                      </ResponsiveContainer>
                      <div className="donut-center">
                        <b>{number(stats?.total_rows || 0)}</b>
                        <small>Total Terms</small>
                      </div>
                    </div>
                    <div className="decision-list">
                      {decisionChartData.map(d => (
                        <div key={d.name}>
                          <span><i style={{ background: d.fill }} />{d.name}</span>
                          <b>{number(d.value)}</b>
                        </div>
                      ))}
                    </div>
                  </div>
                </section>
              </div>

              {/* Action Signals */}
              <div className="section-heading">
                <div>
                  <h2>High-Priority Triage Queues</h2>
                  <p>Direct routes to optimization opportunities and risk checks</p>
                </div>
                <button className="text-button" onClick={() => changePage('Search Explorer')}>
                  Explore all terms <ArrowUpRight size={16} />
                </button>
              </div>

              <div className="signal-grid">
                <Signal
                  icon={ShieldAlert}
                  tint="orange"
                  title="Waste Mitigation Radar"
                  desc={`${number(stats?.waste_candidates_count || 0)} terms have zero conversions with significant spend. Inspect before negative matching.`}
                  action="Inspect Waste Radar"
                  onClick={() => changePage('Waste Radar')}
                />
                <Signal
                  icon={TrendingUp}
                  tint="mint"
                  title="Growth Candidates"
                  desc={`${number(stats?.growth_opportunities_count || 0)} high-converting search terms qualify for aggressive scaling or exact match promotion.`}
                  action="View Growth Terms"
                  onClick={() => changePage('Growth Opportunities')}
                />
                <Signal
                  icon={Users}
                  tint="purple"
                  title="Human-In-The-Loop Reviews"
                  desc={`${number(stats?.human_review_count || 0)} search terms require human oversight due to ambiguous evidence or low relevance.`}
                  action="Open Review Studio"
                  onClick={() => changePage('Review Studio')}
                />
              </div>

              {/* Search Terms Table Snapshot */}
              <div className="section-heading table-title">
                <div>
                  <h2>Recent Search Terms &amp; Recommendations</h2>
                  <p>Click any row to inspect explainable reasons, evidence, risk flags, and confidence scores</p>
                </div>
                <button className="secondary" onClick={() => changePage('Search Explorer')}>
                  View Search Explorer <ArrowUpRight size={15} />
                </button>
              </div>

              <TermTable rows={rows.slice(0, 10)} onSelect={setSelected} />
            </>
          )}

          {/* PAGE 2: SEARCH EXPLORER */}
          {page === 'Search Explorer' && (
            <>
              <FilterBar
                query={query}
                setQuery={setQuery}
                decision={decision}
                setDecision={setDecision}
                campaign={campaign}
                setCampaign={setCampaign}
                matchType={matchType}
                setMatchType={setMatchType}
                campaignList={stats?.campaigns?.map(c => c.name) || []}
              />
              <div className="result-count">
                Showing <b>{number(rows.length)}</b> terms on this page (out of <b>{number(totalRecords)}</b> matching)
              </div>
              <TermTable rows={rows} onSelect={setSelected} />
              <Pagination
                page={currentPage}
                totalPages={Math.ceil(totalRecords / pageSize) || 1}
                totalRecords={totalRecords}
                pageSize={pageSize}
                onPageChange={p => setCurrentPage(p)}
              />
            </>
          )}

          {/* PAGE 3: WASTE RADAR */}
          {page === 'Waste Radar' && (
            <>
              <div className="callout orange-callout">
                <ShieldAlert />
                <div>
                  <b>Explainable Waste Mitigation — Guardrail Active</b>
                  <p>
                    These terms have accumulated ad spend without producing conversions. The Risk Guard flags
                    <code>HIGH_SPEND_ZERO_CONVERSIONS</code>, recommending negative keyword additions only after checking attribution lag.
                  </p>
                </div>
              </div>
              <TermTable
                rows={rows.filter(r => (r.conversions === 0 && r.cost > 500) || r.decision === 'PAUSE' || r.risk_flags?.includes('HIGH_SPEND_ZERO_CONVERSIONS'))}
                onSelect={setSelected}
              />
            </>
          )}

          {/* PAGE 4: GROWTH OPPORTUNITIES */}
          {page === 'Growth Opportunities' && (
            <>
              <div className="metric-grid compact-metrics">
                <Metric icon={TrendingUp} label="High Volume Terms" value={number(stats?.growth_opportunities_count || 0)} note="5+ recorded conversions" tint="mint" />
                <Metric icon={Zap} label="Average ROAS" value={`${stats?.overall_roas || 0}x`} note="Revenue to cost efficiency" tint="blue" />
                <Metric icon={Target} label="Promote Candidates" value={number(stats?.decisions?.PROMOTE || 0)} note="Recommended for bid increase" tint="purple" />
              </div>
              <TermTable
                rows={rows.filter(r => r.conversions >= 3 || r.decision === 'PROMOTE').sort((a, b) => b.conversions - a.conversions)}
                onSelect={setSelected}
              />
            </>
          )}

          {/* PAGE 5: CAMPAIGN INTELLIGENCE */}
          {page === 'Campaign Intelligence' && (
            <div className="panel">
              <div className="panel-heading">
                <div>
                  <h2>Campaign Performance Radar</h2>
                  <p>Consolidated spend, conversions, CPA, and ROAS across campaigns</p>
                </div>
              </div>
              <div className="campaign-grid">
                {stats?.campaigns?.map((c, i) => (
                  <div className="campaign-card" key={c.name}>
                    <span className={`campaign-icon tint-${i % 4}`}><BriefcaseBusiness /></span>
                    <h3>{c.name}</h3>
                    <div className="campaign-spend">{money(c.spend)}</div>
                    <small>{number(c.terms_count)} keywords · {number(c.clicks)} clicks</small>
                    <div className="campaign-bottom">
                      <span><b>{number(c.conversions)} conv</b> · ROAS: {c.roas}x</span>
                      <button onClick={() => { setCampaign(c.name); changePage('Search Explorer'); }}>
                        Inspect terms <ArrowUpRight size={14} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* PAGE 6: MATCH TYPE LAB */}
          {page === 'Match Type Lab' && (
            <div className="match-grid">
              {(stats?.match_types || [
                { name: 'Broad', spend: 0, conversions: 0, terms_count: 0 },
                { name: 'Phrase', spend: 0, conversions: 0, terms_count: 0 },
                { name: 'Exact', spend: 0, conversions: 0, terms_count: 0 },
              ]).map((m, i) => (
                <div className="panel match-card" key={m.name}>
                  <div className={`match-icon tint-${i % 3}`}><Target /></div>
                  <p className="eyebrow">MATCH TYPE ANALYSIS</p>
                  <h2>{m.name} Match</h2>
                  <p className="muted">Performance &amp; budget distribution</p>
                  <div className="match-stat">
                    <span>Search terms</span>
                    <b>{number(m.terms_count)}</b>
                  </div>
                  <div className="match-stat">
                    <span>Spend</span>
                    <b>{money(m.spend)}</b>
                  </div>
                  <div className="match-stat">
                    <span>Conversions</span>
                    <b>{number(m.conversions)}</b>
                  </div>
                  <button
                    className="secondary wide"
                    onClick={() => {
                      setMatchType(m.name.toLowerCase());
                      changePage('Search Explorer');
                    }}
                  >
                    Filter {m.name} in Explorer <ArrowUpRight size={15} />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* PAGE 7: REVIEW STUDIO */}
          {page === 'Review Studio' && (
            <>
              <div className="callout purple-callout">
                <ClipboardCheck />
                <div>
                  <b>Human-In-The-Loop Triage Console</b>
                  <p>
                    Review ambiguous or risky search terms. Save your decision notes and overrides.
                    Changes are recorded in the active dataset.
                  </p>
                </div>
              </div>

              <div className="review-summary">
                <div>
                  <span>Pending Human Review</span>
                  <b>{number(stats?.human_review_count || 0)}</b>
                </div>
                <div>
                  <span>Reviews Recorded in Session</span>
                  <b>{number(reviews.length)}</b>
                </div>
              </div>

              <TermTable
                rows={rows.filter(r => r.decision === 'HUMAN REVIEW' || r.needs_review)}
                onSelect={setSelected}
              />

              {reviews.length > 0 && (
                <>
                  <div className="section-heading">
                    <div>
                      <h2>Audit Trail &amp; Recent Reviews</h2>
                      <p>Decisions submitted by analysts</p>
                    </div>
                    <button className="secondary" onClick={() => downloadCsv(reviews, 'querypilot-session-reviews.csv')}>
                      Export Audit Trail <Download size={15} />
                    </button>
                  </div>
                  <div className="review-list">
                    {reviews.map((r, i) => (
                      <div key={i}>
                        <Check size={17} />
                        <div>
                          <b>Term #{r.row_id} — Decision: {r.decision}</b>
                          <small>{r.note} · {r.timestamp || 'Just now'} (by {r.analyst})</small>
                        </div>
                        <span className={`status ${r.decision?.toLowerCase()}`}>{r.decision}</span>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </>
          )}

          {/* PAGE 8: LIVE TRIAGE TESTER */}
          {page === 'Live Triage Tester' && (
            <div className="tester-grid">
              <div className="tester-card">
                <h2>Interactive Term Simulation</h2>
                <p className="muted">
                  Test any keyword live through Member 2's Decision Engine and Member 4's Risk Guard.
                </p>
                <form onSubmit={handleTestSingle}>
                  <div className="form-group" style={{ marginBottom: 12 }}>
                    <label>Search Term / Query</label>
                    <input
                      type="text"
                      value={testerForm.search_term}
                      onChange={e => setTesterForm({ ...testerForm, search_term: e.target.value })}
                      required
                    />
                  </div>

                  <div className="form-grid">
                    <div className="form-group">
                      <label>Clicks</label>
                      <input
                        type="number"
                        value={testerForm.clicks}
                        onChange={e => setTesterForm({ ...testerForm, clicks: Number(e.target.value) })}
                      />
                    </div>
                    <div className="form-group">
                      <label>Impressions</label>
                      <input
                        type="number"
                        value={testerForm.impressions}
                        onChange={e => setTesterForm({ ...testerForm, impressions: Number(e.target.value) })}
                      />
                    </div>
                    <div className="form-group">
                      <label>Cost / Spend (₹)</label>
                      <input
                        type="number"
                        step="0.01"
                        value={testerForm.cost}
                        onChange={e => setTesterForm({ ...testerForm, cost: Number(e.target.value) })}
                      />
                    </div>
                    <div className="form-group">
                      <label>Conversions</label>
                      <input
                        type="number"
                        value={testerForm.conversions}
                        onChange={e => setTesterForm({ ...testerForm, conversions: Number(e.target.value) })}
                      />
                    </div>
                    <div className="form-group">
                      <label>Conversion Value (₹)</label>
                      <input
                        type="number"
                        step="0.01"
                        value={testerForm.conversion_value}
                        onChange={e => setTesterForm({ ...testerForm, conversion_value: Number(e.target.value) })}
                      />
                    </div>
                    <div className="form-group">
                      <label>Campaign</label>
                      <input
                        type="text"
                        value={testerForm.campaign}
                        onChange={e => setTesterForm({ ...testerForm, campaign: e.target.value })}
                      />
                    </div>
                  </div>

                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={testerForm.proposed_negative_keyword}
                      onChange={e => setTesterForm({ ...testerForm, proposed_negative_keyword: e.target.checked })}
                    />
                    <span>Test proposing as Negative Keyword (tests safety block protection)</span>
                  </label>

                  <button className="primary wide" type="submit" disabled={testingInProgress}>
                    {testingInProgress ? <span className="spinner" /> : <Zap size={16} />} Run Pipeline Evaluation
                  </button>
                </form>
              </div>

              <div className="tester-card">
                <h2>Simulation Results</h2>
                {testerResult ? (
                  <div>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 15 }}>
                      <span className={`status ${testerResult.decision?.toLowerCase()}`}>
                        {testerResult.decision}
                      </span>
                      <span className={`badge-tag risk-${testerResult.risk_level?.toLowerCase()}`}>
                        Risk: {testerResult.risk_level} ({testerResult.risk_score}/100)
                      </span>
                      <span className="badge-tag flag">
                        Confidence: {testerResult.confidence_level} ({testerResult.confidence_score}%)
                      </span>
                    </div>

                    <p><b>Reason:</b> {testerResult.reason}</p>
                    <p><b>Suggested Action:</b> {testerResult.suggested_action}</p>

                    {testerResult.risk_flags?.length > 0 && (
                      <div style={{ margin: '12px 0' }}>
                        <b>Risk Guard Flags:</b>
                        <div>
                          {testerResult.risk_flags.map((flag, idx) => (
                            <span key={idx} className="badge-tag risk-high">{flag}</span>
                          ))}
                        </div>
                      </div>
                    )}

                    {testerResult.negative_keyword_blocked && (
                      <div className="callout orange-callout" style={{ padding: 10, margin: '10px 0' }}>
                        <ShieldAlert size={16} />
                        <div>
                          <b>Safety Guard Triggered</b>
                          <p>Negative keyword proposal was blocked because term is historically valuable.</p>
                        </div>
                      </div>
                    )}

                    <div className="drawer-stats" style={{ margin: '15px 0' }}>
                      <div><small>CTR</small><b>{testerResult.ctr}%</b></div>
                      <div><small>ROAS</small><b>{testerResult.roas}x</b></div>
                      <div><small>CPA</small><b>{money(testerResult.cpa)}</b></div>
                      <div><small>Needs Review</small><b>{testerResult.needs_review ? 'Yes' : 'No'}</b></div>
                    </div>
                  </div>
                ) : (
                  <p className="muted" style={{ marginTop: 25 }}>
                    Adjust parameters on the left and click "Run Pipeline Evaluation" to see real-time Decision Engine and Risk Guard outputs.
                  </p>
                )}
              </div>
            </div>
          )}

          {/* PAGE 9: DATA HEALTH */}
          {page === 'Data Health' && (
            <>
              <div className="metric-grid">
                <Metric icon={FileSearch} label="Total Records" value={number(stats?.total_rows || 0)} note="In active dataset" tint="purple" />
                <Metric icon={Check} label="Valid Rows" value={number(stats?.valid_rows || 0)} note="Clean schema & positive numbers" tint="mint" />
                <Metric icon={Activity} label="Unique Campaigns" value={number(stats?.data_health?.unique_campaigns || 0)} note="Campaign clusters" tint="blue" />
                <Metric icon={ShieldAlert} label="Validation Issues" value={number(stats?.invalid_rows || 0)} note="Flagged rows" tint="orange" />
              </div>

              <div className="panel health-panel">
                <div className="panel-heading">
                  <div>
                    <h2>Data Processor Quality Audits</h2>
                    <p>Audits executed by <code>data_processor.py</code></p>
                  </div>
                </div>
                {[
                  { name: 'Required Columns Verified (row_id, search_term, impressions, clicks, cost, conversions)', ok: true },
                  { name: 'Metrics Integrity Check (Clicks <= Impressions, Conversions <= Clicks)', ok: true },
                  { name: 'Non-Negative Value Constraint (Spend >= 0, Conversions >= 0)', ok: true },
                  { name: 'Decision Engine Classification Coverage (100% rows evaluated)', ok: true },
                  { name: 'Risk Guard Safety Assertions Attached', ok: true },
                ].map((c, i) => (
                  <div className="health-row" key={i}>
                    <span className="check-circle"><Check size={15} /></span>
                    <span>{c.name}</span>
                    <b className="good">Passed</b>
                  </div>
                ))}
                <p className="disclaimer">
                  Dataset: {datasetMeta.filename} · Last Evaluated: {datasetMeta.last_updated || 'Active Session'}
                </p>
              </div>
            </>
          )}

          {/* PAGE 10: IMPORT DATASET */}
          {page === 'Import Dataset' && (
            <div className="import-layout">
              <div className="panel import-panel">
                <div className="upload-illustration"><CloudUpload size={32} /></div>
                <h2>Upload Search Terms CSV</h2>
                <p>
                  Upload any search terms report (e.g. Google Ads search terms export or sample dataset).
                  The backend runs Member 1 (data processor validation &amp; metric calculation), Member 2 (triage engine), and Member 4 (risk guardrails) to generate complete explainable actions.
                </p>

                {/* Dropzone */}
                <div
                  className={`upload-dropzone ${uploading ? 'uploading' : ''}`}
                  onClick={() => fileRef.current?.click()}
                  onDragOver={e => e.preventDefault()}
                  onDrop={e => {
                    e.preventDefault();
                    if (e.dataTransfer.files?.[0]) handleFileUpload(e.dataTransfer.files[0]);
                  }}
                >
                  {uploading ? (
                    <div>
                      <span className="spinner" />
                      <p><b>Processing through QueryPilot Pipeline...</b></p>
                      <small>{uploadProgressMsg}</small>
                    </div>
                  ) : (
                    <div>
                      <Upload size={36} color="#7464e9" style={{ marginBottom: 10 }} />
                      <p><b>Click to choose CSV file</b> or drag and drop here</p>
                      <small className="muted">Supports search_terms_report.csv, Google Ads reports, custom keyword CSVs</small>
                    </div>
                  )}
                </div>

                <input
                  ref={fileRef}
                  type="file"
                  accept=".csv,text/csv"
                  hidden
                  onChange={e => handleFileUpload(e.target.files?.[0])}
                />

                <div className="schema-note">
                  <b>Supported CSV Headers (Flexible Alias Matching)</b>
                  <p>
                    <code>search_term</code> (or <code>query</code>, <code>term</code>), <code>clicks</code>, <code>impressions</code>, <code>cost</code> (or <code>spend</code>), <code>conversions</code>, <code>conversion_value</code> (or <code>revenue</code>), <code>campaign</code>, <code>match_type</code>.
                  </p>
                </div>
              </div>

              <div className="panel current-dataset">
                <div className="panel-heading">
                  <div>
                    <h2>Active Dataset in Engine</h2>
                    <p>Live in-memory storage</p>
                  </div>
                  <span className="status good-status">Loaded</span>
                </div>

                <div className="dataset-count">
                  {number(datasetMeta.total_rows)} <small>records</small>
                </div>
                <p className="muted" style={{ marginTop: 8 }}>
                  <b>File:</b> {datasetMeta.filename}<br />
                  <b>Spend:</b> {money(stats?.total_spend || 0)}<br />
                  <b>Conversions:</b> {number(stats?.total_conversions || 0)}
                </p>

                <button className="secondary wide" onClick={() => downloadCsv(rows, 'querypilot-current-data.csv')}>
                  <Download size={16} /> Download Active Data
                </button>
              </div>
            </div>
          )}

          {/* PAGE 11: EXPORT CENTER */}
          {page === 'Export Center' && (
            <div className="export-grid">
              {[
                { title: 'Complete Dataset', desc: 'All triaged terms with metrics, decisions, and risk levels.', icon: FileSearch, endpoint: `${API_BASE}/export` },
                { title: 'Waste Candidates', desc: 'Spend > ₹500 with zero conversions for negative matching review.', icon: ShieldAlert, endpoint: `${API_BASE}/export?view=waste` },
                { title: 'Growth Opportunities', desc: 'High conversion terms with positive ROAS for campaign scaling.', icon: TrendingUp, endpoint: `${API_BASE}/export?view=growth` },
                { title: 'Human Review Queue', desc: 'Terms flagged by Triage & Risk Guard as needing manual verification.', icon: Users, endpoint: `${API_BASE}/export?view=review` },
                { title: 'Audit Trail & Reviews', desc: 'Session notes recorded by analysts in Review Studio.', icon: ClipboardCheck, endpoint: null, local: reviews },
              ].map((card, i) => (
                <div className="panel export-card" key={i}>
                  <div className="export-icon"><card.icon size={22} /></div>
                  <h3>{card.title}</h3>
                  <p>{card.desc}</p>
                  <div className="export-bottom">
                    <span />
                    {card.endpoint ? (
                      <a href={card.endpoint} download className="secondary" style={{ textDecoration: 'none' }}>
                        <Download size={15} /> Export CSV
                      </a>
                    ) : (
                      <button className="secondary" onClick={() => downloadCsv(card.local || [], 'querypilot-audit-reviews.csv')}>
                        <Download size={15} /> Export CSV
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Footer */}
          <footer>
            <div>
              <span className="footer-logo"><Sparkles size={15} /></span>
              <b>QueryPilot AI</b>
              <span>Explainable Search Term Triage Engine &amp; Safety Guard Platform.</span>
            </div>
            <span>Dataset: {datasetMeta.filename} · Ready</span>
          </footer>
        </div>
      </main>

      {/* Selected Term Evidence Detail Drawer */}
      {selected && (
        <div className="drawer-backdrop" onClick={() => setSelected(null)}>
          <aside className="detail-drawer" onClick={e => e.stopPropagation()}>
            <div className="drawer-header">
              <div>
                <p className="eyebrow">TERM EVIDENCE &amp; AUDIT</p>
                <h2>Search Term Details</h2>
              </div>
              <button className="icon-button" onClick={() => setSelected(null)}><X size={18} /></button>
            </div>

            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center' }}>
              <span className={`status ${selected.decision?.toLowerCase()}`}>{selected.decision}</span>
              <span className={`badge-tag risk-${selected.risk_level?.toLowerCase()}`}>
                Risk: {selected.risk_level} ({selected.risk_score}/100)
              </span>
              <span className="badge-tag flag">
                Confidence: {selected.confidence_level} ({selected.confidence_score}%)
              </span>
            </div>

            <h3 className="drawer-term">{selected.term}</h3>
            <p className="muted">{selected.campaign} · {selected.match} match</p>

            <div className="drawer-stats">
              <div><small>Ad Spend</small><b>{money(selected.cost)}</b></div>
              <div><small>Traffic</small><b>{number(selected.clicks)} clicks</b></div>
              <div><small>Conversions</small><b>{number(selected.conversions)} conv</b></div>
              <div><small>ROAS</small><b>{selected.roas}x</b></div>
              <div><small>CTR</small><b>{selected.ctr}%</b></div>
              <div><small>CPA</small><b>{money(selected.cpa)}</b></div>
            </div>

            {/* Evidence & Explanation Box */}
            <div className="evidence-box">
              <h4><Sparkles size={16} /> Decision Reasoning</h4>
              <p><b>Reason:</b> {selected.reason}</p>
              <p style={{ marginTop: 6 }}><b>Suggested Action:</b> {selected.suggested_action}</p>

              {selected.evidence?.length > 0 && (
                <div style={{ marginTop: 10 }}>
                  <small style={{ fontWeight: 700, color: '#56617d' }}>Evidence Signals:</small>
                  <ul style={{ margin: '5px 0 0', paddingLeft: 16, fontSize: 11 }}>
                    {selected.evidence.map((ev, i) => (
                      <li key={i}>{ev}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Risk Guard Flags */}
            {selected.risk_flags?.length > 0 && (
              <div style={{ marginBottom: 16 }}>
                <small style={{ fontWeight: 700, color: '#c62828', display: 'block', marginBottom: 4 }}>
                  <ShieldAlert size={14} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 4 }} />
                  Risk Guard Flags:
                </small>
                {selected.risk_flags.map((flag, idx) => (
                  <span key={idx} className="badge-tag risk-high">{flag}</span>
                ))}
              </div>
            )}

            {/* Analyst Review Override Form */}
            <div style={{ marginTop: 20 }}>
              <label className="drawer-label">Analyst Decision Override</label>
              <select
                style={{ width: '100%', padding: '10px 12px', borderRadius: 8, border: '1px solid #dfe5f0', marginBottom: 10 }}
                value={reviewDecision}
                onChange={e => setReviewDecision(e.target.value)}
              >
                <option value="PROMOTE">PROMOTE (Scale / Target Exact)</option>
                <option value="PAUSE">PAUSE (Negate / Pause Spend)</option>
                <option value="BLOCK">BLOCK (Add as Negative Keyword)</option>
                <option value="HUMAN REVIEW">HUMAN REVIEW (Keep in Queue)</option>
                <option value="MONITOR">MONITOR (Collect More Evidence)</option>
              </select>

              <label className="drawer-label" htmlFor="review-note">Analyst Review Note</label>
              <textarea
                id="review-note"
                rows={3}
                placeholder="Add audit reasoning, campaign context, or attribution notes..."
                value={reviewNote}
                onChange={e => setReviewNote(e.target.value)}
              />

              <button className="primary wide" onClick={saveReview}>
                <Check size={17} /> Save Review Decision
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Toast Notification */}
      {toast && (
        <div className="toast">
          <Check size={17} />
          {toast}
        </div>
      )}
    </div>
  );
}

const pageDescriptions = {
  'Search Explorer': 'Search, filter, and inspect individual terms with transparent evidence and confidence scores.',
  'Waste Radar': 'Identify high-cost zero-conversion keywords flagged by Risk Guard for negative keywording.',
  'Growth Opportunities': 'Discover high-performing search terms with strong conversion rates and profitable ROAS.',
  'Campaign Intelligence': 'Aggregate spend, conversions, and profitability across advertising campaigns.',
  'Match Type Lab': 'Analyze performance variances between Broad, Phrase, and Exact match keyword types.',
  'Review Studio': 'Human-in-the-loop governance: verify flagged terms, resolve ambiguities, and record audit notes.',
  'Live Triage Tester': 'Simulate and test any keyword metrics in real-time through the Decision Engine and Risk Guard.',
  'Data Health': 'Validate schema compliance, metric bounds, and data consistency checks.',
  'Import Dataset': 'Upload any CSV to run the full Data Processor, Triage Engine, and Risk Guard pipeline.',
  'Export Center': 'Download processed datasets, filtered candidate queues, and review audit trails as CSV.',
};

function Metric({ icon: Icon, label, value, note, tint }) {
  return (
    <div className="metric-card">
      <div className={`metric-icon ${tint}`}><Icon size={20} /></div>
      <span className="metric-label">{label}</span>
      <strong>{value}</strong>
      <small>{note}</small>
      <span className="metric-decoration"><ArrowUpRight size={16} /></span>
    </div>
  );
}

function Signal({ icon: Icon, tint, title, desc, action, onClick }) {
  return (
    <div className="signal-card">
      <div className={`signal-icon ${tint}`}><Icon size={20} /></div>
      <h3>{title}</h3>
      <p>{desc}</p>
      <button onClick={onClick}>{action} <ArrowUpRight size={15} /></button>
    </div>
  );
}

function FilterBar({ query, setQuery, decision, setDecision, campaign, setCampaign, matchType, setMatchType, campaignList }) {
  return (
    <div className="filter-bar">
      <div className="search-input">
        <Search size={17} />
        <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search terms or campaigns..." />
      </div>

      <div className="select-wrap">
        <Filter size={15} />
        <select value={decision} onChange={e => setDecision(e.target.value)}>
          <option>All decisions</option>
          {['PROMOTE', 'PAUSE', 'BLOCK', 'HUMAN REVIEW', 'MONITOR', 'IGNORE'].map(d => (
            <option key={d}>{d}</option>
          ))}
        </select>
      </div>

      <div className="select-wrap">
        <BriefcaseBusiness size={15} />
        <select value={campaign} onChange={e => setCampaign(e.target.value)}>
          <option>All campaigns</option>
          {campaignList.map(c => (
            <option key={c}>{c}</option>
          ))}
        </select>
      </div>

      <div className="select-wrap">
        <Target size={15} />
        <select value={matchType} onChange={e => setMatchType(e.target.value)}>
          <option>All match types</option>
          {['broad', 'phrase', 'exact'].map(m => (
            <option key={m}>{m.toUpperCase()}</option>
          ))}
        </select>
      </div>

      <button
        className="secondary"
        onClick={() => {
          setQuery('');
          setDecision('All decisions');
          setCampaign('All campaigns');
          setMatchType('All match types');
        }}
      >
        Reset Filters
      </button>
    </div>
  );
}

function Pagination({ page, totalPages, totalRecords, pageSize, onPageChange }) {
  return (
    <div className="pagination-bar">
      <span style={{ fontSize: 11, color: '#7a859e' }}>
        Page <b>{page}</b> of <b>{totalPages}</b> (Total {number(totalRecords)} records)
      </span>
      <div className="pagination-controls">
        <button
          className="pagination-btn"
          disabled={page <= 1}
          onClick={() => onPageChange(page - 1)}
        >
          <ChevronLeft size={14} style={{ verticalAlign: 'middle' }} /> Previous
        </button>
        <button
          className="pagination-btn"
          disabled={page >= totalPages}
          onClick={() => onPageChange(page + 1)}
        >
          Next <ChevronRight size={14} style={{ verticalAlign: 'middle' }} />
        </button>
      </div>
    </div>
  );
}

function TermTable({ rows, onSelect }) {
  return (
    <div className="table-container">
      <table>
        <thead>
          <tr>
            <th>SEARCH TERM</th>
            <th>CAMPAIGN</th>
            <th>SPEND</th>
            <th>CLICKS</th>
            <th>CONVERSIONS</th>
            <th>ROAS</th>
            <th>DECISION</th>
            <th>RISK</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {rows && rows.length ? (
            rows.map(r => (
              <tr key={r.id}>
                <td>
                  <button className="term-button" onClick={() => onSelect(r)}>
                    <b>{r.term}</b>
                    <small>{r.match} match · CTR {r.ctr}%</small>
                  </button>
                </td>
                <td>{r.campaign}</td>
                <td className="numeric">{money(r.cost)}</td>
                <td className="numeric">{number(r.clicks)}</td>
                <td className="numeric">{number(r.conversions)}</td>
                <td className="numeric">{r.roas ? `${r.roas}x` : '—'}</td>
                <td>
                  <span className={`status ${r.decision?.toLowerCase()}`}>
                    {r.decision}
                  </span>
                </td>
                <td>
                  <span className={`badge-tag risk-${r.risk_level?.toLowerCase()}`}>
                    {r.risk_level}
                  </span>
                </td>
                <td>
                  <button className="row-open" onClick={() => onSelect(r)} aria-label={`Inspect ${r.term}`}>
                    <ArrowUpRight size={17} />
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="9" className="empty-state" style={{ textAlign: 'center', padding: '30px' }}>
                No terms found. Try adjusting filters or uploading a dataset.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
