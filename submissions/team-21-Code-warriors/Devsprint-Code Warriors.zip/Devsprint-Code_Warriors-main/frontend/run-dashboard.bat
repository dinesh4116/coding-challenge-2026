@echo off
cd /d "%~dp0"
if not exist package.json (
  echo ERROR: package.json is missing. Please extract the entire ZIP first.
  pause
  exit /b 1
)
echo Installing project dependencies...
call npm install
if errorlevel 1 (
  echo Dependency installation failed. Check your internet connection and Node.js installation.
  pause
  exit /b 1
)
echo Starting QueryPilot React dashboard...
call npm run dev
pause
