# QueryPilot React Dashboard

## Run on Windows
1. Download the ZIP and choose **Extract All**.
2. Open the extracted folder in VS Code. The folder should directly contain `package.json`, `index.html`, `src`, and `run-dashboard.bat`.
3. In the VS Code terminal, run:

```powershell
npm install
npm run dev
```

Alternatively, double-click `run-dashboard.bat`.

## Important
- This is a React + Vite frontend.
- The profile menu includes Log out; logout returns to the demo login screen.
- Login is a demo-only frontend interaction; no real authentication backend is connected.
