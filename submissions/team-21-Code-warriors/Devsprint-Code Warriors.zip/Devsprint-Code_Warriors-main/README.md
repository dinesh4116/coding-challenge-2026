# QueryPilot AI — Search Intelligence & Triage Platform

An end-to-end, explainable search term triage engine equipped with safety guardrails and an analyst dashboard.

---

## Architecture & Integration

- **Data Ingestion & Validation** (`data_processor.py`):
  - Validates required columns (`row_id`, `search_term`, `clicks`, `impressions`, `cost`, `conversions`, `conversion_value`, `campaign`, `match_type`).
  - Flags data-quality issues (`is_valid`, `validation_issues`).
  - Calculates core metrics: Click-Through Rate (CTR), Conversion Rate (CVR), Cost Per Acquisition (CPA), Return on Ad Spend (ROAS).

- **Triage & Decision Engine** (`decision_engine.py` / `triage_engine.py`):
  - Explainable heuristic triage categorizing terms into `PROMOTE`, `PAUSE`, `BLOCK`, `HUMAN REVIEW`, `MONITOR`, and `IGNORE`.
  - Computes explainable evidence lists, confidence levels/scores, and human readable reasons with suggested actions.

- **Risk Guard** (`risk_guard.py`):
  - Safety checks: flags `HIGH_SPEND_ZERO_CONVERSIONS`, catches `INSUFFICIENT_EVIDENCE` and `MISSING_METRICS`.
  - Protects valuable historical terms from being mistakenly added as negative keywords (`POTENTIALLY_VALUABLE_NEGATIVE_KEYWORD`).

- **Master REST API & Backend** (`QueryPilot-AI/app.py`):
  - Built with FastAPI + Uvicorn.
  - Endpoints:
    - `POST /api/upload`: Upload any search terms CSV. Runs the entire pipeline and immediately updates the live dashboard.
    - `GET /api/stats`: Comprehensive KPIs, ROAS/CPA calculations, campaign breakdowns, and decision mix.
    - `GET /api/data`: Paginated search terms with live filtering (decision, campaign, match type, search query).
    - `POST /api/triage/single`: Real-time simulator for testing individual search terms.
    - `POST /api/review`: Record human-in-the-loop analyst decisions and audit notes.
    - `GET /api/export`: Export processed CSVs and candidate queues.
    - `GET /`: Serves the integrated React frontend directly.

- **Modern React Dashboard** (`frontend/`):
  - Built with React, Vite, Recharts, and Lucide Icons.
  - Features 10 workspaces: **Command Center**, **Search Explorer**, **Waste Radar**, **Growth Opportunities**, **Campaign Intelligence**, **Match Type Lab**, **Review Studio**, **Live Triage Tester**, **Data Health**, **Import Dataset**, and **Export Center**.

---

## Running the Application

### Option 1: One-Click Launch (All-in-One Backend + Dashboard)
Double-click `run_dashboard.bat` in the root folder, or run:
```powershell
python run.py
```
Open your browser at **[http://127.0.0.1:8000](http://127.0.0.1:8000)**.

### Option 2: Full Dev Mode (Backend + Vite Dev Server)
1. **Terminal 1 (Backend API):**
   ```powershell
   cd QueryPilot-AI
   python -m uvicorn app:app --host 127.0.0.1 --port 8000 --reload
   ```
2. **Terminal 2 (Frontend with Hot Reload):**
   ```powershell
   cd frontend
   npm run dev
   ```
   Open your browser at **[http://127.0.0.1:5173](http://127.0.0.1:5173)**.

---

## Uploading Datasets
1. Go to the **Import Dataset** tab in the dashboard navigation.
2. Click **Choose CSV file** or drag and drop any CSV dataset.
3. The pipeline immediately runs `validate_data` ➔ `calculate_metrics` ➔ `triage_keyword` ➔ `evaluate_risk`, updates the 25,000+ records, recalculates all KPIs and charts, and displays the processed results.