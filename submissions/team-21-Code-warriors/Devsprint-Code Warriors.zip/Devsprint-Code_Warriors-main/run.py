"""QueryPilot AI - Master Launch Script.

Runs the backend pipeline (Data Processor + Triage Engine + Risk Guard)
and serves the complete React dashboard on http://127.0.0.1:8000.
Also allows uploading any new dataset (.csv) directly via the dashboard
and immediately viewing the triaged results.
"""

import sys
import webbrowser
from pathlib import Path

# Add directories to sys.path so modules resolve seamlessly
root_dir = Path(__file__).resolve().parent
qp_dir = root_dir / "QueryPilot-AI"

sys.path.insert(0, str(qp_dir))
sys.path.insert(0, str(root_dir))

if __name__ == "__main__":
    import uvicorn

    print("=" * 65)
    print("  QueryPilot AI — Search Term Triage Engine & Dashboard")
    print("  Serving Complete Platform at: http://127.0.0.1:8000")
    print("=" * 65)
    print("\nOpening dashboard in your web browser...")

    try:
        webbrowser.open("http://127.0.0.1:8000")
    except Exception:
        pass

    # Start Uvicorn serving app:app
    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=False)
