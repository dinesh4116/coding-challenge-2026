"""QueryPilotAI - Master API Server.

Integrates:
- Member 1: data_processor.py (Data ingestion, validation & metrics calculation)
- Member 2: decision_engine.py / triage_engine.py (Explainable heuristic triage)
- Member 4: risk_guard.py (Safety guardrails, risk evaluation & protection)
Exposes complete REST API for the React dashboard with live dataset upload,
real-time stats, filtering, single-term evaluation, and export.
"""

from __future__ import annotations

import io
import math
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel

# Import internal modules
try:
    from data_processor import calculate_metrics, validate_data
except ImportError:
    from .data_processor import calculate_metrics, validate_data

try:
    from decision_engine import triage_keyword
except ImportError:
    from .decision_engine import triage_keyword

try:
    from risk_guard import evaluate_risk
except ImportError:
    from .risk_guard import evaluate_risk

app = FastAPI(
    title="QueryPilotAI API",
    description="Search Term Triage Engine & Risk Guard Platform",
    version="1.0.0",
)

# Enable CORS for Vite frontend and localhost access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory storage for active dataset
CURRENT_DATASET: Optional[pd.DataFrame] = None
DATASET_METADATA: Dict[str, Any] = {
    "filename": "triaged_search_terms.csv",
    "total_rows": 0,
    "last_updated": None,
    "is_loaded": False,
}
REVIEWS_STORE: List[Dict[str, Any]] = []


COLUMN_ALIASES = {
    "search_term": ["search_term", "search term", "term", "query", "keyword"],
    "match_type": ["match_type", "match type", "match"],
    "campaign": ["campaign", "campaign_name", "campaign name"],
    "ad_group": ["ad_group", "ad group", "adgroup", "ad_group_name"],
    "impressions": ["impressions", "impression", "impr"],
    "clicks": ["clicks", "click"],
    "cost": ["cost", "spend", "total_cost", "total cost"],
    "conversions": ["conversions", "conversion", "conv"],
    "conversion_value": ["conversion_value", "conversion value", "revenue", "conv_value", "total_value"],
}


def normalize_incoming_df(df: pd.DataFrame) -> pd.DataFrame:
    """Standardize column names using alias map and fill missing defaults."""
    df = df.copy()
    lower_cols = {col.lower().strip(): col for col in df.columns}

    rename_map = {}
    for target, aliases in COLUMN_ALIASES.items():
        if target in df.columns:
            continue
        for alias in aliases:
            if alias.lower() in lower_cols:
                rename_map[lower_cols[alias.lower()]] = target
                break

    if rename_map:
        df = df.rename(columns=rename_map)

    # Supply default columns if completely missing
    if "search_term" not in df.columns:
        first_str_col = None
        for col in df.columns:
            if df[col].dtype == object or str(df[col].dtype).startswith("str"):
                first_str_col = col
                break
        if first_str_col:
            df["search_term"] = df[first_str_col]
        else:
            df["search_term"] = [f"Term {i+1}" for i in range(len(df))]

    if "row_id" not in df.columns:
        df["row_id"] = range(1, len(df) + 1)
    if "match_type" not in df.columns:
        df["match_type"] = "broad"
    if "campaign" not in df.columns:
        df["campaign"] = "Default Campaign"
    if "ad_group" not in df.columns:
        df["ad_group"] = "Default Ad Group"
    if "impressions" not in df.columns:
        df["impressions"] = df.get("clicks", 0) * 10
    if "clicks" not in df.columns:
        df["clicks"] = 0
    if "cost" not in df.columns:
        df["cost"] = 0.0
    if "conversions" not in df.columns:
        df["conversions"] = 0
    if "conversion_value" not in df.columns:
        df["conversion_value"] = 0.0

    return df


def process_and_enrich_dataset(df: pd.DataFrame) -> pd.DataFrame:
    """Run full pipeline: normalization -> validation -> metrics -> decision -> risk guard."""
    df = normalize_incoming_df(df)

    # 1. Validation via data_processor
    try:
        df = validate_data(df)
    except Exception as e:
        df["is_valid"] = True
        df["validation_issues"] = f"Validation warning: {e}"

    # 2. Performance metrics calculation
    df = calculate_metrics(df)

    # 3. Decision Engine & Risk Guard evaluation per row
    rows = df.to_dict(orient="records")
    decisions = []
    for r in rows:
        dec = triage_keyword(r)
        guarded = evaluate_risk(r, decision=dec)
        decisions.append(guarded)

    # Append results
    df["triage_decision"] = [d.get("decision", "HUMAN REVIEW") for d in decisions]
    df["triage_risk_level"] = [d.get("risk_level", "MEDIUM") for d in decisions]
    df["triage_reason"] = [d.get("reason", "") for d in decisions]
    df["triage_risk_score"] = [d.get("risk_score", 50) for d in decisions]
    df["triage_suggested_action"] = [d.get("suggested_action", "") for d in decisions]
    df["triage_evidence"] = [d.get("evidence", []) for d in decisions]
    df["triage_needs_review"] = [bool(d.get("needs_review", False)) for d in decisions]
    df["guard_risk_level"] = [d.get("guard_risk_level", "LOW") for d in decisions]
    df["risk_flags"] = [d.get("risk_flags", []) for d in decisions]
    df["warnings"] = [d.get("warnings", []) for d in decisions]
    df["negative_keyword_blocked"] = [bool(d.get("negative_keyword_blocked", False)) for d in decisions]
    df["confidence_score"] = [d.get("confidence_score", 65) for d in decisions]
    df["confidence_level"] = [d.get("confidence_level", "MEDIUM") for d in decisions]
    df["human_explanation"] = [d.get("human_explanation", "") for d in decisions]

    return df


def load_initial_dataset():
    """Load default triaged or processed search terms on application startup."""
    global CURRENT_DATASET, DATASET_METADATA

    base_dirs = [
        Path(__file__).resolve().parent,
        Path(__file__).resolve().parent.parent,
    ]

    candidate_files = [
        "triaged_search_terms.csv",
        "processed_search_terms.csv",
    ]

    for b in base_dirs:
        for c in candidate_files:
            p = b / c
            if p.exists():
                try:
                    df = pd.read_csv(p)
                    # If it doesn't already have guard flags or confidence, enrich it
                    if "guard_risk_level" not in df.columns or "confidence_score" not in df.columns:
                        df = process_and_enrich_dataset(df)

                    CURRENT_DATASET = df
                    DATASET_METADATA = {
                        "filename": p.name,
                        "total_rows": len(df),
                        "last_updated": pd.Timestamp.now().isoformat(),
                        "is_loaded": True,
                    }
                    print(f"Loaded initial dataset {p.name} ({len(df):,} rows)")
                    return
                except Exception as e:
                    print(f"Failed loading candidate {p}: {e}")

    # Fallback to demo DataFrame
    demo_df = pd.DataFrame([
        {
            "row_id": 1,
            "search_term": "instant business loan online",
            "match_type": "exact",
            "campaign": "High Intent",
            "ad_group": "Fast Approval",
            "impressions": 1200,
            "clicks": 140,
            "cost": 1250.0,
            "conversions": 18,
            "conversion_value": 4500.0,
        },
        {
            "row_id": 2,
            "search_term": "free small business advice forum",
            "match_type": "broad",
            "campaign": "Growth - Search",
            "ad_group": "Advice",
            "impressions": 850,
            "clicks": 95,
            "cost": 1150.0,
            "conversions": 0,
            "conversion_value": 0.0,
        },
        {
            "row_id": 3,
            "search_term": "best commercial loan rates 2026",
            "match_type": "phrase",
            "campaign": "Working Capital",
            "ad_group": "Commercial",
            "impressions": 400,
            "clicks": 12,
            "cost": 85.0,
            "conversions": 1,
            "conversion_value": 300.0,
        },
    ])
    CURRENT_DATASET = process_and_enrich_dataset(demo_df)
    DATASET_METADATA = {
        "filename": "demo_seed.csv",
        "total_rows": len(demo_df),
        "last_updated": pd.Timestamp.now().isoformat(),
        "is_loaded": True,
    }


# Load on module import
load_initial_dataset()


def sanitize_val(val: Any) -> Any:
    """Make numpy/pandas values JSON serializable."""
    if val is None or (isinstance(val, float) and (math.isnan(val) or not math.isfinite(val))):
        return None
    if isinstance(val, (np.integer, int)):
        return int(val)
    if isinstance(val, (np.floating, float)):
        return round(float(val), 4)
    if isinstance(val, (np.bool_, bool)):
        return bool(val)
    if isinstance(val, (list, tuple)):
        return [sanitize_val(x) for x in val]
    if isinstance(val, dict):
        return {k: sanitize_val(v) for k, v in val.items()}
    return val


def compute_statistics(df: pd.DataFrame) -> Dict[str, Any]:
    """Compute complete analytical KPIs, distributions, and summary views."""
    total_rows = len(df)
    if total_rows == 0:
        return {
            "total_rows": 0,
            "total_spend": 0,
            "total_clicks": 0,
            "total_impressions": 0,
            "total_conversions": 0,
            "total_revenue": 0,
            "overall_ctr": 0,
            "overall_cvr": 0,
            "overall_cpa": 0,
            "overall_roas": 0,
            "decisions": {},
            "risk_levels": {},
            "campaigns": [],
            "match_types": [],
            "waste_candidates_count": 0,
            "growth_opportunities_count": 0,
            "human_review_count": 0,
            "data_health": {},
        }

    cost_col = df["cost"].fillna(0)
    clicks_col = df["clicks"].fillna(0)
    impr_col = df["impressions"].fillna(0)
    conv_col = df["conversions"].fillna(0)
    val_col = df["conversion_value"].fillna(0)

    total_cost = float(cost_col.sum())
    total_clicks = int(clicks_col.sum())
    total_impressions = int(impr_col.sum())
    total_conversions = float(conv_col.sum())
    total_revenue = float(val_col.sum())

    overall_ctr = round((total_clicks / total_impressions * 100), 2) if total_impressions > 0 else 0.0
    overall_cvr = round((total_conversions / total_clicks * 100), 2) if total_clicks > 0 else 0.0
    overall_cpa = round((total_cost / total_conversions), 2) if total_conversions > 0 else 0.0
    overall_roas = round((total_revenue / total_cost), 2) if total_cost > 0 else 0.0

    # Decision distribution
    decision_col = df.get("triage_decision", pd.Series(["HUMAN REVIEW"] * total_rows))
    decision_counts = decision_col.value_counts().to_dict()

    # Risk level distribution
    risk_col = df.get("triage_risk_level", pd.Series(["MEDIUM"] * total_rows))
    risk_counts = risk_col.value_counts().to_dict()

    # Guard risk level distribution
    guard_risk_col = df.get("guard_risk_level", pd.Series(["LOW"] * total_rows))
    guard_counts = guard_risk_col.value_counts().to_dict()

    # Campaign performance
    campaign_grp = df.groupby("campaign").agg(
        spend=("cost", "sum"),
        clicks=("clicks", "sum"),
        conversions=("conversions", "sum"),
        revenue=("conversion_value", "sum"),
        terms_count=("search_term", "count"),
    ).reset_index()

    campaigns_list = []
    for _, r in campaign_grp.iterrows():
        c_spend = float(r["spend"])
        c_conv = float(r["conversions"])
        campaigns_list.append({
            "name": str(r["campaign"]),
            "spend": round(c_spend, 2),
            "clicks": int(r["clicks"]),
            "conversions": int(c_conv),
            "revenue": round(float(r["revenue"]), 2),
            "roas": round(float(r["revenue"]) / c_spend, 2) if c_spend > 0 else 0.0,
            "cpa": round(c_spend / c_conv, 2) if c_conv > 0 else 0.0,
            "terms_count": int(r["terms_count"]),
        })

    # Match type performance
    match_grp = df.groupby("match_type").agg(
        spend=("cost", "sum"),
        clicks=("clicks", "sum"),
        conversions=("conversions", "sum"),
        terms_count=("search_term", "count"),
    ).reset_index()

    match_types_list = []
    for _, r in match_grp.iterrows():
        m_spend = float(r["spend"])
        m_conv = float(r["conversions"])
        match_types_list.append({
            "name": str(r["match_type"]).capitalize(),
            "spend": round(m_spend, 2),
            "clicks": int(r["clicks"]),
            "conversions": int(m_conv),
            "terms_count": int(r["terms_count"]),
        })

    # Waste candidates (spend > 1000 and conversions == 0 or spend > 50 in risk guard)
    waste_mask = (conv_col == 0) & (cost_col > 500)
    waste_count = int(waste_mask.sum())

    # Growth candidates (conversions >= 5 or revenue > spend * 2)
    growth_mask = conv_col >= 5
    growth_count = int(growth_mask.sum())

    # Human review candidates
    needs_review_col = df.get("triage_needs_review", pd.Series([False] * total_rows))
    human_review_count = int((decision_col == "HUMAN REVIEW").sum()) or int(needs_review_col.sum())

    # Data health stats
    valid_col = df.get("is_valid", pd.Series([True] * total_rows))
    valid_count = int(valid_col.sum())
    invalid_count = total_rows - valid_count

    return {
        "total_rows": total_rows,
        "valid_rows": valid_count,
        "invalid_rows": invalid_count,
        "total_spend": round(total_cost, 2),
        "total_clicks": total_clicks,
        "total_impressions": total_impressions,
        "total_conversions": int(total_conversions),
        "total_revenue": round(total_revenue, 2),
        "overall_ctr": overall_ctr,
        "overall_cvr": overall_cvr,
        "overall_cpa": overall_cpa,
        "overall_roas": overall_roas,
        "decisions": decision_counts,
        "risk_levels": risk_counts,
        "guard_risk_levels": guard_counts,
        "campaigns": campaigns_list,
        "match_types": match_types_list,
        "waste_candidates_count": waste_count,
        "growth_opportunities_count": growth_count,
        "human_review_count": human_review_count,
        "data_health": {
            "total": total_rows,
            "valid": valid_count,
            "with_issues": invalid_count,
            "unique_campaigns": int(df["campaign"].nunique()),
            "unique_terms": int(df["search_term"].nunique()),
        },
    }


# Models
class SingleTriageRequest(BaseModel):
    search_term: str = "example business loan query"
    clicks: float = 40.0
    impressions: float = 500.0
    cost: float = 120.0
    conversions: float = 3.0
    conversion_value: float = 350.0
    campaign: Optional[str] = "Growth - Search"
    match_type: Optional[str] = "phrase"
    relevance_score: Optional[float] = None
    proposed_negative_keyword: bool = False


class ReviewActionRequest(BaseModel):
    row_id: int
    decision: str
    note: str
    analyst: Optional[str] = "Analyst"


# Endpoints
@app.get("/api/health")
def health():
    return {
        "status": "healthy",
        "service": "QueryPilotAI Triage & Decision Engine",
        "dataset_metadata": DATASET_METADATA,
    }


@app.get("/api/stats")
def get_stats():
    """Return top-level KPIs, distributions, and summary aggregations."""
    global CURRENT_DATASET
    if CURRENT_DATASET is None:
        raise HTTPException(status_code=404, detail="No dataset loaded")
    return compute_statistics(CURRENT_DATASET)


@app.get("/api/data")
def get_data(
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=1000),
    search: Optional[str] = None,
    decision: Optional[str] = None,
    campaign: Optional[str] = None,
    match_type: Optional[str] = None,
    risk_level: Optional[str] = None,
    needs_review: Optional[bool] = None,
    view: Optional[str] = None,  # 'waste', 'growth', 'review'
    sort_by: Optional[str] = None,
    sort_order: str = Query("desc", pattern="^(asc|desc)$"),
):
    """Retrieve filtered, searched, and paginated records."""
    global CURRENT_DATASET
    if CURRENT_DATASET is None:
        raise HTTPException(status_code=404, detail="No dataset loaded")

    df = CURRENT_DATASET

    # Apply special views
    if view == "waste":
        df = df[(df["conversions"] == 0) & (df["cost"] > 500)]
    elif view == "growth":
        df = df[df["conversions"] >= 5]
    elif view == "review":
        df = df[(df["triage_decision"] == "HUMAN REVIEW") | (df.get("triage_needs_review", False))]

    # Filters
    if search:
        s = search.lower().strip()
        df = df[
            df["search_term"].astype(str).str.lower().str.contains(s, na=False)
            | df["campaign"].astype(str).str.lower().str.contains(s, na=False)
        ]

    if decision and decision not in ("All decisions", "All"):
        df = df[df["triage_decision"].astype(str).str.upper() == decision.upper()]

    if campaign and campaign not in ("All campaigns", "All"):
        df = df[df["campaign"].astype(str) == campaign]

    if match_type and match_type not in ("All match types", "All"):
        df = df[df["match_type"].astype(str).str.lower() == match_type.lower()]

    if risk_level and risk_level not in ("All risk levels", "All"):
        df = df[df["triage_risk_level"].astype(str).str.upper() == risk_level.upper()]

    if needs_review is not None:
        df = df[df["triage_needs_review"] == needs_review]

    # Sorting
    if sort_by and sort_by in df.columns:
        ascending = sort_order == "asc"
        df = df.sort_values(by=sort_by, ascending=ascending)
    else:
        # Default order: cost desc
        if "cost" in df.columns:
            df = df.sort_values(by="cost", ascending=False)

    total_filtered = len(df)
    start_idx = (page - 1) * page_size
    end_idx = start_idx + page_size

    page_df = df.iloc[start_idx:end_idx]

    records = []
    for r in page_df.to_dict(orient="records"):
        # Format record cleanly for the frontend
        rec = {
            "id": sanitize_val(r.get("row_id", 0)),
            "term": sanitize_val(r.get("search_term", "")),
            "campaign": sanitize_val(r.get("campaign", "")),
            "ad_group": sanitize_val(r.get("ad_group", "")),
            "match": str(r.get("match_type", "unknown")).capitalize(),
            "clicks": sanitize_val(r.get("clicks", 0)),
            "impressions": sanitize_val(r.get("impressions", 0)),
            "cost": sanitize_val(r.get("cost", 0.0)),
            "conversions": sanitize_val(r.get("conversions", 0)),
            "conversion_value": sanitize_val(r.get("conversion_value", 0.0)),
            "ctr": sanitize_val(r.get("ctr", 0.0)),
            "conversion_rate": sanitize_val(r.get("conversion_rate", 0.0)),
            "cpa": sanitize_val(r.get("cpa", 0.0)),
            "roas": sanitize_val(r.get("roas", 0.0)),
            "decision": sanitize_val(r.get("triage_decision", "HUMAN REVIEW")),
            "risk_level": sanitize_val(r.get("triage_risk_level", "MEDIUM")),
            "guard_risk_level": sanitize_val(r.get("guard_risk_level", "LOW")),
            "risk_score": sanitize_val(r.get("triage_risk_score", 50)),
            "confidence_score": sanitize_val(r.get("confidence_score", 65)),
            "confidence_level": sanitize_val(r.get("confidence_level", "MEDIUM")),
            "reason": sanitize_val(r.get("triage_reason", "")),
            "suggested_action": sanitize_val(r.get("triage_suggested_action", "")),
            "human_explanation": sanitize_val(r.get("human_explanation", "")),
            "needs_review": sanitize_val(r.get("triage_needs_review", False)),
            "risk_flags": sanitize_val(r.get("risk_flags", [])),
            "warnings": sanitize_val(r.get("warnings", [])),
            "evidence": sanitize_val(r.get("triage_evidence", [])),
            "is_valid": sanitize_val(r.get("is_valid", True)),
            "validation_issues": sanitize_val(r.get("validation_issues", "")),
        }
        records.append(rec)

    return {
        "page": page,
        "page_size": page_size,
        "total": total_filtered,
        "total_pages": math.ceil(total_filtered / page_size) if total_filtered > 0 else 1,
        "records": records,
    }


@app.post("/api/upload")
async def upload_dataset(file: UploadFile = File(...)):
    """Upload a new CSV dataset. Runs full pipeline and refreshes dashboard immediately."""
    global CURRENT_DATASET, DATASET_METADATA

    if not file.filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only CSV files are supported.")

    try:
        content = await file.read()
        # Handle UTF-8 with BOM or fallback encoding
        try:
            text = content.decode("utf-8-sig")
        except UnicodeDecodeError:
            text = content.decode("latin-1")

        raw_df = pd.read_csv(io.StringIO(text))
        if raw_df.empty:
            raise HTTPException(status_code=400, detail="Uploaded CSV file is empty.")

        # Process and enrich
        processed_df = process_and_enrich_dataset(raw_df)

        CURRENT_DATASET = processed_df
        DATASET_METADATA = {
            "filename": file.filename,
            "total_rows": len(processed_df),
            "last_updated": pd.Timestamp.now().isoformat(),
            "is_loaded": True,
        }

        # Save snapshot
        save_path = Path(__file__).resolve().parent / "uploaded_dataset_triaged.csv"
        processed_df.to_csv(save_path, index=False)

        stats = compute_statistics(processed_df)
        return {
            "success": True,
            "message": f"Dataset '{file.filename}' with {len(processed_df):,} rows processed successfully through Triage & Risk Guard.",
            "metadata": DATASET_METADATA,
            "stats": stats,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to process dataset: {str(e)}")


@app.post("/api/triage/single")
def triage_single(req: SingleTriageRequest):
    """Real-time single search term evaluation through Decision Engine & Risk Guard."""
    row = {
        "search_term": req.search_term,
        "clicks": req.clicks,
        "impressions": req.impressions,
        "cost": req.cost,
        "conversions": req.conversions,
        "conversion_value": req.conversion_value,
        "campaign": req.campaign,
        "match_type": req.match_type,
        "relevance_score": req.relevance_score,
        "is_valid": True,
    }

    # Calculate metrics
    ctr = (req.clicks / req.impressions * 100) if req.impressions > 0 else 0.0
    cvr = (req.conversions / req.clicks * 100) if req.clicks > 0 else 0.0
    cpa = (req.cost / req.conversions) if req.conversions > 0 else 0.0
    roas = (req.conversion_value / req.cost) if req.cost > 0 else 0.0

    # Decision & Risk Guard
    dec = triage_keyword(row)
    result = evaluate_risk(row, decision=dec, proposed_negative_keyword=req.proposed_negative_keyword)

    result["ctr"] = round(ctr, 2)
    result["conversion_rate"] = round(cvr, 2)
    result["cpa"] = round(cpa, 2)
    result["roas"] = round(roas, 2)

    return sanitize_val(result)


@app.post("/api/review")
def record_review(action: ReviewActionRequest):
    """Save an analyst review decision and update the active dataset in-memory."""
    global CURRENT_DATASET, REVIEWS_STORE

    entry = {
        "id": len(REVIEWS_STORE) + 1,
        "row_id": action.row_id,
        "decision": action.decision,
        "note": action.note,
        "analyst": action.analyst,
        "timestamp": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    REVIEWS_STORE.insert(0, entry)

    if CURRENT_DATASET is not None:
        mask = CURRENT_DATASET["row_id"] == action.row_id
        if mask.any():
            CURRENT_DATASET.loc[mask, "triage_decision"] = action.decision
            CURRENT_DATASET.loc[mask, "triage_needs_review"] = False
            CURRENT_DATASET.loc[mask, "triage_reason"] = f"Manual override: {action.note}"

    return {"success": True, "review": entry}


@app.get("/api/reviews")
def get_reviews():
    """Retrieve saved reviews from current session."""
    return {"reviews": REVIEWS_STORE}


@app.get("/api/export")
def export_dataset(
    view: Optional[str] = None,
    decision: Optional[str] = None,
):
    """Export current processed dataset or filtered slice to CSV."""
    global CURRENT_DATASET
    if CURRENT_DATASET is None:
        raise HTTPException(status_code=404, detail="No dataset loaded")

    df = CURRENT_DATASET.copy()
    if view == "waste":
        df = df[(df["conversions"] == 0) & (df["cost"] > 500)]
    elif view == "growth":
        df = df[df["conversions"] >= 5]
    elif view == "review":
        df = df[(df["triage_decision"] == "HUMAN REVIEW") | (df.get("triage_needs_review", False))]

    if decision and decision not in ("All decisions", "All"):
        df = df[df["triage_decision"].astype(str).str.upper() == decision.upper()]

    stream = io.StringIO()
    df.to_csv(stream, index=False)
    stream.seek(0)

    filename = f"querypilot_export_{view or 'all'}.csv"
    return StreamingResponse(
        iter([stream.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


# Mount built frontend dist files if available for all-in-one execution
dist_dir = Path(__file__).resolve().parent.parent / "frontend" / "dist"
if dist_dir.exists():
    from fastapi.staticfiles import StaticFiles
    app.mount("/", StaticFiles(directory=str(dist_dir), html=True), name="frontend")
