"""QueryPilotAI - Risk Guard Module.

Provides safety checks and guardrails on top of triage decisions.
Ensures high-spend terms without conversions are flagged, insufficient data is caught,
valuable terms are not accidentally blocked as negative keywords, and missing/invalid
metrics are surfaced for human review.
"""

from __future__ import annotations

import math
from typing import Any, Mapping, Sequence


def _parse_float(val: Any) -> float | None:
    if val is None:
        return None
    try:
        num = float(val)
        if math.isnan(num) or not math.isfinite(num):
            return None
        return num
    except (TypeError, ValueError):
        return None


def evaluate_risk(
    row: Mapping[str, Any],
    decision: Mapping[str, Any] | None = None,
    proposed_negative_keyword: bool = False,
    min_clicks_for_evidence: int = 20,
    high_spend_threshold: float = 50.0,
) -> dict[str, Any]:
    """Evaluate risk guardrails for a search term and its decision.

    Parameters
    ----------
    row : Mapping[str, Any]
        Dictionary of keyword metrics (clicks, cost/spend, conversions, conversion_value, etc.).
    decision : Mapping[str, Any] | None
        Existing triage decision from triage_engine/decision_engine, if available.
    proposed_negative_keyword : bool
        Whether the user/system is proposing to add this term as a negative keyword.
    min_clicks_for_evidence : int
        Minimum clicks to consider evidence sufficient.
    high_spend_threshold : float
        Cost/spend threshold above which 0-conversion terms are flagged as high risk.

    Returns
    -------
    dict[str, Any]
        Merged decision dictionary with safety guard fields added.
    """
    if not isinstance(row, Mapping):
        row = {}

    clicks_raw = row.get("clicks")
    cost_raw = row.get("cost", row.get("spend"))
    conversions_raw = row.get("conversions")
    conv_val_raw = row.get("conversion_value", row.get("revenue"))

    clicks = _parse_float(clicks_raw)
    cost = _parse_float(cost_raw)
    conversions = _parse_float(conversions_raw)
    conv_val = _parse_float(conv_val_raw)

    risk_flags: list[str] = []
    warnings: list[str] = []
    negative_keyword_blocked: bool = False

    # 1. Missing or NaN metrics check
    # Check if critical metrics are None or were unparseable/NaN
    def _is_missing_or_nan(raw_val: Any) -> bool:
        if raw_val is None:
            return True
        try:
            num = float(raw_val)
            return math.isnan(num) or not math.isfinite(num)
        except (TypeError, ValueError):
            return True

    if _is_missing_or_nan(clicks_raw) or _is_missing_or_nan(cost_raw) or _is_missing_or_nan(conversions_raw):
        risk_flags.append("MISSING_METRICS")
        warnings.append("One or more required metrics (clicks, cost, conversions) are missing or non-numeric.")

    # 2. Insufficient evidence (low clicks)
    if clicks is not None and clicks < min_clicks_for_evidence:
        risk_flags.append("INSUFFICIENT_EVIDENCE")
        warnings.append(f"Clicks ({clicks:g}) below threshold ({min_clicks_for_evidence}) for reliable evaluation.")

    # 3. High spend with zero conversions
    if conversions is not None and conversions == 0 and cost is not None and cost >= high_spend_threshold:
        risk_flags.append("HIGH_SPEND_ZERO_CONVERSIONS")
        warnings.append(f"Significant spend ({cost:.2f}) observed with 0 conversions.")

    # 4. Potentially valuable term protected from negative keyword
    if proposed_negative_keyword:
        is_valuable = False
        if conversions is not None and conversions > 0:
            is_valuable = True
        elif conv_val is not None and cost is not None and conv_val > cost:
            is_valuable = True

        if is_valuable:
            risk_flags.append("POTENTIALLY_VALUABLE_NEGATIVE_KEYWORD")
            negative_keyword_blocked = True
            warnings.append("Term generated conversions or value; blocked from being added as negative keyword.")

    # Base decision fields
    base_decision = str(decision.get("decision", "HUMAN REVIEW")) if decision else "HUMAN REVIEW"
    base_risk_level = str(decision.get("risk_level", "MEDIUM")) if decision else "MEDIUM"
    base_reason = str(decision.get("reason", "Evaluated by risk guard.")) if decision else "Evaluated by risk guard."
    base_risk_score = int(decision.get("risk_score", 50)) if decision else 50
    base_suggested_action = str(decision.get("suggested_action", "Review term metrics.")) if decision else "Review term metrics."
    base_needs_review = bool(decision.get("needs_review", False)) if decision else False

    # Determine guard risk level
    if "HIGH_SPEND_ZERO_CONVERSIONS" in risk_flags or "MISSING_METRICS" in risk_flags or "POTENTIALLY_VALUABLE_NEGATIVE_KEYWORD" in risk_flags:
        guard_risk_level = "HIGH"
    elif "INSUFFICIENT_EVIDENCE" in risk_flags:
        guard_risk_level = "MEDIUM"
    else:
        guard_risk_level = "LOW"

    # If decision had higher risk, preserve it
    risk_rank = {"LOW": 1, "MEDIUM": 2, "HIGH": 3}
    final_risk_level = base_risk_level
    if risk_rank.get(guard_risk_level, 0) > risk_rank.get(base_risk_level, 0):
        final_risk_level = guard_risk_level

    # Needs review if guard raised flags or base decision requested review
    final_needs_review = base_needs_review or len(risk_flags) > 0 or base_risk_score >= 70

    # Risk score calculation adjustment
    final_risk_score = base_risk_score
    if "HIGH_SPEND_ZERO_CONVERSIONS" in risk_flags:
        final_risk_score = max(final_risk_score, 85)
    elif "MISSING_METRICS" in risk_flags:
        final_risk_score = max(final_risk_score, 75)
    elif "INSUFFICIENT_EVIDENCE" in risk_flags:
        final_risk_score = max(final_risk_score, 55)

    result: dict[str, Any] = {
        "decision": base_decision,
        "risk_level": final_risk_level,
        "reason": base_reason,
        "risk_score": final_risk_score,
        "suggested_action": base_suggested_action,
        "needs_review": final_needs_review,
        "guard_risk_level": guard_risk_level,
        "risk_flags": risk_flags,
        "warnings": warnings,
        "negative_keyword_blocked": negative_keyword_blocked,
    }

    # Pass through other metadata from decision if present
    if decision:
        for k, v in decision.items():
            if k not in result:
                result[k] = v

    return result
