import React, { useEffect, useState } from 'react';
import { BarChart2, ShieldCheck, CheckCircle2, Play, CheckCircle, XCircle } from 'lucide-react';
import { runAutomatedTestSuite, TestResult } from '../utils/testSuite';

export const BenchmarksView: React.FC = () => {
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [running, setRunning] = useState(false);

  const runTests = () => {
    setRunning(true);
    setTimeout(() => {
      const results = runAutomatedTestSuite();
      setTestResults(results);
      setRunning(false);
    }, 400);
  };

  useEffect(() => {
    runTests();
  }, []);

  return (
    <div className="space-y-6 pb-12">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Automated Test Suite & Engine Evaluation</h2>
          <p className="text-sm text-slate-500">Executing independent unit validations for metric reconciliation, zero-denominator safety, and rule logic.</p>
        </div>
        <button
          onClick={runTests}
          disabled={running}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs rounded-xl shadow-md transition-all flex items-center gap-2"
        >
          <Play className={`h-4 w-4 ${running ? 'animate-spin' : ''}`} />
          <span>{running ? 'Running Tests...' : 'Run Automated Tests'}</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-sm">Test Execution Results</h3>
          <span className="text-xs font-semibold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-full">
            {testResults.filter(r => r.passed).length} / {testResults.length} Tests Passed
          </span>
        </div>
        <div className="divide-y divide-slate-100">
          {testResults.map((res, idx) => (
            <div key={idx} className="p-4 flex items-center justify-between hover:bg-slate-50/80">
              <div className="flex items-center gap-3">
                {res.passed ? (
                  <CheckCircle className="h-5 w-5 text-emerald-600 shrink-0" />
                ) : (
                  <XCircle className="h-5 w-5 text-red-600 shrink-0" />
                )}
                <div>
                  <h4 className="text-xs font-bold text-slate-900">{res.testName}</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">{res.message}</p>
                </div>
              </div>
              <span className={`px-2.5 py-1 rounded text-[10px] font-bold ${res.passed ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}>
                {res.passed ? 'PASS' : 'FAIL'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
