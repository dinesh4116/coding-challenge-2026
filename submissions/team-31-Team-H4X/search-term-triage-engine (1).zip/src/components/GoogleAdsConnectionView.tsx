import React, { useState, useEffect } from 'react';
import { fetchGoogleAdsStatus, fetchGoogleAdsAccounts, fetchOAuthUrl, disconnectGoogleAds } from '../utils/triageClient';
import { Globe, CheckCircle2, AlertCircle, RefreshCw, LogOut, ShieldCheck, Sparkles, Upload } from 'lucide-react';

interface GoogleAdsConnectionViewProps {
  onSyncLive: (terms: any[]) => void;
  onNavigate: (tab: string) => void;
  onLoadDemo: () => void;
}

export const GoogleAdsConnectionView: React.FC<GoogleAdsConnectionViewProps> = ({ onSyncLive, onNavigate, onLoadDemo }) => {
  const [status, setStatus] = useState<any>(null);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const loadStatus = async () => {
    setLoading(true);
    setErrorMessage(null);
    const data = await fetchGoogleAdsStatus();
    setStatus(data);
    if (data.error) {
      setErrorMessage(data.error);
    }
    if (data.connected) {
      const accs = await fetchGoogleAdsAccounts();
      setAccounts(accs);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadStatus();
    const params = new URLSearchParams(window.location.search);
    const oauthError = params.get('oauth_error');
    if (oauthError) {
      setErrorMessage(`OAuth Authorization Error: ${decodeURIComponent(oauthError)}`);
    }
  }, []);

  const handleConnect = async () => {
    setConnecting(true);
    setErrorMessage(null);
    const result = await fetchOAuthUrl();
    setConnecting(false);

    if (result.error) {
      setErrorMessage(result.error);
    } else if (result.authUrl) {
      window.location.href = result.authUrl;
    } else {
      setErrorMessage('Failed to initiate OAuth flow. Please check server logs and environment variables.');
    }
  };

  const handleDisconnect = async () => {
    await disconnectGoogleAds();
    loadStatus();
  };

  const handleSyncTerms = async () => {
    setSyncing(true);
    try {
      const res = await fetch('/api/google-ads/search-terms');
      const data = await res.json();
      if (!res.ok) {
        setErrorMessage(data.error || 'Failed to fetch live search terms report.');
        return;
      }
      if (data && data.searchTerms) {
        onSyncLive(data.searchTerms);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to connect to Google Ads API endpoint.');
    } finally {
      setSyncing(false);
    }
  };

  if (!status) {
    return <div className="p-8 text-center text-slate-500">Checking Google Ads API connection status...</div>;
  }

  const callbackPath = '/auth/google/callback';

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <Globe className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">Google Ads API & OAuth 2.0 Integration</h2>
            <p className="text-sm text-slate-500">Connect securely via OAuth 2.0 to retrieve search term performance reports.</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onLoadDemo}
            className="px-4 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold text-xs rounded-xl transition-all flex items-center gap-1.5"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>Continue with Demo</span>
          </button>
          <button
            onClick={() => onNavigate('import')}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition-all flex items-center gap-1.5"
          >
            <Upload className="h-3.5 w-3.5" />
            <span>Upload CSV</span>
          </button>
        </div>
      </div>

      {errorMessage && (
        <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 flex items-start gap-3 text-amber-800 text-sm">
          <AlertCircle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-bold">Google Ads Configuration Notice (Optional Integration)</p>
            <p>{errorMessage}</p>
            <p className="text-xs text-amber-700 pt-1">
              Note: Demo Mode and CSV dataset uploads remain fully functional and unblocked while Google Ads credentials are unconfigured.
            </p>
          </div>
        </div>
      )}

      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <div className="flex items-center justify-between p-4 rounded-xl bg-slate-50 border border-slate-200">
          <div className="flex items-center gap-3">
            <div className={`h-3 w-3 rounded-full ${status.connected ? 'bg-emerald-500 animate-pulse' : 'bg-slate-300'}`}></div>
            <div>
              <p className="text-sm font-bold text-slate-900">
                Status: {status.connected ? 'Connected to Google Ads API' : 'Not Connected'}
              </p>
              <p className="text-xs text-slate-500">OAuth 2.0 Web Client & Developer Token verification</p>
            </div>
          </div>
          {status.connected ? (
            <button
              onClick={handleDisconnect}
              className="px-4 py-2 bg-red-50 hover:bg-red-100 text-red-600 font-semibold text-xs rounded-xl transition-all flex items-center gap-1.5"
            >
              <LogOut className="h-4 w-4" />
              <span>Disconnect</span>
            </button>
          ) : (
            <button
              onClick={handleConnect}
              disabled={connecting}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 disabled:opacity-50"
            >
              {connecting ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Globe className="h-4 w-4" />}
              <span>{connecting ? 'Connecting...' : 'Connect Google Ads Account'}</span>
            </button>
          )}
        </div>

        {/* Credentials Checklist */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">Environment & API Credentials Checklist</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className={`p-4 rounded-xl border flex items-center gap-3 ${status.clientIdConfigured ? 'bg-emerald-50/50 border-emerald-200 text-emerald-800' : 'bg-slate-50 border-slate-200 text-slate-600'}`}>
              <CheckCircle2 className={`h-5 w-5 ${status.clientIdConfigured ? 'text-emerald-600' : 'text-slate-400'}`} />
              <div>
                <p className="text-xs font-bold">Client ID</p>
                <p className="text-[10px] opacity-80">{status.clientIdConfigured ? 'Configured in env' : 'Missing GOOGLE_ADS_CLIENT_ID'}</p>
              </div>
            </div>

            <div className={`p-4 rounded-xl border flex items-center gap-3 ${status.clientSecretConfigured ? 'bg-emerald-50/50 border-emerald-200 text-emerald-800' : 'bg-slate-50 border-slate-200 text-slate-600'}`}>
              <CheckCircle2 className={`h-5 w-5 ${status.clientSecretConfigured ? 'text-emerald-600' : 'text-slate-400'}`} />
              <div>
                <p className="text-xs font-bold">Client Secret</p>
                <p className="text-[10px] opacity-80">{status.clientSecretConfigured ? 'Configured in env' : 'Missing GOOGLE_ADS_CLIENT_SECRET'}</p>
              </div>
            </div>

            <div className={`p-4 rounded-xl border flex items-center gap-3 ${status.developerTokenConfigured ? 'bg-emerald-50/50 border-emerald-200 text-emerald-800' : 'bg-slate-50 border-slate-200 text-slate-600'}`}>
              <CheckCircle2 className={`h-5 w-5 ${status.developerTokenConfigured ? 'text-emerald-600' : 'text-slate-400'}`} />
              <div>
                <p className="text-xs font-bold">Developer Token</p>
                <p className="text-[10px] opacity-80">{status.developerTokenConfigured ? 'Configured in env' : 'Missing GOOGLE_ADS_DEVELOPER_TOKEN'}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Setup Instructions */}
        <div className="p-5 rounded-xl bg-blue-50/60 border border-blue-100 space-y-3">
          <h4 className="text-xs font-bold text-blue-900 uppercase tracking-wider flex items-center gap-1.5">
            <ShieldCheck className="h-4 w-4 text-blue-600" />
            <span>Google Cloud Console Setup Instructions</span>
          </h4>
          <p className="text-xs text-slate-700 leading-relaxed">
            To enable live Google Ads API connection, you must configure the following OAuth 2.0 redirect URI in your Google Cloud Console project:
          </p>
          <div className="p-3 rounded-lg bg-white border border-blue-200 font-mono text-xs text-blue-900 select-all">
            {window.location.origin}{callbackPath}
          </div>
          <p className="text-[11px] text-slate-500">
            Ensure backend environment variables <code className="bg-slate-200 px-1 py-0.5 rounded font-mono">GOOGLE_ADS_CLIENT_ID</code>, <code className="bg-slate-200 px-1 py-0.5 rounded font-mono">GOOGLE_ADS_CLIENT_SECRET</code>, and <code className="bg-slate-200 px-1 py-0.5 rounded font-mono">GOOGLE_ADS_DEVELOPER_TOKEN</code> are provisioned.
          </p>
        </div>

        {status.connected && (
          <div className="space-y-4 pt-4 border-t border-slate-200">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">Select Account & Fetch Live Report</h3>
            <div className="flex flex-wrap items-center gap-4">
              <select className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 min-w-[280px]">
                {accounts.length === 0 ? (
                  <option value="">No MCC accounts discovered</option>
                ) : (
                  accounts.map(acc => (
                    <option key={acc.id} value={acc.id}>{acc.name} ({acc.id})</option>
                  ))
                )}
              </select>
              <button
                onClick={handleSyncTerms}
                disabled={syncing}
                className="px-5 py-3 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl shadow-md transition-all flex items-center gap-2"
              >
                {syncing ? <RefreshCw className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4 text-emerald-400" />}
                <span>Fetch Search Terms via GAQL</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
