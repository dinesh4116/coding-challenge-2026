import React, { useState } from 'react';
import { SearchTermItem, RecommendationType } from '../types';
import { Sparkles, Sliders, ArrowRight, ShieldAlert, CheckCircle2, TrendingDown, HelpCircle, FileText } from 'lucide-react';

interface DecisionIntelligenceViewProps {
  terms: SearchTermItem[];
  onReviewUpdate: (rowId: string, action: RecommendationType, notes?: string) => void;
}

export const DecisionIntelligenceView: React.FC<DecisionIntelligenceViewProps> = ({ terms, onReviewUpdate }) => {
  const [selectedRowIds, setSelectedRowIds] = useState<string[]>([]);
  const [counterfactualTermId, setCounterfactualTermId] = useState<string>(terms[0]?.row_id || '');

  const selectedTerm = terms.find(t => t.row_id === counterfactualTermId) || terms[0];

  const handleToggleSelect = (rowId: string) => {
    if (selectedRowIds.includes(rowId)) {
      setSelectedRowIds(selectedRowIds.filter(id => id !== rowId));
    } else {
      setSelectedRowIds([...selectedRowIds, rowId]);
    }
  };

  const selectedTermsList = terms.filter(t => selectedRowIds.includes(t.row_id));
  const historicalSpendSelected = selectedTermsList.reduce((acc, t) => acc + (Number(t.cost) || 0), 0);
  const historicalConversionsSelected = selectedTermsList.reduce((acc, t) => acc + (Number(t.conversions) || 0), 0);

  const blockCandidates = terms.filter(t => (t.reviewer_action || t.recommendation) === 'BLOCK');
  const totalBlockSpend = blockCandidates.reduce((acc, t) => acc + (Number(t.cost) || 0), 0);

  return (
    <div className="space-y-8 pb-12">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <Sparkles className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">Decision Intelligence & Counterfactual Simulator</h2>
            <p className="text-sm text-slate-500">Explore evidence-based counterfactual scenarios, decision impact simulations, and rule-based confidence justifications.</p>
          </div>
        </div>
      </div>

      {/* Feature 2: Counterfactual Analysis */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
          <Sliders className="h-5 w-5 text-blue-600" />
          <span>Counterfactual Analysis ("What if we block vs. keep?")</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-3">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Select Search Term</label>
            <select
              value={counterfactualTermId}
              onChange={(e) => setCounterfactualTermId(e.target.value)}
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800"
            >
              {terms.slice(0, 50).map(t => (
                <option key={t.row_id} value={t.row_id}>{t.search_term} ({t.campaign})</option>
              ))}
            </select>
            {selectedTerm && (
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                <div className="flex justify-between"><span className="text-slate-500">Campaign:</span><span className="font-semibold text-slate-800">{selectedTerm.campaign}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Historical Spend:</span><span className="font-semibold text-red-600">${selectedTerm.cost.toFixed(2)}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Clicks / Imp:</span><span className="font-semibold">{selectedTerm.clicks} / {selectedTerm.impressions}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Conversions:</span><span className="font-semibold text-emerald-600">{selectedTerm.conversions}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">ROAS:</span><span className="font-semibold">{selectedTerm.roas.toFixed(2)}x</span></div>
              </div>
            )}
          </div>

          <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-5 rounded-2xl bg-red-50 border border-red-200 space-y-3">
              <div className="flex items-center gap-2 text-red-800 font-bold text-xs">
                <ShieldAlert className="h-4 w-4 text-red-600" />
                <span>Scenario A: Apply BLOCK Action</span>
              </div>
              <p className="text-xs text-slate-700 leading-relaxed">
                If blocked, future impressions and clicks for this exact search term query string will be prevented by negative keyword rules.
              </p>
              <div className="text-[11px] text-red-900 font-medium">
                Historical Spend Reallocated: <span className="font-bold">${selectedTerm?.cost.toFixed(2)}</span> (Estimated potential saving; actual future savings depend on search volume shifts).
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-3">
              <div className="flex items-center gap-2 text-emerald-800 font-bold text-xs">
                <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                <span>Scenario B: Maintain or PROMOTE</span>
              </div>
              <p className="text-xs text-slate-700 leading-relaxed">
                If maintained or promoted, current bidding and budget allocation continue unchanged to capture commercial intent.
              </p>
              <div className="text-[11px] text-emerald-900 font-medium">
                Historical Conversion Value: <span className="font-bold">${selectedTerm?.conversion_value.toLocaleString()}</span> ({selectedTerm?.conversions} conversions).
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Feature 4: Decision Impact Simulator */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-base font-bold text-slate-900">Decision Impact Simulator</h3>
          <span className="text-xs font-semibold text-blue-700 bg-blue-100 px-3 py-1 rounded-full">
            {selectedRowIds.length} Terms Selected for Impact Simulation
          </span>
        </div>
        <p className="text-xs text-slate-500">
          Select rows below to calculate the cumulative historical spend and conversion metrics associated with proposed reviewer actions.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
            <span className="text-xs font-semibold text-slate-400 uppercase">Selected Historical Spend</span>
            <p className="text-2xl font-bold text-slate-900 mt-1">${historicalSpendSelected.toLocaleString(undefined, {minimumFractionDigits: 2})}</p>
          </div>
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
            <span className="text-xs font-semibold text-slate-400 uppercase">Selected Conversions</span>
            <p className="text-2xl font-bold text-emerald-600 mt-1">{historicalConversionsSelected.toLocaleString()}</p>
          </div>
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
            <span className="text-xs font-semibold text-slate-400 uppercase">Total Block Candidates Pool</span>
            <p className="text-2xl font-bold text-red-600 mt-1">${totalBlockSpend.toLocaleString(undefined, {minimumFractionDigits: 2})}</p>
          </div>
        </div>

        <div className="overflow-x-auto pt-2">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-500 border-b border-slate-200 font-semibold">
                <th className="p-3">Select</th>
                <th className="p-3">Search Term</th>
                <th className="p-3">Campaign</th>
                <th className="p-3 text-right">Cost</th>
                <th className="p-3 text-right">Conversions</th>
                <th className="p-3 text-center">Current Rec</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {terms.slice(0, 10).map((t) => (
                <tr key={t.row_id} className="hover:bg-slate-50/80">
                  <td className="p-3">
                    <input
                      type="checkbox"
                      checked={selectedRowIds.includes(t.row_id)}
                      onChange={() => handleToggleSelect(t.row_id)}
                      className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 h-4 w-4"
                    />
                  </td>
                  <td className="p-3 font-semibold text-slate-800">{t.search_term}</td>
                  <td className="p-3 text-slate-500">{t.campaign}</td>
                  <td className="p-3 text-right font-medium text-slate-900">${t.cost.toFixed(2)}</td>
                  <td className="p-3 text-right text-emerald-600 font-semibold">{t.conversions}</td>
                  <td className="p-3 text-center">
                    <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-bold text-[10px]">
                      {t.reviewer_action || t.recommendation}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
