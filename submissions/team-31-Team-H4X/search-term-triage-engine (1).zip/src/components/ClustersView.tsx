import React from 'react';
import { SearchTermItem } from '../types';
import { clusterSearchTerms } from '../utils/clustering';
import { Layers, AlertTriangle, Sparkles, DollarSign, Target } from 'lucide-react';

interface ClustersViewProps {
  terms: SearchTermItem[];
}

export const ClustersView: React.FC<ClustersViewProps> = ({ terms }) => {
  const clusters = clusterSearchTerms(terms);

  return (
    <div className="space-y-6 pb-12">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <h2 className="text-xl font-bold text-slate-900">Search Term Clusters & Root Intent</h2>
        <p className="text-sm text-slate-500">Grouped by normalized tokens and commercial theme variants to analyze portfolio performance.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {clusters.map((cluster, idx) => (
          <div key={idx} className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="h-9 w-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
                  <Layers className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">{cluster.clusterName}</h3>
                  <p className="text-xs text-slate-500">{cluster.terms.length} search terms in cluster</p>
                </div>
              </div>
              {cluster.hasConflict && (
                <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold flex items-center gap-1">
                  <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />
                  <span>Conflicting Actions</span>
                </span>
              )}
            </div>

            <div className="grid grid-cols-3 gap-3 pt-2">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span className="text-[10px] font-semibold text-slate-400 uppercase">Combined Spend</span>
                <p className="text-sm font-bold text-slate-900 mt-0.5">${cluster.totalCost.toLocaleString(undefined, {minimumFractionDigits: 2})}</p>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span className="text-[10px] font-semibold text-slate-400 uppercase">Conversions</span>
                <p className="text-sm font-bold text-emerald-600 mt-0.5">{cluster.totalConversions}</p>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span className="text-[10px] font-semibold text-slate-400 uppercase">Conv. Value</span>
                <p className="text-sm font-bold text-slate-900 mt-0.5">${cluster.totalValue.toLocaleString()}</p>
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-100">
              <span className="text-[10px] font-semibold text-slate-400 uppercase">Sample Terms in Cluster:</span>
              <div className="flex flex-wrap gap-1.5">
                {cluster.terms.slice(0, 5).map((t, tIdx) => (
                  <span key={tIdx} className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 text-xs font-medium">
                    {t.search_term} ({t.reviewer_action || t.recommendation})
                  </span>
                ))}
                {cluster.terms.length > 5 && (
                  <span className="px-2 py-1 rounded-lg bg-slate-50 text-slate-500 text-xs">
                    +{cluster.terms.length - 5} more
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
