import React from 'react';
import { Bell, Search, Database, Globe, RefreshCw } from 'lucide-react';

interface NavbarProps {
  dataSourceMode: string;
  totalTermsCount: number;
  onRefresh: () => void;
  isRefreshing: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({ dataSourceMode, totalTermsCount, onRefresh, isRefreshing }) => {
  return (
    <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between sticky top-0 z-30 shadow-xs">
      <div className="flex items-center gap-4">
        <h2 className="text-lg font-bold text-slate-800 tracking-tight">Search Term Triage Engine</h2>
        <span className="hidden md:inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-slate-100 text-slate-600 border border-slate-200">
          <Database className="h-3.5 w-3.5 text-blue-600" />
          <span>{totalTermsCount.toLocaleString()} Terms Analyzed</span>
        </span>
      </div>

      <div className="flex items-center gap-3">
        <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-blue-50 border border-blue-100 text-xs font-medium text-blue-800">
          <Globe className="h-3.5 w-3.5 text-blue-600" />
          <span>Advertiser: Kestrel Business Funding (US Lenders)</span>
        </div>

        <button
          onClick={onRefresh}
          disabled={isRefreshing}
          className="p-2 text-slate-600 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition-colors relative"
          title="Refresh Data & Re-run Analysis"
        >
          <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin text-blue-600' : ''}`} />
        </button>

        <div className="h-8 w-[1px] bg-slate-200"></div>

        <div className="flex items-center gap-2.5">
          <div className="h-9 w-9 rounded-full bg-blue-600 text-white font-semibold flex items-center justify-center text-sm shadow-sm">
            KB
          </div>
          <div className="hidden md:block text-left">
            <p className="text-xs font-bold text-slate-800">Reviewer User</p>
            <p className="text-[10px] text-slate-500 font-medium">Lead PPC Analyst</p>
          </div>
        </div>
      </div>
    </header>
  );
};
