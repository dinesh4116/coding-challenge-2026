import React, { useState, useMemo } from 'react';
import { SearchTermItem, RecommendationType } from '../types';
import { 
  Search, 
  Filter, 
  Download, 
  ChevronLeft, 
  ChevronRight, 
  Eye, 
  CheckCircle2, 
  Ban, 
  HelpCircle, 
  MinusCircle,
  ExternalLink,
  Sparkles
} from 'lucide-react';

interface SearchTermsViewProps {
  terms: SearchTermItem[];
  onReviewUpdate: (rowId: string, action: RecommendationType, notes?: string) => void;
}

export const SearchTermsView: React.FC<SearchTermsViewProps> = ({ terms, onReviewUpdate }) => {
  const [searchTermQuery, setSearchTermQuery] = useState('');
  const [selectedCampaign, setSelectedCampaign] = useState('ALL');
  const [selectedRecommendation, setSelectedRecommendation] = useState('ALL');
  const [selectedMatchType, setSelectedMatchType] = useState('ALL');
  const [minClicks, setMinClicks] = useState(0);
  const [minSpend, setMinSpend] = useState(0);
  const [minConversions, setMinConversions] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 15;

  const [activeDrawerItem, setActiveDrawerItem] = useState<SearchTermItem | null>(null);
  const [reviewerNotesInput, setReviewerNotesInput] = useState('');

  // Extract unique campaigns
  const campaigns = useMemo(() => {
    const set = new Set<string>();
    terms.forEach(t => { if (t.campaign) set.add(t.campaign); });
    return Array.from(set);
  }, [terms]);

  // Filter & sort terms
  const filteredTerms = useMemo(() => {
    return terms.filter(t => {
      const matchQuery = t.search_term.toLowerCase().includes(searchTermQuery.toLowerCase()) ||
                         t.ad_group.toLowerCase().includes(searchTermQuery.toLowerCase());
      const matchCamp = selectedCampaign === 'ALL' || t.campaign === selectedCampaign;
      const effectiveRec = t.reviewer_action || t.recommendation;
      const matchRec = selectedRecommendation === 'ALL' || effectiveRec === selectedRecommendation;
      const matchType = selectedMatchType === 'ALL' || t.match_type === selectedMatchType;
      const matchClicks = (Number(t.clicks) || 0) >= minClicks;
      const matchSpend = (Number(t.cost) || 0) >= minSpend;
      const matchConv = (Number(t.conversions) || 0) >= minConversions;

      return matchQuery && matchCamp && matchRec && matchType && matchClicks && matchSpend && matchConv;
    });
  }, [terms, searchTermQuery, selectedCampaign, selectedRecommendation, selectedMatchType, minClicks, minSpend, minConversions]);

  const totalPages = Math.ceil(filteredTerms.length / pageSize) || 1;
  const paginatedTerms = filteredTerms.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const handleExportFilteredCSV = () => {
    const csvHeader = "row_id,search_term,match_type,campaign,ad_group,impressions,clicks,cost,conversions,conversion_value,recommendation,confidence,intent_category\n";
    const csvRows = filteredTerms.map(t => 
      `"${t.row_id}","${t.search_term}","${t.match_type}","${t.campaign}","${t.ad_group}",${t.impressions},${t.clicks},${t.cost},${t.conversions},${t.conversion_value},"${t.reviewer_action || t.recommendation}",${t.confidence},"${t.intent_category}"`
    ).join("\n");

    const blob = new Blob([csvHeader + csvRows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'filtered_search_terms_report.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Controls */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Search Terms Explorer</h2>
            <p className="text-sm text-slate-500">Filter, inspect, and override triage recommendations for Google Ads search terms.</p>
          </div>
          <button
            onClick={handleExportFilteredCSV}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs rounded-xl shadow-md transition-all flex items-center gap-2"
          >
            <Download className="h-4 w-4" />
            <span>Export Filtered CSV ({filteredTerms.length})</span>
          </button>
        </div>

        {/* Filter Toolbar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
          <div className="relative">
            <Search className="h-4 w-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="Search terms or ad groups..."
              value={searchTermQuery}
              onChange={(e) => setSearchTermQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500"
            />
          </div>

          <select
            value={selectedCampaign}
            onChange={(e) => setSelectedCampaign(e.target.value)}
            className="py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:border-blue-500"
          >
            <option value="ALL">All Campaigns</option>
            {campaigns.map(c => <option key={c} value={c}>{c}</option>)}
          </select>

          <select
            value={selectedRecommendation}
            onChange={(e) => setSelectedRecommendation(e.target.value)}
            className="py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:border-blue-500"
          >
            <option value="ALL">All Recommendations</option>
            <option value="PROMOTE">PROMOTE</option>
            <option value="BLOCK">BLOCK</option>
            <option value="REVIEW">REVIEW</option>
            <option value="IGNORE">IGNORE</option>
          </select>

          <select
            value={selectedMatchType}
            onChange={(e) => setSelectedMatchType(e.target.value)}
            className="py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:border-blue-500"
          >
            <option value="ALL">All Match Types</option>
            <option value="Exact">Exact</option>
            <option value="Phrase">Phrase</option>
            <option value="Broad">Broad</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden flex flex-col">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-500 border-b border-slate-200 font-semibold">
                <th className="p-3.5">Search Term</th>
                <th className="p-3.5">Campaign / Ad Group</th>
                <th className="p-3.5 text-center">Match</th>
                <th className="p-3.5 text-right">Clicks / Imp</th>
                <th className="p-3.5 text-right">Cost</th>
                <th className="p-3.5 text-right">Conv (ROAS)</th>
                <th className="p-3.5 text-center">Recommendation</th>
                <th className="p-3.5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedTerms.map((t) => {
                const rec = t.reviewer_action || t.recommendation;
                return (
                  <tr key={t.row_id} className="hover:bg-slate-50/80">
                    <td className="p-3.5 font-semibold text-slate-900">
                      <div>{t.search_term}</div>
                      <div className="text-[10px] text-slate-400 font-normal">{t.intent_category}</div>
                    </td>
                    <td className="p-3.5">
                      <div className="font-medium text-slate-800">{t.campaign}</div>
                      <div className="text-[10px] text-slate-400">{t.ad_group}</div>
                    </td>
                    <td className="p-3.5 text-center">
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium text-[10px]">
                        {t.match_type}
                      </span>
                    </td>
                    <td className="p-3.5 text-right font-medium text-slate-700">
                      <div>{t.clicks.toLocaleString()}</div>
                      <div className="text-[10px] text-slate-400">{t.impressions.toLocaleString()} imp</div>
                    </td>
                    <td className="p-3.5 text-right font-semibold text-slate-900">${t.cost.toFixed(2)}</td>
                    <td className="p-3.5 text-right font-medium text-slate-700">
                      <div>{t.conversions} (${t.conversion_value.toLocaleString()})</div>
                      <div className="text-[10px] text-emerald-600 font-semibold">{t.roas.toFixed(2)}x ROAS</div>
                    </td>
                    <td className="p-3.5 text-center">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                        rec === 'PROMOTE' ? 'bg-emerald-100 text-emerald-800' :
                        rec === 'BLOCK' ? 'bg-red-100 text-red-800' :
                        rec === 'IGNORE' ? 'bg-slate-100 text-slate-700' :
                        'bg-amber-100 text-amber-800'
                      }`}>
                        {rec} {t.reviewer_action ? '(Overridden)' : ''}
                      </span>
                    </td>
                    <td className="p-3.5 text-center">
                      <button
                        onClick={() => {
                          setActiveDrawerItem(t);
                          setReviewerNotesInput(t.reviewer_notes || '');
                        }}
                        className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="View Details"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
              {paginatedTerms.length === 0 && (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">
                    No search terms match your filter criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-600">
          <div>
            Showing {(currentPage - 1) * pageSize + 1} to {Math.min(currentPage * pageSize, filteredTerms.length)} of {filteredTerms.length.toLocaleString()} entries
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage(p => Math.max(p - 1, 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded-lg border border-slate-200 bg-white disabled:opacity-40"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <span className="font-semibold">Page {currentPage} of {totalPages}</span>
            <button
              onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded-lg border border-slate-200 bg-white disabled:opacity-40"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Detail Drawer */}
      {activeDrawerItem && (
        <div className="fixed inset-0 bg-slate-950/50 z-50 flex justify-end backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white h-full shadow-2xl flex flex-col p-6 overflow-y-auto space-y-6">
            <div className="flex items-center justify-between border-b border-slate-200 pb-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600">{activeDrawerItem.row_id}</span>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">{activeDrawerItem.search_term}</h3>
              </div>
              <button
                onClick={() => setActiveDrawerItem(null)}
                className="h-8 w-8 rounded-full bg-slate-100 text-slate-600 hover:bg-slate-200 flex items-center justify-center font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase">Campaign</span>
                  <p className="text-xs font-bold text-slate-800 mt-0.5">{activeDrawerItem.campaign}</p>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase">Ad Group</span>
                  <p className="text-xs font-bold text-slate-800 mt-0.5">{activeDrawerItem.ad_group}</p>
                </div>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-4 gap-3">
                <div className="bg-blue-50/50 p-3 rounded-xl border border-blue-100 text-center">
                  <span className="text-[10px] font-semibold text-blue-600 uppercase">Clicks</span>
                  <p className="text-sm font-bold text-slate-900 mt-0.5">{activeDrawerItem.clicks.toLocaleString()}</p>
                </div>
                <div className="bg-blue-50/50 p-3 rounded-xl border border-blue-100 text-center">
                  <span className="text-[10px] font-semibold text-blue-600 uppercase">Cost</span>
                  <p className="text-sm font-bold text-slate-900 mt-0.5">${activeDrawerItem.cost.toFixed(2)}</p>
                </div>
                <div className="bg-blue-50/50 p-3 rounded-xl border border-blue-100 text-center">
                  <span className="text-[10px] font-semibold text-blue-600 uppercase">Conversions</span>
                  <p className="text-sm font-bold text-slate-900 mt-0.5">{activeDrawerItem.conversions}</p>
                </div>
                <div className="bg-blue-50/50 p-3 rounded-xl border border-blue-100 text-center">
                  <span className="text-[10px] font-semibold text-blue-600 uppercase">ROAS</span>
                  <p className="text-sm font-bold text-emerald-600 mt-0.5">{activeDrawerItem.roas.toFixed(2)}x</p>
                </div>
              </div>

              {/* Explanation & Rules */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">Triage Engine Analysis</span>
                  <span className="text-xs font-bold text-blue-600">{activeDrawerItem.confidence}% Confidence</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">{activeDrawerItem.explanation}</p>
                <div className="space-y-1">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase">Triggered Rules:</span>
                  {activeDrawerItem.triggered_rules?.map((rule, idx) => (
                    <div key={idx} className="text-[11px] font-medium text-slate-700 flex items-center gap-1.5">
                      <Sparkles className="h-3 w-3 text-blue-600" />
                      <span>{rule}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Reviewer Action Override */}
              <div className="space-y-3 pt-2">
                <label className="text-xs font-bold text-slate-800 uppercase tracking-wider">Reviewer Action & Override</label>
                <div className="grid grid-cols-4 gap-2">
                  {(['PROMOTE', 'BLOCK', 'REVIEW', 'IGNORE'] as RecommendationType[]).map((act) => {
                    const isSelected = (activeDrawerItem.reviewer_action || activeDrawerItem.recommendation) === act;
                    return (
                      <button
                        key={act}
                        onClick={() => {
                          onReviewUpdate(activeDrawerItem.row_id, act, reviewerNotesInput);
                          setActiveDrawerItem({ ...activeDrawerItem, reviewer_action: act });
                        }}
                        className={`py-2 px-1 rounded-xl text-xs font-bold transition-all border ${
                          isSelected
                            ? act === 'PROMOTE' ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm' :
                              act === 'BLOCK' ? 'bg-red-600 text-white border-red-600 shadow-sm' :
                              act === 'IGNORE' ? 'bg-slate-700 text-white border-slate-700 shadow-sm' :
                              'bg-amber-500 text-white border-amber-500 shadow-sm'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        {act}
                      </button>
                    );
                  })}
                </div>

                <div className="space-y-1 pt-2">
                  <label className="text-xs font-semibold text-slate-600">Reviewer Notes</label>
                  <textarea
                    rows={3}
                    placeholder="Add notes on why this override or approval was made..."
                    value={reviewerNotesInput}
                    onChange={(e) => setReviewerNotesInput(e.target.value)}
                    onBlur={() => {
                      if (activeDrawerItem) {
                        onReviewUpdate(activeDrawerItem.row_id, activeDrawerItem.reviewer_action || activeDrawerItem.recommendation, reviewerNotesInput);
                      }
                    }}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setActiveDrawerItem(null)}
                className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl shadow-sm"
              >
                Close Drawer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
