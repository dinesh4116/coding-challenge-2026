import { SearchTermItem, SettingsData, ReviewItem } from '../types';

export async function fetchSearchTerms(accountId?: string): Promise<SearchTermItem[]> {
  try {
    const res = await fetch(`/api/google-ads/search-terms${accountId ? `?accountId=${accountId}` : ''}`);
    const data = await res.json();
    return data.searchTerms || [];
  } catch (err) {
    console.error('Failed to fetch search terms', err);
    return [];
  }
}

export async function fetchGoogleAdsStatus() {
  try {
    const res = await fetch('/api/google-ads/status');
    return await res.json();
  } catch (err) {
    return { connected: false };
  }
}

export async function fetchGoogleAdsAccounts() {
  try {
    const res = await fetch('/api/google-ads/accounts');
    const data = await res.json();
    return data.accounts || [];
  } catch (err) {
    return [];
  }
}

export async function fetchOAuthUrl(): Promise<{ authUrl?: string; error?: string }> {
  try {
    const res = await fetch('/api/google-ads/auth');
    const data = await res.json();
    if (!res.ok) {
      return { error: data.error || 'Failed to generate OAuth authorization URL' };
    }
    return { authUrl: data.authUrl };
  } catch (err: any) {
    return { error: err.message || 'Network error while connecting Google Ads' };
  }
}

export async function disconnectGoogleAds() {
  try {
    const res = await fetch('/api/google-ads/disconnect', { method: 'POST' });
    return await res.json();
  } catch (err) {
    return { success: false };
  }
}

export async function fetchReviews(): Promise<ReviewItem[]> {
  try {
    const res = await fetch('/api/reviews');
    return await res.json();
  } catch (err) {
    return [];
  }
}

export async function saveReview(review: ReviewItem): Promise<boolean> {
  try {
    const res = await fetch('/api/reviews', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(review)
    });
    const data = await res.json();
    return data.success;
  } catch (err) {
    return false;
  }
}

export async function fetchSettings(): Promise<SettingsData | null> {
  try {
    const res = await fetch('/api/settings');
    return await res.json();
  } catch (err) {
    return null;
  }
}

export async function saveSettings(settings: SettingsData): Promise<boolean> {
  try {
    const res = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings)
    });
    const data = await res.json();
    return data.success;
  } catch (err) {
    return false;
  }
}

export async function analyzeSearchTermsLocallyOrAPI(terms: SearchTermItem[]): Promise<SearchTermItem[]> {
  try {
    const res = await fetch('/api/triage/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ searchTerms: terms })
    });
    const data = await res.json();
    if (data.success && data.results) {
      return data.results;
    }
    return terms;
  } catch (err) {
    return terms;
  }
}

export async function fetchBenchmarks() {
  try {
    const res = await fetch('/api/benchmarks');
    return await res.json();
  } catch (err) {
    return null;
  }
}

export async function fetchDemoSearchTerms(): Promise<SearchTermItem[]> {
  try {
    const res = await fetch('/api/demo/search-terms');
    const data = await res.json();
    return data.searchTerms || [];
  } catch (err) {
    console.error('Failed to fetch demo search terms', err);
    return [];
  }
}
