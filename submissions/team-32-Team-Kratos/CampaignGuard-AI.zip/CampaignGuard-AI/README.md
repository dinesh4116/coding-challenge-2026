# CampaignGuard AI — Industry Dataset MVP

CampaignGuard AI is a Streamlit dashboard for trust-aware advertising campaign anomaly detection. It validates daily campaign data, builds leakage-safe rolling baselines, flags unusual observations, explains the evidence, and provides campaign timelines and incident summaries.

## Features

- CSV and Excel upload
- Automatic column mapping for common names, with optional manual overrides
- Data quality checks for missing/negative metrics and duplicate campaign-days
- Rolling median/MAD baselines computed from prior observations only
- Adjustable robust anomaly threshold and minimum-history sliders, with automatic re-analysis
- Evidence-specific anomaly explanations and investigation recommendations
- Session-state persistence so timeline/alert selections survive Streamlit reruns
- Consecutive flagged-day incident summaries with a heuristic anomaly-strength score (not accuracy)
- False-positive count shown only when independent ground-truth labels are provided; otherwise displayed as unavailable with a heuristic anomaly-strength score (not accuracy)
- False-positive count shown only when independent ground-truth labels are provided; otherwise displayed as unavailable
- CSV export of analyzed results

## Run locally (Windows Command Prompt)

```bat
cd C:\Projects\Hackathon
.venv\Scripts\activate.bat
cd CampaignGuard-AI
pip install -r requirements.txt
streamlit run app.py
```

Use the supplied industry file `daily_campaign_metrics.csv`. The expected mapping is `date` → date, `campaign_id` → campaign identifier, `spend` → spend, `impressions` → impressions, `clicks` → clicks, `conversions` → conversions, and `revenue` → revenue. Budget and ground-truth labels are not present in that file.

For the supplied industry dataset, data quality should report 3,600 rows, 20 campaigns, 180 unique dates, and zero duplicate campaign-days.

## Important limitations

- A detected anomaly is a diagnostic signal, not proof of a business incident or its root cause.
- The industry dataset has no ground-truth incident labels, so precision/recall cannot be measured from it alone.
- No budget-exhaustion conclusion is possible without a budget field.
- Interactive sliders support sensitivity testing; no threshold is claimed to be optimally calibrated. Validate with labeled incidents and known test scenarios before production use.
- Suggested actions are investigation guidance based on metric patterns; they are not causal diagnoses.
