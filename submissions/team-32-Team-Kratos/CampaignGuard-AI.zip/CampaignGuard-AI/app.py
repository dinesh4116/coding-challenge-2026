import io
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

from src.data_loader import (
    read_table, suggest_column_mapping, standardize_data, validate_data
)
from src.features import add_campaign_features
from src.detector import detect_anomalies
from src.decision_engine import apply_decision_policy, summarize_incidents
from src.explanations import explain_alert
from src.evaluation import evaluate_detector, evaluate_scenarios

st.set_page_config(page_title="CampaignGuard AI", page_icon="🛡️", layout="wide", initial_sidebar_state="collapsed")

# Dark graphite + violet UI. CSS only styles presentation; detection logic remains unchanged.
st.markdown("""
<style>
:root { --cg-bg:#0b0a10; --cg-panel:#15131d; --cg-panel-2:#1c1927; --cg-border:#302a40; --cg-violet:#9b7bff; --cg-violet-2:#7654e8; --cg-text:#f4f1fb; --cg-muted:#aaa4ba; }
.stApp { background: radial-gradient(ellipse at 12% 0%, rgba(118,84,232,.13), transparent 34%), var(--cg-bg); color:var(--cg-text); }
[data-testid="stHeader"] { background:rgba(11,10,16,.88); }
.block-container { max-width: 1450px; padding-top: 2.6rem !important; padding-bottom: 3rem; overflow: visible; }
[data-testid="stAppViewContainer"] .main .block-container { gap: .8rem; }
.cg-hero { box-sizing:border-box; width:100%; border:1px solid var(--cg-border); background:linear-gradient(120deg,rgba(155,123,255,.13),rgba(28,25,39,.98) 50%,rgba(21,19,29,.99)); border-radius:22px; padding:32px 30px 28px; margin:10px 0 24px 0; box-shadow:0 18px 45px rgba(0,0,0,.16); overflow:visible; }
.cg-eyebrow { display:block; color:#b9a6ff; text-transform:uppercase; letter-spacing:.14em; font-size:.72rem; line-height:1.5; font-weight:800; margin:0 0 10px 0; padding-top:2px; }
.cg-title { display:block; font-size:2.25rem; line-height:1.2; font-weight:850; letter-spacing:-.045em; color:#fbfaff; margin:0; padding:0; }
.cg-subtitle { color:#c0b9d0; margin-top:10px; font-size:1rem; max-width:850px; }
.cg-pill { display:inline-block; margin-top:15px; border:1px solid #59468b; color:#d9ceff; background:rgba(118,84,232,.16); border-radius:999px; padding:5px 11px; font-size:.76rem; }
[data-testid="stMetric"] { background:linear-gradient(145deg,#1a1724,#121018); border:1px solid var(--cg-border); border-radius:16px; padding:16px 18px; box-shadow:0 8px 22px rgba(0,0,0,.12); }
[data-testid="stMetricLabel"] { color:var(--cg-muted) !important; font-size:.82rem !important; }
[data-testid="stMetricValue"] { color:#f6f2ff !important; font-weight:800 !important; }
[data-testid="stMetricDelta"] { color:#b9a6ff !important; }
[data-testid="stFileUploader"] section { background:#15131d; border:1px dashed #65518e; border-radius:16px; }
[data-testid="stFileUploaderDropzoneInstructions"] { color:#c7bfd8; }
.stButton > button, .stFormSubmitButton > button, [data-testid="stDownloadButton"] button { border-radius:11px; border:1px solid #7654e8; background:linear-gradient(135deg,#8b68f3,#6f4add); color:white; font-weight:750; min-height:2.7rem; transition:all .15s ease; }
.stButton > button:hover, .stFormSubmitButton > button:hover, [data-testid="stDownloadButton"] button:hover { border-color:#b8a4ff; background:linear-gradient(135deg,#9b7bff,#7958ed); color:white; transform:translateY(-1px); }
.stSelectbox > div > div, .stMultiSelect > div > div, .stTextInput input { background:#17141f; border-color:#393148; border-radius:10px; }
[data-testid="stExpander"] { border:1px solid var(--cg-border); background:rgba(21,19,29,.75); border-radius:13px; }
[data-testid="stDataFrame"] { border:1px solid var(--cg-border); border-radius:12px; overflow:hidden; }
[data-testid="stAlert"] { border-radius:12px; }
hr { border-color:#302a40; }
h1,h2,h3,h4 { letter-spacing:-.025em; }
section[data-testid="stSidebar"] { background:#100e16; border-right:1px solid var(--cg-border); }
label, .stCaption { color:#b7afc8; }
/* Use violet as the accent for sliders and focus states. */
[data-baseweb="slider"] [role="slider"] { background:#9b7bff; border-color:#9b7bff; }
:focus-visible { outline-color:#9b7bff !important; }
@media (max-width: 768px) { .block-container { padding-top:1.5rem !important; } .cg-hero { padding:24px 20px; border-radius:16px; margin-top:6px; } .cg-title { font-size:1.8rem; } .cg-eyebrow { letter-spacing:.09em; } }
</style>
<div class="cg-hero">
  <div class="cg-eyebrow">Campaign intelligence · Anomaly monitoring</div>
  <div class="cg-title">🛡️ CampaignGuard <span style="color:#a991ff">AI</span></div>
  <div class="cg-subtitle">Find unusual campaign behavior, understand the evidence, and focus on alerts that deserve attention.</div>
  <div class="cg-pill">● Trust-aware monitoring &nbsp; · &nbsp; CSV / Excel analysis</div>
</div>
""", unsafe_allow_html=True)

uploaded = st.file_uploader("Upload campaign data", type=["csv", "xlsx", "xls"])

if uploaded is None:
    st.info(
        "Upload the industry dataset when you have it. Map its columns below; "
        "the app does not assume the file uses a specific schema."
    )
    st.stop()

try:
    raw = read_table(uploaded)
except Exception as exc:
    st.error(f"Could not read the uploaded file: {exc}")
    st.stop()

if raw.empty:
    st.error("The uploaded file contains no rows.")
    st.stop()

st.subheader("01  ·  Data source & mapping")
suggested = suggest_column_mapping(raw.columns)
columns = list(raw.columns)
# A schema-specific key prevents Streamlit from reusing a stale manual selection
# when a different file/schema is uploaded. Defaults come from detected column names.
schema_key = "_".join(str(c).strip().lower().replace(" ", "_") for c in columns)
schema_key = str(abs(hash((getattr(uploaded, "name", "upload"), schema_key))))

def select_column(label, canonical, required=False):
    guess = suggested.get(canonical)
    options = ["— Not available —"] + columns
    index = options.index(guess) if guess in columns else 0
    selected = st.selectbox(
        label, options, index=index,
        key=f"map_v2_{schema_key}_{canonical}",
        help="Automatically suggested from the source column name. Change only if the suggestion is wrong."
    )
    if selected == "— Not available —":
        if required:
            st.warning(f"{label} is required.")
        return None
    return selected

with st.form("column_mapping_v2"):
    st.caption("We automatically match recognized column names. Open the optional section only if a column was mapped incorrectly.")
    with st.expander("Review or override column mappings", expanded=False):
        c1, c2, c3 = st.columns(3)
        with c1:
            date_col = select_column("Date column *", "date", True)
            campaign_col = select_column("Campaign ID/name *", "campaign_id", True)
            spend_col = select_column("Spend/cost", "spend")
        with c2:
            impressions_col = select_column("Impressions", "impressions")
            clicks_col = select_column("Clicks", "clicks")
            conversions_col = select_column("Conversions", "conversions")
        with c3:
            revenue_col = select_column("Revenue/value", "revenue")
            budget_col = select_column("Budget", "budget")
            label_col = select_column("Ground-truth label (optional)", "ground_truth_anomaly")
    # Resolve the same automatic suggestions when the advanced mapping panel is untouched.
    if "date_col" not in locals():
        date_col = suggested.get("date")
        campaign_col = suggested.get("campaign_id")
        spend_col = suggested.get("spend")
        impressions_col = suggested.get("impressions")
        clicks_col = suggested.get("clicks")
        conversions_col = suggested.get("conversions")
        revenue_col = suggested.get("revenue")
        budget_col = suggested.get("budget")
        label_col = suggested.get("ground_truth_anomaly")
    submitted = st.form_submit_button("Analyze campaign data", type="primary")

file_signature = (getattr(uploaded, "name", "upload"), getattr(uploaded, "size", None))
if not submitted and (
    "campaignguard_result" not in st.session_state
    or st.session_state.get("campaignguard_signature") != file_signature
):
    st.stop()

mapping = {
    "date": date_col,
    "campaign_id": campaign_col,
    "spend": spend_col,
    "impressions": impressions_col,
    "clicks": clicks_col,
    "conversions": conversions_col,
    "revenue": revenue_col,
    "budget": budget_col,
    "ground_truth_anomaly": label_col,
}

if submitted:
    try:
        data = standardize_data(raw, mapping)
        quality = validate_data(data)
    except Exception as exc:
        st.error(f"Data validation failed: {exc}")
        st.stop()
else:
    data, quality, featured, detected = st.session_state["campaignguard_result"]

st.subheader("02  ·  Data quality")
q1, q2, q3, q4 = st.columns(4)
q1.metric("Rows", f"{quality['rows']:,}")
q2.metric("Campaigns", quality["campaigns"])
q3.metric("Dates", quality["unique_dates"])
q4.metric("Duplicate campaign-days", quality["duplicate_campaign_days"])
st.caption(f"Date range: {quality['date_start']} to {quality['date_end']}")

with st.expander("Full data quality report"):
    st.json(quality)

st.subheader("03  ·  Detection controls")
settings_left, settings_right = st.columns(2)
with settings_left:
    threshold = st.slider(
        "Robust anomaly threshold", min_value=1.5, max_value=6.0,
        value=float(st.session_state.get("cg_threshold", 3.5)), step=0.25,
        help="Lower values flag more deviations; higher values are more conservative."
    )
with settings_right:
    min_history = st.slider(
        "Minimum historical observations", min_value=3, max_value=14,
        value=int(st.session_state.get("cg_min_history", 7)), step=1,
        help="How many prior observations are required before scoring a metric."
    )
st.caption("Adjust either slider to rerun detection. These settings change sensitivity; they do not directly measure accuracy.")
settings_signature = (float(threshold), int(min_history))
settings_changed = st.session_state.get("campaignguard_settings_signature") != settings_signature

if submitted or settings_changed:
    try:
        featured = add_campaign_features(data, min_periods=min_history)
        detected = detect_anomalies(featured, threshold=threshold, min_history=min_history)
        detected = apply_decision_policy(detected)
        # A heuristic anomaly-strength score is useful for ranking, but is not calibrated accuracy/probability.
        detected["anomaly_strength_pct"] = (
            (detected["anomaly_score"].clip(lower=0) / (threshold * 2.5)) * 100
        ).clip(upper=100).round(1)
        st.session_state["campaignguard_result"] = (data, quality, featured, detected)
        st.session_state["campaignguard_signature"] = file_signature
        st.session_state["campaignguard_settings_signature"] = settings_signature
        st.session_state["cg_threshold"] = threshold
        st.session_state["cg_min_history"] = min_history
    except Exception as exc:
        st.error(f"Analysis failed: {exc}")
        st.exception(exc)
        st.stop()
else:
    # Restore the latest detection result when other dashboard widgets trigger a rerun.
    data, quality, featured, detected = st.session_state["campaignguard_result"]

st.subheader("04  ·  Monitoring overview")
alerts = detected[detected["anomaly_detected"]].copy()
m1, m2, m3, m4 = st.columns(4)
m1.metric("Campaigns monitored", detected["campaign_id"].nunique())
m2.metric("Flagged days", int(detected["anomaly_detected"].sum()))
m3.metric("Campaigns with alerts", alerts["campaign_id"].nunique())
m4.metric("High severity days", int((alerts["severity"] == "High").sum()))

left, right = st.columns(2)
with left:
    daily = detected.groupby("date", as_index=False)["anomaly_detected"].sum()
    fig = px.line(daily, x="date", y="anomaly_detected", title="Flagged campaign-days over time", template="plotly_dark")
    fig.update_traces(line=dict(color="#9b7bff", width=3), fill="tozeroy", fillcolor="rgba(155,123,255,0.12)")
    fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font_color="#dcd5eb", title_font_color="#f5f0ff")
    st.plotly_chart(fig, use_container_width=True)
with right:
    if not alerts.empty:
        counts = alerts["incident_type"].value_counts().rename_axis("incident_type").reset_index(name="days")
        fig2 = px.bar(counts, x="incident_type", y="days", title="Flagged days by signal type", template="plotly_dark", color_discrete_sequence=["#9b7bff"])
        fig2.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font_color="#dcd5eb", title_font_color="#f5f0ff")
        st.plotly_chart(fig2, use_container_width=True)
    else:
        st.success("No anomalies crossed the configured threshold.")

st.subheader("05  ·  Alert investigation")
if alerts.empty:
    st.info("No rows were flagged. Consider checking the column mapping and threshold.")
else:
    display_cols = [
        c for c in [
            "date", "campaign_id", "incident_type", "severity",
            "evidence_strength", "anomaly_score", "anomaly_strength_pct", "alert_status",
            "explanation", "recommended_action"
        ] if c in alerts.columns
    ]
    st.dataframe(alerts[display_cols], use_container_width=True, hide_index=True)
    chosen_index = st.selectbox(
        "Select an alert to inspect",
        alerts.index.tolist(),
        format_func=lambda i: f"{pd.Timestamp(alerts.loc[i, 'date']).date()} · {alerts.loc[i, 'campaign_id']} · {alerts.loc[i, 'incident_type']}",
        key="alert_to_inspect_v2"
    )
    st.info(explain_alert(alerts.loc[chosen_index]))

st.subheader("06  ·  Campaign timeline")
campaigns = sorted(detected["campaign_id"].dropna().astype(str).unique())
chosen_campaign = st.selectbox("Choose campaign", campaigns, key="timeline_campaign_v2")
campaign_df = detected[detected["campaign_id"].astype(str) == chosen_campaign].copy()
metric_options = [c for c in ["spend", "impressions", "clicks", "conversions", "revenue"] if c in campaign_df and campaign_df[c].notna().any()]
if metric_options:
    metric = st.selectbox("Metric to plot", metric_options, key="timeline_metric_v2")
    baseline = f"{metric}_baseline"
    chart = campaign_df[["date", metric] + ([baseline] if baseline in campaign_df else [])].melt(
        id_vars="date", var_name="series", value_name="value"
    )
    fig3 = px.line(chart, x="date", y="value", color="series", title=f"{chosen_campaign}: {metric} and historical baseline", template="plotly_dark", color_discrete_sequence=["#9b7bff", "#888395"])
    fig3.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font_color="#dcd5eb", title_font_color="#f5f0ff", legend_title_text="Series")
    flagged = campaign_df[campaign_df["anomaly_detected"]]
    if not flagged.empty:
        fig3.add_scatter(
            x=flagged["date"], y=flagged[metric], mode="markers",
            name="Flagged", marker={"size": 9, "symbol": "x"}
        )
    st.plotly_chart(fig3, use_container_width=True)

st.subheader("07  ·  Incident summary")
events = summarize_incidents(detected)
if events.empty:
    st.write("No flagged incident windows to summarize.")
else:
    # Attach a transparent, heuristic anomaly-strength score to each incident window.
    # This is deliberately not called accuracy because there are no verified labels.
    score_rows = []
    flagged_rows = detected[detected["anomaly_detected"].fillna(False)].copy()
    for _, event in events.iterrows():
        mask = (
            (flagged_rows["campaign_id"].astype(str) == str(event["campaign_id"]))
            & (pd.to_datetime(flagged_rows["date"]).dt.date >= pd.Timestamp(event["start_date"]).date())
            & (pd.to_datetime(flagged_rows["date"]).dt.date <= pd.Timestamp(event["end_date"]).date())
        )
        event_flags = flagged_rows.loc[mask]
        score_rows.append(float(event_flags["anomaly_strength_pct"].mean()) if not event_flags.empty else 0.0)
    events["mean_anomaly_strength_pct"] = [round(x, 1) for x in score_rows]
    events = events.rename(columns={"mean_anomaly_strength_pct": "Anomaly strength (%) — not accuracy"})
    # When independent labels exist, show the share of flagged days in each event labeled positive.
    if "ground_truth_anomaly" in detected.columns:
        labels = pd.to_numeric(detected["ground_truth_anomaly"], errors="coerce")
        if labels.isin([0, 1]).any():
            labeled = detected.assign(_truth=labels)
            event_match_rates = []
            for _, event in events.iterrows():
                mask = (
                    labeled["anomaly_detected"].fillna(False)
                    & (labeled["campaign_id"].astype(str) == str(event["campaign_id"]))
                    & (pd.to_datetime(labeled["date"]).dt.date >= pd.Timestamp(event["start_date"]).date())
                    & (pd.to_datetime(labeled["date"]).dt.date <= pd.Timestamp(event["end_date"]).date())
                )
                vals = labeled.loc[mask, "_truth"].dropna()
                event_match_rates.append(round(float((vals == 1).mean() * 100), 1) if not vals.empty else float("nan"))
            events["Labeled incident match (%)"] = event_match_rates
    st.dataframe(events, use_container_width=True, hide_index=True)
    st.caption("Anomaly strength is a heuristic score, not a probability or accuracy. If independent 0/1 labels are provided, Labeled incident match (%) is the share of flagged days in that event window labeled as real incidents.")

st.markdown("### 08  ·  Evaluation summary")
if label_col is not None and "ground_truth_anomaly" in detected.columns:
    st.subheader("8. Evaluation against provided labels")
    try:
        metrics = evaluate_detector(detected)
        metric_cols = st.columns(4)
        for col, key, label in zip(
            metric_cols,
            ["precision", "recall", "f1_score", "false_positive_rate"],
            ["Precision", "Recall", "F1 score", "False-positive rate"]
        ):
            col.metric(label, f"{metrics[key]:.2%}")
        with st.expander("Detailed evaluation"):
            st.json(metrics)
        st.metric("False positives (campaign-days)", f"{metrics['false_positives']:,}")
        if "scenario_tag" in detected.columns:
            st.dataframe(evaluate_scenarios(detected), use_container_width=True, hide_index=True)
    except Exception as exc:
        st.warning(f"Evaluation unavailable: {exc}")
else:
    flagged_count = int(detected["anomaly_detected"].fillna(False).sum())
    st.caption("No ground-truth label was mapped. True accuracy and false-positive count cannot be calculated from this dataset because there is no verified incident label for each campaign-day.")
    fp_col, unverified_col = st.columns(2)
    fp_col.metric("False positives", "N/A")
    unverified_col.metric("Unverified flagged campaign-days", f"{flagged_count:,}")
    st.info("The unverified flagged count is not the false-positive count. To calculate false positives, map an independent ground-truth label (1 = real incident, 0 = no incident) and rerun analysis.")

csv_bytes = detected.to_csv(index=False).encode("utf-8")
st.download_button(
    "Download analyzed results (CSV)",
    data=csv_bytes,
    file_name="campaignguard_analysis.csv",
    mime="text/csv"
)
