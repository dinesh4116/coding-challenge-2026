from pathlib import Path
import pandas as pd

# Canonical fields used internally. The uploaded industry dataset can use different names;
# app.py lets the user map its columns to these fields.
REQUIRED_FIELDS = ["date", "campaign_id"]
NUMERIC_FIELDS = ["spend", "impressions", "clicks", "conversions", "revenue", "budget"]

ALIASES = {
    "date": ["date", "day", "report_date", "day_date", "timestamp", "date_start"],
    "campaign_id": ["campaign_id", "campaign", "campaign_name", "campaignid", "campaign_id_name"],
    "spend": ["spend", "cost", "amount_spent", "ad_spend", "total_spend", "cost_micros"],
    "impressions": ["impressions", "impr", "impression"],
    "clicks": ["clicks", "link_clicks", "click"],
    "conversions": ["conversions", "purchases", "leads", "results", "actions"],
    "revenue": ["revenue", "sales", "conversion_value", "purchase_value", "value"],
    "budget": ["budget", "daily_budget", "campaign_budget", "monthly_budget"],
    "ground_truth_anomaly": ["ground_truth_anomaly", "is_anomaly", "anomaly", "incident_label", "label"],
}

def read_table(file, filename="uploaded.csv"):
    """Read CSV or Excel upload/file path."""
    name = getattr(file, "name", filename).lower()
    if name.endswith((".xlsx", ".xls")):
        return pd.read_excel(file)
    return pd.read_csv(file)

def suggest_column_mapping(columns):
    """Suggest source columns for canonical fields using case-insensitive aliases."""
    lowered = {str(c).strip().lower().replace(" ", "_"): c for c in columns}
    mapping = {}
    for target, aliases in ALIASES.items():
        found = next((lowered[a] for a in aliases if a in lowered), None)
        mapping[target] = found
    return mapping

def standardize_data(raw_df, mapping):
    """
    Convert an industry dataset to the canonical internal schema.
    mapping maps canonical names to source column names; optional fields may be None.
    """
    if raw_df is None or raw_df.empty:
        raise ValueError("The uploaded dataset is empty.")

    out = pd.DataFrame(index=raw_df.index)
    for target, source in mapping.items():
        if source is not None and source in raw_df.columns:
            out[target] = raw_df[source]

    missing = [field for field in REQUIRED_FIELDS if field not in out.columns]
    if missing:
        raise ValueError(
            f"Could not map required field(s): {', '.join(missing)}. "
            "Map at least a date column and a campaign identifier."
        )

    out["date"] = pd.to_datetime(out["date"], errors="coerce")
    out["campaign_id"] = out["campaign_id"].astype("string").str.strip()
    out = out.dropna(subset=["date", "campaign_id"])
    out = out[out["campaign_id"] != ""]

    # If a metric is unavailable, preserve it as missing; do not invent measurements.
    for col in NUMERIC_FIELDS:
        if col in out.columns:
            out[col] = pd.to_numeric(out[col], errors="coerce")

    for col in ["spend", "impressions", "clicks", "conversions", "revenue", "budget"]:
        if col not in out.columns:
            out[col] = pd.NA

    if "ground_truth_anomaly" in out.columns:
        out["ground_truth_anomaly"] = pd.to_numeric(
            out["ground_truth_anomaly"], errors="coerce"
        )

    out = out.sort_values(["campaign_id", "date"]).reset_index(drop=True)
    return out

def validate_data(df):
    """Return data-quality checks without treating undefined ratios as missing raw data."""
    duplicate_keys = int(df.duplicated(["campaign_id", "date"]).sum())
    report = {
        "rows": int(len(df)),
        "campaigns": int(df["campaign_id"].nunique()),
        "unique_dates": int(df["date"].nunique()),
        "date_start": str(df["date"].min().date()) if len(df) else "n/a",
        "date_end": str(df["date"].max().date()) if len(df) else "n/a",
        "duplicate_campaign_days": duplicate_keys,
    }
    for col in ["spend", "impressions", "clicks", "conversions", "revenue", "budget"]:
        if col in df.columns:
            report[f"{col}_missing"] = int(df[col].isna().sum())
            report[f"{col}_negative"] = int((df[col].dropna() < 0).sum())
    if df["clicks"].notna().any() and df["impressions"].notna().any():
        valid = df[["clicks", "impressions"]].dropna()
        report["clicks_gt_impressions"] = int((valid["clicks"] > valid["impressions"]).sum())
    if df["conversions"].notna().any() and df["clicks"].notna().any():
        valid = df[["conversions", "clicks"]].dropna()
        report["conversions_gt_clicks"] = int((valid["conversions"] > valid["clicks"]).sum())
    return report
