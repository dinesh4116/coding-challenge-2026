import pandas as pd
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, confusion_matrix
)

def evaluate_detector(df, label_column="ground_truth_anomaly"):
    """Evaluate only when an independent ground-truth label is supplied."""
    if label_column not in df.columns:
        raise ValueError(
            f"No '{label_column}' column found. Evaluation requires an independent label."
        )
    valid = df[label_column].notna() & df["anomaly_detected"].notna()
    y_true = pd.to_numeric(df.loc[valid, label_column], errors="coerce")
    valid2 = y_true.isin([0, 1])
    subset = df.loc[valid].loc[valid2]
    y_true = y_true.loc[valid2].astype(int)
    y_pred = subset["anomaly_detected"].astype(int)
    if len(y_true) == 0:
        raise ValueError("No valid 0/1 ground-truth labels are available.")

    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return {
        "evaluated_rows": int(len(y_true)),
        "true_incident_rows": int(y_true.sum()),
        "true_positives": int(tp),
        "false_positives": int(fp),
        "false_negatives": int(fn),
        "true_negatives": int(tn),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1_score": float(f1_score(y_true, y_pred, zero_division=0)),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "false_positive_rate": float(fp / (fp + tn)) if (fp + tn) else 0.0,
    }

def evaluate_scenarios(df, scenario_column="scenario_tag", label_column="ground_truth_anomaly"):
    if scenario_column not in df.columns:
        raise ValueError(f"No '{scenario_column}' column is available.")
    rows = []
    for name, group in df.groupby(scenario_column, dropna=False):
        actual = pd.to_numeric(group[label_column], errors="coerce") if label_column in group else pd.Series(index=group.index, dtype=float)
        valid = actual.isin([0, 1])
        positives = int((actual[valid] == 1).sum())
        detected = int(((actual[valid] == 1) & group.loc[valid, "anomaly_detected"]).sum())
        rows.append({
            "scenario": str(name),
            "rows": int(len(group)),
            "labeled_incident_rows": positives,
            "detected_incident_rows": detected,
            "alert_rows": int(group["anomaly_detected"].sum()),
        })
    return pd.DataFrame(rows)
