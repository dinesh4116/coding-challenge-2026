import numpy as np
import pandas as pd

METRIC_LABELS = {
    "spend": "spend",
    "impressions": "impressions",
    "clicks": "clicks",
    "conversions": "conversions",
    "revenue": "revenue",
}


def _recommendation(row, threshold):
    """Return an evidence-aware investigation action, not a claimed root cause."""
    if row.get("incident_type") == "Possible conversion tracking failure":
        return "Verify conversion tags, analytics events, attribution delays, and data ingestion; compare against order or lead records."
    if row.get("incident_type") == "Campaign delivery stopped":
        return "Check campaign status, scheduling, billing, budget limits, approval status, and source-data completeness."

    candidates = []
    for metric in ["spend", "impressions", "clicks", "conversions", "revenue"]:
        zcol = f"{metric}_robust_z"
        z = row.get(zcol, np.nan)
        if pd.notna(z):
            candidates.append((metric, float(z)))
    candidates.sort(key=lambda item: abs(item[1]), reverse=True)
    strongest = candidates[0][0] if candidates else None
    if strongest == "spend":
        return "Review recent budget, bid strategy, pacing, and delivery changes; confirm the spend change was planned."
    if strongest == "impressions":
        return "Check campaign status, ad approval, audience/targeting changes, reach, and delivery restrictions."
    if strongest == "clicks":
        return "Inspect traffic volume, targeting, ad creative, click quality, and any recent delivery changes."
    if strongest == "conversions":
        return "Compare clicks with conversions; verify conversion tracking and inspect the landing page and conversion funnel."
    if strongest == "revenue":
        return "Check order value, conversion rate, revenue ingestion, attribution, and traffic quality."
    return "Inspect the campaign timeline and compare the changed metrics with recent campaign activity."


def detect_anomalies(df, threshold=3.5, min_history=7):
    """Campaign-specific robust rolling anomaly detection with evidence-aware descriptions."""
    result = df.copy()
    result["anomaly_detected"] = False
    result["severity"] = "Normal"
    result["incident_type"] = "Normal activity"
    result["anomaly_score"] = 0.0
    result["evidence_strength"] = "Insufficient history"
    result["explanation"] = "No strong anomaly signal detected."
    result["recommended_action"] = "Continue monitoring."

    available_z = [c for c in [
        "spend_robust_z", "impressions_robust_z", "clicks_robust_z",
        "conversions_robust_z", "revenue_robust_z"
    ] if c in result.columns]

    if available_z:
        z = result[available_z].abs()
        result["anomaly_score"] = z.max(axis=1, skipna=True).fillna(0)
        corroborating_metrics = (z >= threshold).sum(axis=1)
        extreme_single_metric = result["anomaly_score"] >= threshold * 2.5
        history_cols = [c for c in [
            "spend_history_count", "impressions_history_count", "clicks_history_count",
            "conversions_history_count", "revenue_history_count"
        ] if c in result.columns]
        enough_history = (result[history_cols].max(axis=1).fillna(0) >= min_history
                          if history_cols else pd.Series(False, index=result.index))
        statistical = ((corroborating_metrics >= 2) | extreme_single_metric) & enough_history
    else:
        statistical = pd.Series(False, index=result.index)

    result.loc[statistical, "anomaly_detected"] = True
    result.loc[statistical, "severity"] = "Medium"
    result.loc[statistical, "incident_type"] = "Unusual metric deviation"
    result.loc[statistical, "evidence_strength"] = "Statistical signal"

    for idx in result.index[statistical]:
        row = result.loc[idx]
        changed = []
        for metric in ["spend", "impressions", "clicks", "conversions", "revenue"]:
            z = row.get(f"{metric}_robust_z", np.nan)
            baseline = row.get(f"{metric}_baseline", np.nan)
            value = row.get(metric, np.nan)
            if pd.notna(z) and abs(float(z)) >= threshold and pd.notna(value) and pd.notna(baseline):
                direction = "increased" if value > baseline else "decreased" if value < baseline else "changed"
                changed.append(f"{metric} {direction} versus its recent baseline")
        if changed:
            result.at[idx, "explanation"] = "Detected deviation: " + "; ".join(changed[:3]) + "."
        else:
            result.at[idx, "explanation"] = "One or more metrics differ substantially from the campaign's recent historical baseline."
        result.at[idx, "recommended_action"] = _recommendation(row, threshold)

    # Pattern consistent with a possible tracking issue; not proof of root cause.
    needed = ["conversions", "conversions_baseline", "clicks", "clicks_baseline"]
    if all(c in result.columns for c in needed):
        tracking = (
            (result["conversions"] == 0)
            & (result["conversions_baseline"] >= 3)
            & (result["clicks_baseline"] >= 10)
            & (result["clicks"] >= 0.5 * result["clicks_baseline"])
        )
        result.loc[tracking, "anomaly_detected"] = True
        result.loc[tracking, "severity"] = "High"
        result.loc[tracking, "incident_type"] = "Possible conversion tracking failure"
        result.loc[tracking, "evidence_strength"] = "Strong multi-metric signal"
        result.loc[tracking, "explanation"] = "Recorded conversions fell to zero while click activity continued near its historical level; this can indicate a tracking issue or a real conversion decline."
        result.loc[tracking, "recommended_action"] = "Verify conversion tags, analytics events, attribution delays, and data ingestion; compare against order or lead records."

    # Delivery stop is a signal, not proof of budget exhaustion.
    if all(c in result.columns for c in ["spend", "impressions", "clicks"]):
        delivery_stop = (result["spend"] == 0) & (result["impressions"] == 0) & (result["clicks"] == 0)
        if "spend_baseline" in result.columns:
            delivery_stop &= result["spend_baseline"].fillna(0) > 0
        result.loc[delivery_stop, "anomaly_detected"] = True
        result.loc[delivery_stop, "severity"] = "Medium"
        result.loc[delivery_stop, "incident_type"] = "Campaign delivery stopped"
        result.loc[delivery_stop, "evidence_strength"] = "Delivery interruption signal"
        result.loc[delivery_stop, "explanation"] = "Spend, impressions, and clicks are all zero despite prior campaign activity."
        result.loc[delivery_stop, "recommended_action"] = "Check campaign status, scheduling, billing, budget limits, approval status, and source-data completeness."

    return result
