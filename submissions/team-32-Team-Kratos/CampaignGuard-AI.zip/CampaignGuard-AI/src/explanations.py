import pandas as pd


def explain_alert(row):
    """Produce a human-readable evidence summary for a flagged campaign-day."""
    if not bool(row.get("anomaly_detected", False)):
        return "No alert: no configured anomaly rule was triggered."
    parts = [
        f"Type: {row.get('incident_type', 'Unusual activity')}.",
        str(row.get("explanation", "")),
    ]
    for metric in ["spend", "impressions", "clicks", "conversions", "revenue"]:
        baseline_col = f"{metric}_baseline"
        if metric in row.index and baseline_col in row.index:
            value, baseline = row.get(metric), row.get(baseline_col)
            if pd.notna(value) and pd.notna(baseline):
                if baseline != 0:
                    pct = (value - baseline) / abs(baseline) * 100
                    parts.append(f"{metric}: {value:,.2f} vs baseline {baseline:,.2f} ({pct:+.1f}%).")
                else:
                    parts.append(f"{metric}: {value:,.2f} vs baseline {baseline:,.2f} (percentage change undefined when baseline is zero).")
    parts.append(f"Status: {row.get('alert_status', 'Review')}; severity: {row.get('severity', 'Unclassified')}; evidence: {row.get('evidence_strength', 'Not assessed')}.")
    parts.append(f"Recommended investigation: {row.get('recommended_action', 'Inspect the campaign timeline and validate the source data.')}")
    parts.append("This is a diagnostic signal, not proof of root cause.")
    return " ".join(p for p in parts if p)
