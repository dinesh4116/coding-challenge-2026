import numpy as np
import pandas as pd

METRICS = ["spend", "impressions", "clicks", "conversions", "revenue"]

def add_campaign_features(df, window=14, min_periods=7):
    """
    Create ratios and leakage-safe rolling baselines.
    Today's observation is excluded from its own baseline.
    """
    result = df.copy()
    result["date"] = pd.to_datetime(result["date"])
    result = result.sort_values(["campaign_id", "date"]).reset_index(drop=True)

    if result["spend"].notna().any() and result["clicks"].notna().any():
        result["cpc"] = result["spend"] / result["clicks"].replace(0, np.nan)
    if result["clicks"].notna().any() and result["impressions"].notna().any():
        result["ctr"] = result["clicks"] / result["impressions"].replace(0, np.nan)
    if result["conversions"].notna().any() and result["clicks"].notna().any():
        result["conversion_rate"] = result["conversions"] / result["clicks"].replace(0, np.nan)
    if result["spend"].notna().any() and result["conversions"].notna().any():
        result["cpa"] = result["spend"] / result["conversions"].replace(0, np.nan)
    if result["revenue"].notna().any() and result["spend"].notna().any():
        result["roas"] = result["revenue"] / result["spend"].replace(0, np.nan)

    result["day_of_week"] = result["date"].dt.dayofweek
    group = result.groupby("campaign_id", sort=False)

    for metric in METRICS:
        if metric not in result.columns or result[metric].isna().all():
            continue
        previous = group[metric].shift(1)
        rolling_group = previous.groupby(result["campaign_id"], sort=False)
        result[f"{metric}_baseline"] = rolling_group.transform(
            lambda s: s.rolling(window=window, min_periods=min_periods).median()
        )
        # Robust scale based on the prior observations only.
        result[f"{metric}_mad"] = rolling_group.transform(
            lambda s: s.rolling(window=window, min_periods=min_periods).apply(
                lambda x: np.median(np.abs(x - np.median(x))), raw=True
            )
        )
        result[f"{metric}_history_count"] = rolling_group.transform(
            lambda s: s.rolling(window=window, min_periods=1).count()
        )
        scale = (1.4826 * result[f"{metric}_mad"]).replace(0, np.nan)
        result[f"{metric}_robust_z"] = (
            result[metric] - result[f"{metric}_baseline"]
        ) / scale

    return result
