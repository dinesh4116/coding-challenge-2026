import pandas as pd


def apply_decision_policy(df, min_consecutive_days=2):
    """Label consecutive anomaly runs as Alert; isolated signals remain Review."""
    result = df.copy().sort_values(["campaign_id", "date"]).reset_index(drop=True)
    if "anomaly_detected" not in result:
        raise ValueError("Run detect_anomalies before apply_decision_policy.")
    result["date"] = pd.to_datetime(result["date"])
    result["alert_status"] = "Normal"
    for _, group in result.groupby("campaign_id", sort=False):
        active = group["anomaly_detected"].fillna(False).astype(bool)
        event_num = active.ne(active.shift(fill_value=False)).cumsum()
        for _, event_idx in group.groupby(event_num).groups.items():
            event_rows = result.loc[event_idx]
            if not bool(event_rows["anomaly_detected"].all()):
                continue
            status = "Alert" if len(event_rows) >= min_consecutive_days else "Review"
            result.loc[event_idx, "alert_status"] = status
    return result


def summarize_incidents(df):
    """Collapse consecutive flagged dates for each campaign into incident windows."""
    if df.empty:
        return pd.DataFrame()
    result = df.copy().sort_values(["campaign_id", "date"]).reset_index(drop=True)
    result["date"] = pd.to_datetime(result["date"])
    rows = []
    for campaign, group in result.groupby("campaign_id", sort=False):
        group = group.reset_index(drop=True)
        flags = group["anomaly_detected"].fillna(False).astype(bool)
        # Start a new event at each flagged row whose previous row was not flagged
        # or whose date is not exactly one day after the preceding date.
        prev_date = group["date"].shift(1)
        consecutive_date = (group["date"] - prev_date).dt.days.eq(1)
        starts = flags & (~flags.shift(fill_value=False) | ~consecutive_date)
        event_ids = starts.cumsum()
        for event_id, event in group[flags].groupby(event_ids[flags]):
            actions = [str(x) for x in event.get("recommended_action", pd.Series(dtype=str)).dropna().unique() if str(x).strip()]
            types = event["incident_type"].mode()
            severities = event["severity"].mode()
            rows.append({
                "campaign_id": campaign,
                "start_date": event["date"].min().date(),
                "end_date": event["date"].max().date(),
                "duration_days": int(event["date"].nunique()),
                "incident_type": types.iat[0] if len(types) else "Unusual activity",
                "severity": severities.iat[0] if len(severities) else "Review",
                "recommended_action": " | ".join(actions[:2]) if actions else "Inspect the campaign timeline and validate the source data.",
            })
    return pd.DataFrame(rows)
